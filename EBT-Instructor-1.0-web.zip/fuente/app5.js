/* ============ Agenda y avisos ============ */
var SLOT_ST={scheduled:['Programada',''],confirmed:['Confirmada','ok'],rescheduled:['Reprogramada','warn'],cancelled:['Cancelada','bad'],done:['Realizada','acc']};
var NOTE_K={cae:['Simulador','acc'],cambio:['Cambio de horario','warn'],cancelacion:['Cancelación','bad'],general:['General','']};
var DOW=['dom','lun','mar','mié','jue','vie','sáb'],MESL=['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
function dow(s){var p=s.split('-');return DOW[new Date(+p[0],+p[1]-1,+p[2]).getDay()];}
function monthKey(s){return String(s||'').slice(0,7);}
function unreadNotices(){var seen=S.ui.seenNotices||0;return live('notices').filter(function(n){return (n.ts||0)>seen;}).length;}
function slotPilots(sl){return [sl.cm1,sl.cm2].filter(Boolean);}
function slotName(id){if(!id)return '';var p=pilot(id);return p?p.name:id;}
function slotCrew(sl){return slotPilots(sl).map(function(x){return esc(slotName(x));}).join(' · ')||'<span class="muted">Sin tripulación asignada</span>';}
function slotsOf(month){return live('schedule').filter(function(s){return !month||monthKey(s.date)===month;}).sort(function(a,b){return (a.date+a.time).localeCompare(b.date+b.time);});}
function slotRow(sl){
  var st=SLOT_ST[sl.status]||SLOT_ST.scheduled,mine=isMine(sl);
  return '<button class="li" data-act="openSlot" data-id="'+sl.id+'"'+(sl.status==='cancelled'?' style="opacity:.6"':'')+'><div style="width:52px;flex:none;text-align:center"><div class="num" style="font-weight:700;font-size:15px">'+esc(sl.time||'—')+'</div><div class="tiny muted num">'+esc(sl.end||'')+'</div></div><div class="grow"><div class="t"><span class="pill acc" style="height:20px;margin-right:6px">'+esc(sl.phase)+'</span>'+slotCrew(sl)+'</div><div class="small muted" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(sl.sim||'Simulador por asignar')+' · '+esc(sl.fleet)+(sl.instructor?' · '+esc(sl.instructor):'')+'</div></div>'+(mine?'<span class="pill">Tuya</span>':'')+(sl.sessionId?'<span class="pill ok">Evaluada</span>':'<span class="pill '+st[1]+'">'+st[0]+'</span>')+I.chev+'</button>';
}
function noticeRow(n,compact){
  var k=NOTE_K[n.kind]||NOTE_K.general,isNew=(n.ts||0)>(S.ui.seenNotices||0);
  return '<div class="flag" style="flex-direction:column;align-items:stretch;gap:4px"><div class="row" style="gap:8px"><span class="pill '+k[1]+'" style="flex:none">'+k[0]+'</span><div style="flex:1;min-width:0;font-weight:600">'+(isNew?'<span class="dot" style="display:inline-block;background:var(--accent);margin-right:6px;vertical-align:middle"></span>':'')+esc(n.title)+'</div></div>'+(compact?'':'<div class="small" style="white-space:pre-wrap">'+esc(n.body||'')+'</div>')+
   '<div class="row" style="gap:8px"><span class="tiny muted" style="flex:1;min-width:0">'+ftime(n.ts)+(n.by?' · '+esc(n.by):'')+'</span>'+(n.scheduleId&&S.schedule[n.scheduleId]?'<button class="btn ghost sm" data-act="openSlot" data-id="'+n.scheduleId+'">Ver sesión</button>':'')+(compact||!(isCoord()||n.by===S.settings.instructor)?'':'<button class="btn ghost sm" data-act="delNotice" data-id="'+n.id+'" aria-label="Eliminar aviso" style="color:var(--muted)">'+I.x+'</button>')+'</div></div>';
}
function inicioAgenda(){
  var t=today(),up=live('schedule').filter(function(s){return s.date>=t&&s.status!=='cancelled';}).sort(function(a,b){return (a.date+a.time).localeCompare(b.date+b.time);}).slice(0,4);
  var ns=live('notices').sort(function(a,b){return (b.ts||0)-(a.ts||0);}).slice(0,3);
  if(!up.length&&!ns.length)return '';
  var byDay={};up.forEach(function(s){(byDay[s.date]=byDay[s.date]||[]).push(s);});
  return '<div class="grid g2" style="margin-bottom:16px"><div class="card" style="padding:0;overflow:hidden"><div class="card-head" style="padding:16px 20px 6px;margin:0"><div><h3>Próximas sesiones</h3><p class="small muted">'+(up.length?(up[0].date===t?'Hoy':'Siguiente: '+dow(up[0].date)+' '+fdate(up[0].date)):'Nada programado')+'</p></div><button class="btn ghost sm" data-act="go" data-r="agenda">Agenda</button></div>'+
   (up.length?Object.keys(byDay).map(function(d){return '<div class="eyebrow" style="padding:8px 20px 2px">'+(d===t?'Hoy · ':'')+dow(d)+' '+fdate(d)+'</div>'+byDay[d].map(slotRow).join('');}).join(''):'<p class="small muted" style="padding:0 20px 16px">Importa el cronograma del mes o programa una sesión.</p>')+'</div>'+
   '<div class="card"><div class="card-head"><div><h3>Avisos</h3><p class="small muted">'+(unreadNotices()?unreadNotices()+' sin leer':'Al día')+'</p></div><button class="btn ghost sm" data-act="go" data-r="agenda">Ver todos</button></div>'+(ns.length?ns.map(function(n){return noticeRow(n,true);}).join(''):'<p class="small muted">Sin avisos.</p>')+'</div></div>';
}
function vAgenda(){
  var m=S.ui.month||(S.ui.month=today().slice(0,7));var p=m.split('-'),y=+p[0],mo=+p[1];
  function shift(d){var dt=new Date(y,mo-1+d,1);return dt.getFullYear()+'-'+String(dt.getMonth()+1).padStart(2,'0');}
  var ss=slotsOf(m),t=today();
  var html=head('Agenda','Cronograma de simulador y avisos.',(isCoord()?'<button class="btn" data-act="importSched">'+I.up+'Importar cronograma</button>':'')+(isCoord()?'<button class="btn" data-act="newNotice">'+I.bell+'Aviso</button>':'')+(isCoord()?'<button class="btn primary" data-act="newSlot">'+I.plus+'Programar</button>':''));
  var ns=live('notices').sort(function(a,b){return (b.ts||0)-(a.ts||0);});
  html+='<div class="card" style="margin-bottom:16px"><div class="card-head"><div><h3>Avisos</h3><p class="small muted">Cambios de horario, cancelaciones e información de simulador</p></div>'+(unreadNotices()?'<button class="btn sm" data-act="markRead">Marcar leídos</button>':'')+'</div>'+(ns.length?ns.slice(0,S.ui.allNotices?999:5).map(function(n){return noticeRow(n);}).join('')+(ns.length>5&&!S.ui.allNotices?'<button class="btn ghost sm" data-act="allNotices" style="margin-top:8px">Ver los '+ns.length+' avisos</button>':''):'<p class="small muted">Sin avisos todavía.</p>')+'</div>';
  html+='<div class="row" style="margin-bottom:12px"><button class="btn sm" data-act="month" data-v="'+shift(-1)+'">'+I.back+'</button><h2 style="min-width:190px;text-align:center">'+MESL[mo-1]+' '+y+'</h2><button class="btn sm" data-act="month" data-v="'+shift(1)+'">'+I.chev.replace('class="chev"','')+'</button>'+(m!==t.slice(0,7)?'<button class="btn ghost sm" data-act="month" data-v="'+t.slice(0,7)+'">Hoy</button>':'')+'<span class="spacer"></span><div class="seg"><button class="'+(!S.ui.onlyMine?'on':'')+'" data-act="onlyMine" data-v="">Todas</button><button class="'+(S.ui.onlyMine?'on':'')+'" data-act="onlyMine" data-v="1">Mis sesiones</button></div></div>';
  if(S.ui.onlyMine==null)S.ui.onlyMine=!isCoord();
  if(S.ui.onlyMine)ss=ss.filter(function(s){return isMine(s);});
  var n=ss.filter(function(s){return s.status!=='cancelled';}).length,c=ss.length-n;
  html+='<p class="small muted" style="margin-bottom:10px">'+n+' sesión'+(n===1?'':'es')+(c?' · '+c+' cancelada'+(c===1?'':'s'):'')+' · '+ss.filter(function(s){return s.sessionId;}).length+' evaluada'+(ss.filter(function(s){return s.sessionId;}).length===1?'':'s')+'</p>';
  if(!ss.length)return html+'<div class="card">'+empty('cal','Sin sesiones en '+MESL[mo-1],'Importa el cronograma mensual (CSV o JSON con fecha, hora, fase, módulo, flota, CM1, CM2, instructor y simulador) o programa una sesión manualmente.',isCoord()?'<div class="row" style="justify-content:center"><button class="btn" data-act="importSched">'+I.up+'Importar cronograma</button><button class="btn primary" data-act="newSlot">'+I.plus+'Programar sesión</button></div>':'')+'</div>';
  var byDay={};ss.forEach(function(s){(byDay[s.date]=byDay[s.date]||[]).push(s);});
  html+=Object.keys(byDay).sort().map(function(d){var past=d<t;return '<div class="eyebrow" style="margin:14px 0 6px;'+(past?'opacity:.6':'')+(d===t?'color:var(--accent)':'')+'">'+(d===t?'Hoy · ':'')+dow(d)+' '+fdate(d)+'</div><div class="list"'+(past?' style="opacity:.75"':'')+'>'+byDay[d].map(slotRow).join('')+'</div>';}).join('');
  return html;
}
function prepCard(pid){
  var p=pilot(pid);if(!p)return '<div class="note">Trainee «'+esc(pid)+'» no está registrado. Agrégalo en Trainees para ver su historial.</div>';
  var ss=pilotSessions(pid).filter(function(s){return s.status==='signed';}),last=ss[ss.length-1],w=weaknesses(pid);
  var html='<div class="card" style="padding:14px 16px"><div class="row" style="margin-bottom:8px"><span class="avatar">'+initials(p.name)+'</span><div style="flex:1;min-width:0"><div style="font-weight:600">'+esc(p.name)+'</div><div class="small muted">'+esc(p.rank==='CPT'?'Capitán':'Primer oficial')+' · '+esc(p.fleet)+' · '+ss.length+' sesión'+(ss.length===1?'':'es')+(last?' · última '+esc(last.phase)+' '+fdateShort(last.date)+' ('+f1(sessAvg(last,seatOf(last,pid)))+')':'')+'</div></div><button class="btn sm" data-act="openPilot" data-id="'+pid+'">Perfil</button></div>';
  if(!last)return html+'<p class="small muted">Sin historial firmado.</p></div>';
  html+='<div style="display:grid;grid-template-columns:repeat(9,1fr);gap:4px;margin-bottom:10px">'+CK.map(function(k){var v=last.grades[seatOf(last,pid)][k];v=v&&v.g;return '<div style="text-align:center"><div class="tiny muted" style="font-family:var(--mono)">'+k+'</div><span class="gchip '+gcls(v)+'" style="width:100%">'+(v||'·')+'</span></div>';}).join('')+'</div>';
  if(w.comp.length||w.obs.length||w.events.length){html+='<div class="eyebrow" style="margin-bottom:4px">Atención</div><div class="small">'+(w.comp.length?'<div><b>Competencias en 1–2:</b> '+w.comp.map(function(c){return c.k+' ('+c.n+'×)';}).join(', ')+'</div>':'')+(w.obs.length?'<div><b>OB deficientes:</b> '+w.obs.slice(0,6).map(function(o){return 'OB '+o.o;}).join(', ')+'</div>':'')+(w.events.length?'<div><b>Reforzar:</b> '+w.events.slice(0,3).map(function(e){return esc(e.t);}).join('; ')+'</div>':'')+'</div>';}
  else html+='<p class="small muted">Sin falencias registradas en el historial.</p>';
  return html+'</div>';
}
function slotDetail(sl){
  var st=SLOT_ST[sl.status]||SLOT_ST.scheduled;
  var html='<div class="row" style="margin-bottom:14px"><span class="pill '+st[1]+'">'+st[0]+'</span>'+(sl.sessionId?'<span class="pill ok">Evaluada</span>':'')+(sl.example?'<span class="pill">Ejemplo</span>':'')+'<span class="spacer"></span>'+(isCoord()?'<button class="btn sm" data-act="editSlot" data-id="'+sl.id+'">'+I.pen+'Editar</button>':'')+'</div>';
  html+='<div class="card" style="margin-bottom:14px"><dl class="kv"><dt>Fecha</dt><dd>'+dow(sl.date)+' '+fdate(sl.date)+' · '+esc(sl.time||'')+(sl.end?'–'+esc(sl.end):'')+'</dd><dt>Sesión</dt><dd>'+esc(sl.phase)+' <span class="muted small">('+esc(phaseName(sl.phase))+')</span> · '+esc(sl.module)+' · '+esc(sl.fleet)+'</dd><dt>Simulador</dt><dd>'+esc(sl.sim||'Por asignar')+'</dd><dt>Instructor</dt><dd>'+esc(sl.instructor||'Por asignar')+'</dd>'+(sl.note?'<dt>Nota</dt><dd style="font-weight:500">'+esc(sl.note)+'</dd>':'')+'</dl></div>';
  if(sl.sessionId&&S.sessions[sl.sessionId])html+='<button class="btn" data-act="openSession" data-id="'+sl.sessionId+'" style="margin-bottom:14px">'+I.doc+'Ver evaluación</button>';
  html+='<div class="eyebrow" style="margin-bottom:8px">Preparación · trainees a evaluar</div><div class="stack" style="gap:10px;margin-bottom:14px">'+(slotPilots(sl).length?slotPilots(sl).map(prepCard).join(''):'<p class="small muted">Sin tripulación asignada.</p>')+'</div>';
  var ns=live('notices').filter(function(n){return n.scheduleId===sl.id;});if(ns.length)html+='<div class="card" style="margin-bottom:14px"><h3 style="margin-bottom:4px">Avisos de esta sesión</h3>'+ns.map(function(n){return noticeRow(n,true);}).join('')+'</div>';
  if(isCoord())html+='<div class="eyebrow" style="margin-bottom:8px">Estado</div><div class="row" style="margin-bottom:14px">'+['confirmed','rescheduled','cancelled','scheduled'].filter(function(k){return k!==sl.status;}).map(function(k){return '<button class="btn sm'+(k==='cancelled'?' danger':'')+'" data-act="slotStatus" data-id="'+sl.id+'" data-v="'+k+'">'+SLOT_ST[k][0]+'</button>';}).join('')+'</div>';
  if(isCoord())html+='<div class="row"><button class="btn danger sm" data-act="delSlot" data-id="'+sl.id+'">'+I.trash+'Eliminar</button></div>';
  return html;
}
function slotForm(){
  var f=S.ui.form,st=S.settings,ps=live('trainees').filter(function(p){return p.fleet===f.fleet;}).sort(function(a,b){return a.name.localeCompare(b.name);});
  function sel(id,k,opts,blank){return '<select class="input" id="'+id+'" data-fb="'+k+'"'+(k==='fleet'?' data-rerender="1"':'')+'>'+(blank?'<option value="">'+blank+'</option>':'')+opts.map(function(o){var v=typeof o==='string'?o:o[0],l=typeof o==='string'?o:o[1];return '<option value="'+esc(v)+'"'+(f[k]===v?' selected':'')+'>'+esc(l)+'</option>';}).join('')+'</select>';}
  var popts=ps.map(function(p){return [p.id,p.name+' · '+(p.rank==='CPT'?'CPT':'FO')];});
  return '<div class="stack"><div class="grid g3" style="gap:12px"><div class="field"><label for="sf-d">Fecha</label><input type="date" class="input" id="sf-d" data-fb="date" value="'+esc(f.date||'')+'"></div><div class="field"><label for="sf-t">Inicio</label><input type="time" class="input" id="sf-t" data-fb="time" value="'+esc(f.time||'')+'"></div><div class="field"><label for="sf-e">Fin</label><input type="time" class="input" id="sf-e" data-fb="end" value="'+esc(f.end||'')+'"></div></div>'+
   '<div class="grid g3" style="gap:12px"><div class="field"><label for="sf-m">Módulo</label>'+sel('sf-m','module',st.modules)+'</div><div class="field"><label for="sf-f">Flota</label>'+sel('sf-f','fleet',st.fleets)+'</div><div class="field"><label for="sf-p">Fase</label>'+sel('sf-p','phase',st.phases)+'</div></div>'+
   '<div class="field"><label for="sf-s">Simulador</label>'+sel('sf-s','sim',st.sims||[],'Por asignar')+'</div>'+
   '<div class="grid g2" style="gap:12px"><div class="field"><label for="sf-1">CM1</label>'+sel('sf-1','cm1',popts,'Sin asignar')+'</div><div class="field"><label for="sf-2">CM2</label>'+sel('sf-2','cm2',popts,'Sin asignar')+'</div></div>'+
   '<div class="field"><label for="sf-i">Instructor</label>'+sel('sf-i','iid',Object.keys(members()).map(function(k){var m=members()[k];return [k,(m.full_name||m.email)+(m.ie_code?' · '+m.ie_code:'')];}).filter(function(o){return members()[o[0]].status==='active';}),'Por asignar')+'</div>'+
   '<div class="field"><label for="sf-n">Nota</label><input class="input" id="sf-n" data-fb="note" value="'+esc(f.note||'')+'" placeholder="Ej. refuerzo WLM; cambio de simulador"></div></div>';
}
function noticeForm(){
  var f=S.ui.form,sl=slotsOf('').filter(function(s){return s.date>=today();});
  return '<div class="stack"><div class="field"><label>Tipo</label><div class="seg full">'+Object.keys(NOTE_K).map(function(k){return '<button class="'+(f.kind===k?'on':'')+'" data-act="form" data-k="kind" data-v="'+k+'">'+NOTE_K[k][0]+'</button>';}).join('')+'</div></div>'+
   '<div class="field"><label for="nf-t">Título</label><input class="input" id="nf-t" data-fb="title" value="'+esc(f.title||'')+'" placeholder="Ej. FFS A320 #2 fuera de servicio el 10 oct"></div>'+
   '<div class="field"><label for="nf-b">Detalle</label><textarea class="input" id="nf-b" data-fb="body" style="min-height:90px">'+esc(f.body||'')+'</textarea></div>'+
   '<div class="field"><label for="nf-s">Sesión relacionada (opcional)</label><select class="input" id="nf-s" data-fb="scheduleId"><option value="">Ninguna</option>'+sl.map(function(s){return '<option value="'+s.id+'"'+(f.scheduleId===s.id?' selected':'')+'>'+esc(fdate(s.date)+' '+(s.time||'')+' · '+s.phase+' · '+slotPilots(s).map(function(x){return slotName(x).split(' ')[0];}).join('/'))+'</option>';}).join('')+'</select></div></div>';
}
function addNotice(kind,title,body,scheduleId){put('notices',{id:uid('n'),ts:Date.now(),kind:kind,title:title,body:body||'',scheduleId:scheduleId||'',by:S.settings.instructor},true);}
function matchPilot(txt,fleet){txt=String(txt||'').trim();if(!txt)return '';var low=txt.toLowerCase();var ps=live('trainees');var hit=ps.filter(function(p){return p.id===txt||(p.emp&&p.emp===txt)||p.name.toLowerCase()===low;})[0]||ps.filter(function(p){return p.name.toLowerCase().indexOf(low)>=0||low.indexOf(p.name.toLowerCase())>=0;})[0];return hit?hit.id:'';}
function importSchedule(text,name){
  var rows=[];
  try{
    if(/^\s*[\[{]/.test(text)){var o=JSON.parse(text);rows=Array.isArray(o)?o:(o.schedule?(Array.isArray(o.schedule)?o.schedule:Object.keys(o.schedule).map(function(k){return o.schedule[k];})):[o]);}
    else{var lines=text.split(/\r?\n/).filter(function(l){return l.trim();});var sep=(lines[0].match(/;/g)||[]).length>=(lines[0].match(/,/g)||[]).length?';':',';
      var hd=lines[0].split(sep).map(function(h){return h.trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');});
      rows=lines.slice(1).map(function(l){var c=l.split(sep);var r={};hd.forEach(function(h,i){r[h]=(c[i]||'').trim().replace(/^"|"$/g,'');});return r;});}
  }catch(e){toast('No se pudo leer el archivo');return;}
  function pick(r,keys){for(var i=0;i<keys.length;i++){if(r[keys[i]]!=null&&r[keys[i]]!=='')return r[keys[i]];}return '';}
  var n=0;rows.forEach(function(r){
    var date=pick(r,['date','fecha']);if(!date)return;if(/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(date)){var p=date.split('/');date=p[2]+'-'+p[1].padStart(2,'0')+'-'+p[0].padStart(2,'0');}
    var fleet=pick(r,['fleet','flota'])||S.settings.fleets[0];
    var rec={id:r.id||uid('a'),date:date,time:pick(r,['time','hora','inicio']),end:pick(r,['end','fin','hora fin']),module:pick(r,['module','modulo'])||S.settings.module,fleet:fleet,phase:(pick(r,['phase','fase'])||'EVAL').toUpperCase(),sim:pick(r,['sim','simulador','ffs']),cm1:matchPilot(pick(r,['cm1','piloto1','capitan','cpt']),fleet),cm2:matchPilot(pick(r,['cm2','piloto2','primer oficial','fo']),fleet),instructor:pick(r,['instructor','ie']),status:r.status||'scheduled',note:pick(r,['note','nota','observaciones']),sessionId:''};var im=memberByName(rec.instructor);rec.iid=im?im.user_id:'';rec.instructor=im?memberName(im.user_id):rec.instructor;var miss=[];if(!rec.cm1&&pick(r,['cm1','piloto1','capitan','cpt']))miss.push('CM1 '+pick(r,['cm1','piloto1','capitan','cpt']));if(!rec.cm2&&pick(r,['cm2','piloto2','primer oficial','fo']))miss.push('CM2 '+pick(r,['cm2','piloto2','primer oficial','fo']));if(miss.length)rec.note=(rec.note?rec.note+' · ':'')+'No registrado: '+miss.join(', ');if(!isUuid(rec.id))rec.id=uid('a');
    var ex=S.schedule[rec.id];if(ex){rec.sessionId=ex.sessionId;rec.status=ex.status;}put('schedule',rec,true);n++;});
  if(n){addNotice('cae','Cronograma importado','Se cargaron '+n+' sesiones desde '+(name||'archivo')+'.','');var first=rows.map(function(r){return r.date||r.fecha||'';}).filter(Boolean).sort()[0];if(first)S.ui.month=monthKey(first);}
  render();toast(n?n+' sesiones importadas':'No se encontraron filas con fecha');
}
var AGENDA_ACT={
  month:function(el){S.ui.month=el.dataset.v;render();window.scrollTo(0,0);},
  onlyMine:function(el){S.ui.onlyMine=!!el.dataset.v;render();},
  allNotices:function(){S.ui.allNotices=true;render();},
  markRead:function(){S.ui.seenNotices=Date.now();persist();render();},
  openSlot:function(el){openSheet({type:'slot',id:el.dataset.id});},
  newSlot:function(){S.ui.form={date:today(),time:'08:00',end:'12:00',module:S.settings.module,fleet:S.settings.fleets[0],phase:S.settings.phases[0],sim:'',cm1:'',cm2:'',iid:myId(),note:''};openSheet({type:'slotForm'});},
  editSlot:function(el){S.ui.form=JSON.parse(JSON.stringify(S.schedule[el.dataset.id]));openSheet({type:'slotForm',id:el.dataset.id});},
  saveSlot:function(){var f=S.ui.form;if(!f.date)return toast('Indica la fecha');if(f.cm1&&f.cm1===f.cm2)return toast('CM1 y CM2 deben ser distintos');var isNew=!f.id;var prev=f.id&&S.schedule[f.id];var r=Object.assign({},f,{id:f.id||uid('a'),status:f.status||'scheduled',sessionId:f.sessionId||'',instructor:memberName(f.iid)});
    if(prev&&(prev.date!==r.date||prev.time!==r.time||prev.sim!==r.sim)){if(prev.date!==r.date||prev.time!==r.time)r.status='rescheduled';addNotice('cambio','Sesión '+r.phase+' '+(slotPilots(r).map(function(x){return slotName(x).split(' ')[0];}).join('/')||'')+' reprogramada','Antes: '+fdate(prev.date)+' '+(prev.time||'')+' · '+(prev.sim||'')+'\nAhora: '+fdate(r.date)+' '+(r.time||'')+' · '+(r.sim||''),r.id);}
    put('schedule',r,true);S.ui.sheet=null;S.ui.month=monthKey(r.date);render();toast(isNew?'Sesión programada':'Sesión actualizada');},
  slotStatus:function(el){var sl=S.schedule[el.dataset.id];var v=el.dataset.v;sl.status=v;put('schedule',sl,true);
    if(v==='cancelled')addNotice('cancelacion','Cancelada: '+sl.phase+' '+fdate(sl.date)+' '+(sl.time||''),slotPilots(sl).map(slotName).join(' / ')+' · '+(sl.sim||''),sl.id);
    render();toast('Estado: '+SLOT_ST[v][0]);},
  delSlot:function(el){openSheet({type:'confirm',title:'Eliminar sesión programada',msg:'Se quitará del cronograma para todos los instructores.',act:'delSlotYes',id:el.dataset.id});},
  startFromSlot:function(el){var sl=S.schedule[el.dataset.id];S.ui.cur=null;S.ui.setup=null;vSetup();Object.assign(S.ui.setup,{date:sl.date,module:sl.module,fleet:sl.fleet,phase:sl.phase,mode:sl.cm2?'crew':'single',cm1:pilot(sl.cm1)?sl.cm1:'',cm2:pilot(sl.cm2)?sl.cm2:'',slotId:sl.id});
    var t=live('evals').filter(function(e){return e.fleet===sl.fleet&&e.phase===sl.phase&&e.module===sl.module;})[0]||live('evals').filter(function(e){return e.fleet===sl.fleet&&e.phase===sl.phase;})[0];if(t)S.ui.setup.templateId=t.id;go('evaluar');},
  newNotice:function(){S.ui.form={kind:'general',title:'',body:'',scheduleId:''};openSheet({type:'notice'});},
  saveNotice:function(){var f=S.ui.form;if(!f.title||!f.title.trim())return toast('Escribe el título del aviso');addNotice(f.kind,f.title.trim(),f.body,f.scheduleId);S.ui.sheet=null;render();toast('Aviso publicado');},
  delNotice:function(el){remove('notices',el.dataset.id);}
};
