#!/bin/sh
# Construye la versión de producción en dist/
set -e
V=$(date +%Y%m%d%H%M)
rm -rf dist && mkdir -p dist/icons
cat app1.js sb.js app2.js app3.js app5.js app6.js app4.js app7.js app8.js > dist/app.js
cp config.js manifest.webmanifest dist/
sed "s/__VERSION__/$V/" sw.js > dist/sw.js
cp brand/icon-192.png brand/icon-512.png brand/icon-1024.png brand/apple-touch-icon.png dist/icons/
cp brand/icon.svg dist/icons/icon.svg
{ echo '<!doctype html><html lang="es"><head><meta charset="utf-8">'
  echo '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
  echo '<meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">'
  echo '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-mobile-web-app-title" content="EBT Instructor">'
  echo '<link rel="manifest" href="manifest.webmanifest"><link rel="icon" href="icons/icon.svg" type="image/svg+xml"><link rel="apple-touch-icon" href="icons/apple-touch-icon.png">'
  cat head.html
  echo '</head><body><div id="root"></div>'
  echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js" defer></script>'
  echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js" defer></script>'
  echo "<script src=\"config.js?v=$V\"></script><script src=\"app.js?v=$V\"></script>"
  echo '<script>if("serviceWorker" in navigator&&location.protocol==="https:"||location.hostname==="localhost"){navigator.serviceWorker&&navigator.serviceWorker.register("sw.js").catch(function(){});}</script>'
  echo '</body></html>'; } > dist/index.html
echo "dist listo ($V)"
