'use strict';
/* ============ Marco de competencias (EASA AMC1 ORO.FC.231 / OACI Doc 9995 — numeración OB 0–8) ============ */
var COMP=[
 {k:'KNO',n:0,es:'Aplicación del conocimiento',en:'Application of knowledge',ob:[
  ['0.1','Demonstrates practical and applicable knowledge of limitations and systems and their interaction'],
  ['0.2','Demonstrates required knowledge of published operating instructions'],
  ['0.3','Demonstrates knowledge of the physical environment, the ATC environment and the operational infrastructure'],
  ['0.4','Demonstrates appropriate knowledge of applicable legislation'],
  ['0.5','Knows where to source required information'],
  ['0.6','Demonstrates a positive interest in acquiring knowledge'],
  ['0.7','Is able to apply knowledge effectively']]},
 {k:'APK',n:1,es:'Aplicación de procedimientos y cumplimiento normativo',en:'Application of procedures and compliance with regulations',ob:[
  ['1.1','Identifies where to find procedures and regulations'],
  ['1.2','Applies relevant operating instructions, procedures and techniques in a timely manner'],
  ['1.3','Follows SOPs unless a higher degree of safety dictates an appropriate deviation'],
  ['1.4','Operates aircraft systems and associated equipment correctly'],
  ['1.5','Monitors aircraft systems status'],
  ['1.6','Complies with applicable regulations'],
  ['1.7','Applies relevant procedural knowledge']]},
 {k:'COM',n:2,es:'Comunicación',en:'Communication',ob:[
  ['2.1','Determines that the recipient is ready and able to receive information'],
  ['2.2','Selects appropriately what, when, how and with whom to communicate'],
  ['2.3','Conveys messages clearly, accurately and concisely'],
  ['2.4','Confirms that the recipient demonstrates understanding of important information'],
  ['2.5','Listens actively and demonstrates understanding when receiving information'],
  ['2.6','Asks relevant and effective questions'],
  ['2.7','Uses appropriate escalation in communication to resolve identified deviations'],
  ['2.8','Uses and interprets non-verbal communication appropriately'],
  ['2.9','Adheres to standard radiotelephone phraseology and procedures'],
  ['2.10','Accurately reads, interprets, constructs and responds to datalink messages']]},
 {k:'FPA',n:3,es:'Gestión de la trayectoria: automatización',en:'Flight path management — automation',ob:[
  ['3.1','Controls the aircraft using automation with accuracy and smoothness as appropriate'],
  ['3.2','Monitors and detects deviations from the intended flight path and takes appropriate action'],
  ['3.3','Manages the flight path to achieve optimum operational performance'],
  ['3.4','Maintains the intended flight path using automation whilst managing other tasks and distractions'],
  ['3.5','Selects appropriate level and mode of automation in a timely manner'],
  ['3.6','Effectively monitors automation, including engagement and automatic mode transitions']]},
 {k:'FPM',n:4,es:'Gestión de la trayectoria: control manual',en:'Flight path management — manual control',ob:[
  ['4.1','Controls the aircraft using manual control with accuracy and smoothness as appropriate'],
  ['4.2','Monitors and detects deviations from the intended flight path and takes appropriate action'],
  ['4.3','Manually controls the aeroplane using the relationship between attitude, speed and thrust, and navigation signals or visual information'],
  ['4.4','Manages the flight path to achieve optimum operational performance'],
  ['4.5','Maintains the intended flight path during manual flight whilst managing other tasks and distractions'],
  ['4.6','Uses appropriate flight management and guidance systems, as installed and applicable'],
  ['4.7','Effectively monitors flight guidance systems including engagement and automatic mode transitions']]},
 {k:'LTW',n:5,es:'Liderazgo y trabajo en equipo',en:'Leadership and teamwork',ob:[
  ['5.1','Encourages team participation and open communication'],
  ['5.2','Demonstrates initiative and provides direction when required'],
  ['5.3','Engages others in planning'],
  ['5.4','Considers inputs from others'],
  ['5.5','Gives and receives feedback constructively'],
  ['5.6','Addresses and resolves conflicts and disagreements in a constructive manner'],
  ['5.7','Exercises decisive leadership when required'],
  ['5.8','Accepts responsibility for decisions and actions'],
  ['5.9','Carries out instructions when directed'],
  ['5.10','Applies effective intervention strategies to resolve identified deviations'],
  ['5.11','Manages cultural and language challenges, as applicable']]},
 {k:'PSD',n:6,es:'Resolución de problemas y toma de decisiones',en:'Problem solving and decision making',ob:[
  ['6.1','Identifies, assesses and manages threats and errors in a timely manner'],
  ['6.2','Seeks accurate and adequate information from appropriate sources'],
  ['6.3','Identifies and verifies what and why things have gone wrong, if appropriate'],
  ['6.4','Perseveres in working through problems whilst prioritising safety'],
  ['6.5','Identifies and considers appropriate options'],
  ['6.6','Applies appropriate and timely decision-making techniques'],
  ['6.7','Monitors, reviews and adapts decisions as required'],
  ['6.8','Adapts when faced with situations where no guidance or procedure exists'],
  ['6.9','Demonstrates resilience when encountering an unexpected event']]},
 {k:'SAW',n:7,es:'Conciencia situacional y gestión de la información',en:'Situation awareness and management of information',ob:[
  ['7.1','Monitors and assesses the state of the aeroplane and its systems'],
  ['7.2','Monitors and assesses the aeroplane’s energy state and its anticipated flight path'],
  ['7.3','Monitors and assesses the general environment as it may affect the operation'],
  ['7.4','Validates the accuracy of information and checks for gross errors'],
  ['7.5','Maintains awareness of the people involved in or affected by the operation and their capacity to perform as expected'],
  ['7.6','Develops effective contingency plans based upon potential risks associated with threats and errors'],
  ['7.7','Responds to indications of reduced situation awareness']]},
 {k:'WLM',n:8,es:'Gestión de la carga de trabajo',en:'Workload management',ob:[
  ['8.1','Exercises self-control in all situations'],
  ['8.2','Plans, prioritises and schedules appropriate tasks effectively'],
  ['8.3','Manages time efficiently when carrying out tasks'],
  ['8.4','Offers and gives assistance'],
  ['8.5','Delegates tasks'],
  ['8.6','Seeks and accepts assistance, when appropriate'],
  ['8.7','Monitors, reviews and cross-checks actions conscientiously'],
  ['8.8','Verifies that tasks are completed to the expected outcome'],
  ['8.9','Manages and recovers from interruptions, distractions, variations and failures effectively']]}
];
var LOGO="data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 96 96%22%3E%3Crect x=%22.5%22 y=%22.5%22 width=%2295%22 height=%2295%22 rx=%2221.5%22 fill=%22%23111113%22 stroke=%22%23ffffff%22 stroke-opacity=%22.14%22/%3E%3Cdefs%3E%3CclipPath id=%22c528%22%3E%3Ccircle cx=%2248%22 cy=%2248%22 r=%2224.2%22/%3E%3C/clipPath%3E%3C/defs%3E%3Cg clip-path=%22url(%23c528)%22 transform=%22rotate(-10 48 48)%22%3E%3Crect x=%226.4%22 y=%2255.8%22 width=%2283.2%22 height=%2252%22 fill=%22%23ffffff%22 fill-opacity=%22.18%22/%3E%3Cline x1=%229%22 y1=%2255.8%22 x2=%2287%22 y2=%2255.8%22 stroke=%22%23fff%22 stroke-width=%221.8%22/%3E%3C/g%3E%3Ccircle cx=%2248%22 cy=%2248%22 r=%2226%22 fill=%22none%22 stroke=%22%23fff%22 stroke-width=%223.6%22/%3E%3Cpath d=%22M32.4 46.7 h9.36 l6.24 5.72 l6.24 -5.72 h9.36%22 fill=%22none%22 stroke=%22%23E0313F%22 stroke-width=%223.96%22 stroke-linecap=%22round%22 stroke-linejoin=%22round%22/%3E%3Ccircle cx=%2248%22 cy=%2246.7%22 r=%222.16%22 fill=%22%23E0313F%22/%3E%3C/svg%3E";
var LOGO_BIG="data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 96 96%22%3E%3Crect x=%22.5%22 y=%22.5%22 width=%2295%22 height=%2295%22 rx=%2221.5%22 fill=%22%23111113%22 stroke=%22%23ffffff%22 stroke-opacity=%22.14%22/%3E%3Cdefs%3E%3CclipPath id=%22c518%22%3E%3Ccircle cx=%2248%22 cy=%2238%22 r=%2218.5%22/%3E%3C/clipPath%3E%3C/defs%3E%3Cg clip-path=%22url(%23c518)%22 transform=%22rotate(-10 48 38)%22%3E%3Crect x=%2216%22 y=%2244%22 width=%2264%22 height=%2240%22 fill=%22%23ffffff%22 fill-opacity=%22.18%22/%3E%3Cline x1=%2218%22 y1=%2244%22 x2=%2278%22 y2=%2244%22 stroke=%22%23fff%22 stroke-width=%221.5%22/%3E%3C/g%3E%3Ccircle cx=%2248%22 cy=%2238%22 r=%2220%22 fill=%22none%22 stroke=%22%23fff%22 stroke-width=%223%22/%3E%3Cpath d=%22M36 37 h7.2 l4.8 4.4 l4.8 -4.4 h7.2%22 fill=%22none%22 stroke=%22%23E0313F%22 stroke-width=%223.3%22 stroke-linecap=%22round%22 stroke-linejoin=%22round%22/%3E%3Ccircle cx=%2248%22 cy=%2237%22 r=%221.8%22 fill=%22%23E0313F%22/%3E%3Ctext x=%2248%22 y=%2280%22 text-anchor=%22middle%22 fill=%22%23fff%22 font-family=%22-apple-system,BlinkMacSystemFont,'SF Pro Text','Helvetica Neue',Helvetica,Arial,sans-serif%22 font-size=%2211.5%22 font-weight=%22600%22%3EInstructor%3C/text%3E%3C/svg%3E";
var CK=COMP.map(function(c){return c.k;});
var CMAP={}; COMP.forEach(function(c){CMAP[c.k]=c;});
var GL={1:'Unsafe situation',2:'Not an unsafe situation',3:'Safe situation',4:'Safe situation',5:'Enhanced safety, effectiveness and efficiency'};
var GS={1:'Unsafe',2:'Not unsafe',3:'Safe',4:'Safe',5:'Enhanced'};
var RES={C:['Competente','ok'],RT:['Requiere entrenamiento adicional','warn'],INC:['Incompleto','bad'],'':['Sin resultado','']};

/* ============ Iconos ============ */
function ic(p,extra){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" '+(extra||'')+'>'+p+'</svg>';}
var I={
 home:ic('<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20h5v-6h4v6h5V9.5"/>'),
 eval:ic('<rect x="5" y="3.5" width="14" height="17.5" rx="2.5"/><path d="M9 3.5h6v3H9z"/><path d="m9 13 2 2 4-4.5"/>'),
 people:ic('<circle cx="9" cy="8" r="3.2"/><path d="M3.5 19.5c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5"/><circle cx="17" cy="9" r="2.4"/><path d="M15.8 14.3c2.4-.3 4.3 1.3 4.8 4.2"/>'),
 book:ic('<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M4 20.5A2.5 2.5 0 0 1 6.5 18H20v3H6.5"/>'),
 chart:ic('<path d="M4 20V4"/><path d="M4 20h16"/><path d="M8 16v-4M12 16V8M16 16v-6"/>'),
 spark:ic('<path d="M12 3.5 13.8 9l5.7 1.8-5.7 1.9L12 18.5l-1.8-5.8L4.5 10.8 10.2 9z"/><path d="M19 3v3M17.5 4.5h3"/>'),
 gear:ic('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'),
 more:ic('<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>'),
 plus:ic('<path d="M12 5v14M5 12h14"/>'),
 chev:ic('<path d="m9 6 6 6-6 6"/>','class="chev"'),
 back:ic('<path d="m15 6-6 6 6 6"/>'),
 x:ic('<path d="M6 6l12 12M18 6 6 18"/>'),
 check:ic('<path d="m5 12.5 4.5 4.5L19 7.5"/>','stroke-width="2.6"'),
 search:ic('<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4-4"/>'),
 doc:ic('<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>'),
 down:ic('<path d="M12 4v11M7 10.5l5 5 5-5"/><path d="M5 20h14"/>'),
 up:ic('<path d="M12 20V9M7 13.5l5-5 5 5"/><path d="M5 4h14"/>'),
 grid:ic('<rect x="3.5" y="3.5" width="7" height="7" rx="1.8"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.8"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.8"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.8"/>'),
 cam:ic('<path d="M4 8.5h3l1.5-2.5h7L17 8.5h3v11H4z"/><circle cx="12" cy="13.5" r="3.2"/>'),
 cal:ic('<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>'),
 bell:ic('<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>'),
 clock:ic('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'),
 cloud:ic('<path d="M7 18.5h10.5a4 4 0 0 0 .6-7.95A6 6 0 0 0 6.6 9.1 4.7 4.7 0 0 0 7 18.5z"/>'),
 pen:ic('<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/>'),
 trash:ic('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>'),
 send:ic('<path d="M5 12h13M13 6l6 6-6 6"/>','stroke-width="2.2"'),
 sign:ic('<path d="M3 17c3-1 4-9 6-9s0 9 2 9 3-4 4.5-4 1 3 2.5 3H21"/><path d="M3 21h18"/>'),
 alert:ic('<path d="M12 4 2.8 19.5h18.4z"/><path d="M12 10v4.5M12 17.2v.1"/>'),
 plane:ic('<path d="M10.5 13.5 3 11l1.5-1.5 8 .5 4-4.5c1-1 2.6-1.3 3.3-.6.7.7.4 2.3-.6 3.3l-4.5 4 .5 8L14 21.5 11.5 14l-3 2.5v3L7 21l-1-3.5L2.5 16.5 4 15h3z"/>')
};

/* ============ Utilidades ============ */
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function uid(p){return (p||'')+Date.now().toString(36)+Math.random().toString(36).slice(2,7);}
function today(){var d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
var MES=['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
function fdate(s){if(!s)return '—';var p=String(s).split('-');if(p.length<3)return s;return +p[2]+' '+MES[+p[1]-1]+' '+p[0];}
function fdateShort(s){var p=String(s||'').split('-');return p.length<3?s:(+p[2]+' '+MES[+p[1]-1]);}
function ftime(ms){if(!ms)return '—';var d=new Date(ms);return d.getDate()+' '+MES[d.getMonth()]+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');}
function initials(n){return String(n||'?').split(/\s+/).filter(Boolean).slice(0,2).map(function(w){return w[0];}).join('').toUpperCase();}
function avg(a){a=a.filter(function(x){return x>0;});return a.length?a.reduce(function(s,x){return s+x;},0)/a.length:0;}
function f1(x){return x?x.toFixed(1).replace('.',','):'—';}
function gcls(g){return 'gc'+(g?Math.max(1,Math.min(5,Math.round(g))):0);}
function gvar(g){return g?'var(--g'+Math.max(1,Math.min(5,Math.round(g)))+')':'var(--line)';}
function live(coll){var o=S[coll]||{};return Object.keys(o).map(function(k){return o[k];}).filter(function(r){return r&&!r.deleted;});}
function pilot(id){var p=S.trainees[id];return p&&!p.deleted?p:null;}
function pname(id){var p=pilot(id);return p?p.name:'Trainee eliminado';}
function sortByDate(a,b){return (a.date||'').localeCompare(b.date||'')||(a.updatedAt||0)-(b.updatedAt||0);}
function seats(s){return s.mode==='crew'?['cm1','cm2']:['cm1'];}
function pilotSessions(pid){return live('sessions').filter(function(s){return seats(s).some(function(x){return s.pilots[x]===pid;});}).sort(sortByDate);}
function seatOf(s,pid){return seats(s).filter(function(x){return s.pilots[x]===pid;})[0];}
function sessAvg(s,seat){var g=(s.grades||{})[seat]||{};return avg(CK.map(function(k){return g[k]?g[k].g:0;}));}
function graded(s,seat){var g=(s.grades||{})[seat]||{};return CK.filter(function(k){return g[k]&&(g[k].g||g[k].no);}).length;}
function gtxt(e){return !e?'–':e.no?'N/O':(e.g||'–');}
function phaseName(p){var m={EVAL:'Evaluation phase',MT:'Manoeuvres training',SBT:'Scenario-based training',LOFT:'Line oriented flight training',LOE:'Line oriented evaluation','LINE':'Line check'};return m[p]||p;}

/* ============ Almacén local-first + sincronización ============ */
var LS='bitacora-ebt-v1';
var DEF_SETTINGS={instructor:'',instructorId:'',ieRef:'',sbProject:'japjyiccjwnhbfpwqtti',emLastSend:0,emLastCheck:0,pin:'',photo:'',rank:'',fleet:'',quals:'',license:'',
  flightPhases:['Pre-vuelo','Despegue y ascenso','Crucero','Descenso y aproximación','Aterrizaje','Post-vuelo'],operator:'',module:'M1 2S-2026',
  modules:['M6 1S-2026','M1 2S-2026','M2 1S-2027','M3 2S-2027','M4 1S-2028','M5 2S-2028','M6 1S-2029'],
  phases:['EVAL','MT','SBT','LOFT','LOE','LINE'],fleets:['A320','B787'],
  phrases:['Adecuado manejo.','Requiere refuerzo.','Fortaleza destacada.','Mejoró respecto a la sesión anterior.','Aplicó SOP de forma oportuna.','Monitoreo tardío; requirió intervención.','Buena gestión del evento bajo presión.'],
  sims:['FFS A320 #1','FFS A320 #2','FFS B787','FTD A320'],
  debPhrases:['La tripulación gestionó los eventos conforme a SOP y con buena coordinación.','Se identifican oportunidades de mejora en el monitoreo y en la comunicación de desviaciones.','Se recomienda reforzar en el próximo módulo: ','Resultado competente; sin hallazgos que requieran entrenamiento adicional.','El debriefing se realizó de forma facilitada; la tripulación identificó por sí misma las áreas de mejora.']};
var S;
var COLLS=['trainees','sessions','evals','schedule','notices'];
function blank(){return {trainees:{},sessions:{},evals:{},schedule:{},notices:{},members:{},invites:[],org:{},owner:'',me:null,outbox:{},settings:JSON.parse(JSON.stringify(DEF_SETTINGS)),ui:{route:'inicio'},lastSync:0};}
function load(){
  try{var raw=localStorage.getItem(LS);if(raw){var o=JSON.parse(raw);var b=blank();for(var k in b){if(o[k]==null)o[k]=b[k];}for(var j in DEF_SETTINGS){if(o.settings[j]==null)o.settings[j]=DEF_SETTINGS[j];}COLLS.forEach(function(c){var m=o[c]||{};Object.keys(m).forEach(function(k){if(m[k]&&m[k].example){delete m[k];delete o.outbox[c+'/'+k];}});});if(Array.isArray(o.settings.sims))o.settings.sims=o.settings.sims.map(function(x){return String(x).replace(/^CAE Bogot\u00e1 \u00b7 /,'');});return o;}}catch(e){}
  return blank();
}
var persistT=null;
function persist(){clearTimeout(persistT);persistT=setTimeout(function(){try{localStorage.setItem(LS,JSON.stringify(S));}catch(e){toast('No se pudo guardar en este dispositivo: almacenamiento lleno');}},150);}
function put(coll,rec,quiet){rec.updatedAt=Date.now();rec.by=S.settings.instructor;S[coll][rec.id]=rec;S.outbox[coll+'/'+rec.id]=1;persist();scheduleFlush();if(!quiet)render();}
function remove(coll,id){var r=S[coll][id];if(!r)return;r.deleted=true;put(coll,r);}

var ROLE='instructor',ME=null;function realCoord(){return ROLE==='coord';}function isCoord(){return ROLE==='coord'&&!(S&&S.ui&&S.ui.viewAs==='instructor');}function roleLabel(){return isCoord()?'Manager EBT':'Instructor';}
var DB=null, dbState='connecting', flushing=false, flushT=null, unsub=[];
function online(){return navigator.onLine!==false;}
function pending(){return Object.keys(S.outbox).length;}
function scheduleFlush(){clearTimeout(flushT);flushT=setTimeout(flush,700);}
async function flush(){
  if(!DB||!online()||flushing)return;
  var keys=Object.keys(S.outbox);if(!keys.length)return;
  flushing=true;renderSync();
  for(var i=0;i<keys.length;i++){
    var key=keys[i],p=key.split('/'),rec=S[p[0]]&&S[p[0]][p[1]];
    if(!rec){delete S.outbox[key];continue;}
    try{await DB.doc(key).set(JSON.parse(JSON.stringify(rec)));delete S.outbox[key];}
    catch(e){if(e&&(e.code==='not_granted'||e.code==='invalid_argument')){dbState='readonly';}break;}
  }
  S.lastSync=Date.now();flushing=false;persist();renderSync();
  if(Object.keys(S.outbox).length&&dbState==='on')scheduleFlush();
}
function mergeRemote(coll,snap){
  var changed=false;
  snap.docs.forEach(function(d){
    var r=d.data();if(!r||r.example)return;r.id=r.id||d.id;
    var l=S[coll][d.id];
    if(S.outbox[coll+'/'+d.id]&&l&&(l.updatedAt||0)>=(r.updatedAt||0))return;
    if(!l||(r.updatedAt||0)>(l.updatedAt||0)){S[coll][d.id]=r;changed=true;}
  });
  if(changed){S.lastSync=Date.now();persist();softRender();}
  if(coll==='instructors'&&typeof checkInvite==='function')checkInvite();
}
var softT=null;
function softRender(){clearTimeout(softT);softT=setTimeout(function(){var a=document.activeElement;if(a&&(a.tagName==='TEXTAREA'||a.tagName==='INPUT'))return renderSync();render();},250);}
async function connect(){
  try{
    if(!window.claude||!window.claude.use){dbState='off';ROLE='coord';renderSync();render();return;}
    try{var u=await window.claude.use('user');if(u){ROLE=(u.canEdit&&u.canEdit())?'coord':'instructor';try{ME=await u.me();if(ME&&ME.name&&!S.settings.instructor){S.settings.instructor=ME.name;persist();}}catch(e){}}}catch(e){}
    render();
    var db=await window.claude.use('db');
    if(!db){dbState='off';renderSync();return;}
    DB=db;dbState='on';renderSync();
    COLLS.forEach(function(c){
      unsub.push(DB.collection(c).onSnapshot(function(s){mergeRemote(c,s);},function(e){dbState='error';renderSync();}));
    });
    flush();
  }catch(e){dbState='off';renderSync();}
}
function syncInfo(){
  var n=pending();
  if(!online())return {c:'warn',t:'Sin conexión',d:n?n+' cambio'+(n>1?'s':'')+' por subir':'Trabajando en este dispositivo'};
  if(dbState==='connecting')return {c:'',t:'Conectando…',d:'Base de datos compartida'};
  if(dbState==='off')return {c:'',t:'Solo este dispositivo',d:'Abre la app en Claude para sincronizar'};
  if(dbState==='readonly')return {c:'warn',t:'Solo lectura',d:'Tu acceso no permite subir cambios'};
  if(dbState==='error')return {c:'bad',t:'Error de sincronización',d:n+' pendiente'+(n===1?'':'s')};
  if(flushing)return {c:'acc',t:'Sincronizando…',d:n+' en cola'};
  if(n)return {c:'warn',t:n+' cambio'+(n>1?'s':'')+' pendiente'+(n>1?'s':''),d:'Se suben automáticamente'};
  return {c:'ok',t:'Sincronizado',d:S.lastSync?'Última: '+ftime(S.lastSync):'Base de datos al día'};
}
function syncHTML(){var i=syncInfo();var col={ok:'var(--ok)',warn:'var(--warn)',bad:'var(--bad)',acc:'var(--accent)'}[i.c]||'var(--faint)';return '<div class="sync"><span class="dot" style="background:'+col+';flex:none"></span><div style="min-width:0"><div>'+esc(i.t)+'</div><div class="tiny muted" style="font-weight:500">'+esc(i.d)+'</div></div></div>';}
function renderSync(){document.querySelectorAll('[data-sync]').forEach(function(el){el.innerHTML=syncHTML();});var i=syncInfo(),col={ok:'var(--ok)',warn:'var(--warn)',bad:'var(--bad)',acc:'var(--accent)'}[i.c]||'var(--faint)';document.querySelectorAll('[data-sync-pill]').forEach(function(el){el.innerHTML='<span class="dot" style="background:'+col+'"></span>'+esc(i.t);el.title=i.d;});}
window.addEventListener('online',function(){renderSync();flush();});
var rzT=null;window.addEventListener('resize',function(){clearTimeout(rzT);rzT=setTimeout(function(){if(S&&S.ui.route==='evaluar'&&typeof render==='function')render();},200);});
window.addEventListener('offline',renderSync);
