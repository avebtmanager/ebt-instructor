/* ============ Supabase: cliente mínimo sin dependencias (auth + REST + funciones) ============ */
var SB={url:EI_CONFIG.url.replace(/\/$/,''),key:EI_CONFIG.key,session:null,refreshing:null};
var SBK='ei-auth-v1';
LS='ei-data-v1';
function sbLoad(){try{SB.session=JSON.parse(localStorage.getItem(SBK)||'null');}catch(e){SB.session=null;}}
function sbStore(){try{if(SB.session)localStorage.setItem(SBK,JSON.stringify(SB.session));else localStorage.removeItem(SBK);}catch(e){}}
function myId(){return SB.session&&SB.session.user?SB.session.user.id:'';}
function myEmail(){return SB.session&&SB.session.user?(SB.session.user.email||''):'';}
function sbError(status,body){var msg=body&&(body.msg||body.message||body.error_description||body.error)||('HTTP '+status);var e=new Error(msg);e.status=status;e.code=body&&(body.code||body.error_code||body.error)||'';e.body=body;return e;}
function isPermErr(e){return e&&(e.status===401||e.status===403||e.code==='42501'||e.code==='23503'||e.code==='23505'||e.code==='23514'||e.code==='22P02');}
async function sbRaw(path,opts){
  opts=opts||{};var h=Object.assign({'apikey':SB.key},opts.headers||{});if(opts.body!=null)h['Content-Type']='application/json';
  if(opts.auth!==false){var t=await sbToken();if(t)h.Authorization='Bearer '+t;}
  var r;try{r=await fetch(SB.url+path,{method:opts.method||'GET',headers:h,body:opts.body!=null?JSON.stringify(opts.body):undefined});}
  catch(e){var ne=new Error('Sin conexión');ne.offline=true;throw ne;}
  var txt=await r.text(),data=null;try{data=txt?JSON.parse(txt):null;}catch(e){data=txt;}
  if(!r.ok)throw sbError(r.status,data);
  return data;
}
function sbSetSession(d){
  if(!d||!d.access_token)return;
  var exp=d.expires_at?d.expires_at*1000:Date.now()+(d.expires_in||3600)*1000;
  SB.session={access_token:d.access_token,refresh_token:d.refresh_token||(SB.session&&SB.session.refresh_token),expires_at:exp,user:d.user||(SB.session&&SB.session.user)||null};
  sbStore();
}
async function sbToken(){
  var s=SB.session;if(!s)return null;
  if(s.expires_at-60000>Date.now())return s.access_token;
  if(!s.refresh_token)return s.access_token;
  if(!SB.refreshing)SB.refreshing=(async function(){
    try{var d=await sbRaw('/auth/v1/token?grant_type=refresh_token',{method:'POST',auth:false,body:{refresh_token:s.refresh_token}});sbSetSession(d);}
    catch(e){if(!e.offline&&(e.status===400||e.status===401)){SB.session=null;sbStore();sbExpired();}}
    finally{SB.refreshing=null;}
  })();
  await SB.refreshing;return SB.session?SB.session.access_token:null;
}
async function sbSignIn(email,password){var d=await sbRaw('/auth/v1/token?grant_type=password',{method:'POST',auth:false,body:{email:email,password:password}});sbSetSession(d);return d;}
async function sbRecover(email){return sbRaw('/auth/v1/recover?redirect_to='+encodeURIComponent(appUrl()),{method:'POST',auth:false,body:{email:email}});}
async function sbSetPassword(pw){var u=await sbRaw('/auth/v1/user',{method:'PUT',body:{password:pw}});if(SB.session){SB.session.user=u;sbStore();}return u;}
async function sbSignOut(){try{await sbRaw('/auth/v1/logout',{method:'POST'});}catch(e){}SB.session=null;sbStore();}
async function sbUser(token){return sbRaw('/auth/v1/user',{auth:false,headers:{Authorization:'Bearer '+token}});}
function appUrl(){return location.origin+location.pathname;}
async function sbSelect(table,q){return sbRaw('/rest/v1/'+table+'?'+(q||'select=*'));}
async function sbUpsert(table,rows){return sbRaw('/rest/v1/'+table+'?on_conflict='+(table==='ei_members'?'user_id':'id'),{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:rows});}
async function sbPatch(table,filter,body){return sbRaw('/rest/v1/'+table+'?'+filter,{method:'PATCH',headers:{Prefer:'return=minimal'},body:body});}
async function sbDelete(table,filter){return sbRaw('/rest/v1/'+table+'?'+filter,{method:'DELETE',headers:{Prefer:'return=minimal'}});}
async function sbRpc(fn,args){return sbRaw('/rest/v1/rpc/'+fn,{method:'POST',body:args||{}});}
async function sbFn(name,body){return sbRaw('/functions/v1/'+name,{method:'POST',body:body||{}});}

/* ============ Identificadores ============ */
function uuid(){if(window.crypto&&crypto.randomUUID)return crypto.randomUUID();var b=new Uint8Array(16);(window.crypto||{getRandomValues:function(a){for(var i=0;i<a.length;i++)a[i]=Math.random()*256|0;return a;}}).getRandomValues(b);b[6]=b[6]&15|64;b[8]=b[8]&63|128;var h=Array.from(b,function(x){return x.toString(16).padStart(2,'0');}).join('');return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20);}
function uid(){return uuid();}
function isUuid(v){return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(v||''));}
function ts(v){var t=Date.parse(v||'');return isNaN(t)?0:t;}
function iso(ms){return ms?new Date(ms).toISOString():null;}

/* ============ Miembros, organización y perfil ============ */
function members(){return S.members||{};}
function memberName(id){var m=members()[id];return m?(m.full_name||m.email||'Instructor'):'';}
function memberByName(n){n=String(n||'').trim().toLowerCase();if(!n)return null;var ms=members();var hit=null;Object.keys(ms).forEach(function(k){var m=ms[k];if(!hit&&((m.full_name||'').toLowerCase()===n||(m.ie_code||'').toLowerCase()===n||(m.email||'').toLowerCase()===n))hit=m;});return hit;}
function isMine(r){return r&&((r.iid&&r.iid===myId())||(!r.iid&&r.instructor&&r.instructor===S.settings.instructor));}
function ORG(k,d){var o=S.org||{};return o[k]==null?d:o[k];}
var ORG_MAP={phrases:'phrases',debPhrases:'debriefPhrases',phases:'phases',fleets:'fleets',modules:'modules',flightPhases:'flightPhases',sims:'sims',module:'currentModule'};
var PROFILE_MAP={instructor:'full_name',instructorId:'ie_code',rank:'rank',fleet:'fleet',quals:'quals',license:'license'};
function applyOrg(cfg){
  S.org=cfg||{};
  Object.keys(ORG_MAP).forEach(function(k){var v=S.org[ORG_MAP[k]];if(v!=null&&(!Array.isArray(v)||v.length))S.settings[k]=JSON.parse(JSON.stringify(v));});
  S.orgSnap=orgFromSettings();applyScale();
}
function orgFromSettings(){var o=JSON.parse(JSON.stringify(S.org||{}));Object.keys(ORG_MAP).forEach(function(k){o[ORG_MAP[k]]=S.settings[k];});return o;}
function profileFromSettings(){var p={};Object.keys(PROFILE_MAP).forEach(function(k){p[PROFILE_MAP[k]]=S.settings[k]||null;});p.full_name=p.full_name||'';return p;}
function applyMember(m){
  S.me=m||null;
  if(!m){ROLE='instructor';return;}
  ROLE=m.role==='manager'?'coord':'instructor';
  Object.keys(PROFILE_MAP).forEach(function(k){var v=m[PROFILE_MAP[k]];if(v!=null&&v!=='')S.settings[k]=v;});
  if(!S.settings.instructor)S.settings.instructor=m.email||myEmail();
  S.profileSnap=JSON.stringify(profileFromSettings());
}
function hexRgb(h){var m=String(h||'').match(/^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i);return m?[parseInt(m[1],16),parseInt(m[2],16),parseInt(m[3],16)]:null;}
function applyScale(){
  var sc=ORG('scale',null);if(!sc)return;var css='';
  [1,2,3,4,5].forEach(function(g){var e=sc[g]||sc[String(g)];if(!e)return;if(e.label)GL[g]=e.label;if(e.short)GS[g]=e.short;var rgb=hexRgb(e.color);if(rgb){RGB[g]=rgb;css+='--g'+g+':'+e.color+';';}});
  var st=document.getElementById('ei-scale');if(!st){st=document.createElement('style');st.id='ei-scale';document.head.appendChild(st);}
  st.textContent=css?':root,:root[data-theme="dark"]{'+css+'}@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){'+css+'}}':'';
}

/* ============ Conversión entre la app y las tablas ============ */
var CODEC={
  trainees:{table:'ei_trainees',
    to:function(r){return {id:r.id,full_name:(r.name||'').trim()||'Sin nombre',emp_no:r.emp?String(r.emp).trim():null,rank:r.rank||null,fleet:r.fleet||null,base:r.base||null,notes:r.notes||'',active:!r.deleted};},
    from:function(x){return {id:x.id,name:x.full_name,emp:x.emp_no||'',rank:x.rank||'',fleet:x.fleet||'',base:x.base||'',notes:x.notes||'',deleted:x.active===false,updatedAt:ts(x.updated_at),createdBy:x.created_by||''};}},
  evals:{table:'ei_formats',
    to:function(t){return {id:t.id,name:(t.name||'').trim()||'Plantilla',fleet:t.fleet||null,module:t.module||null,phase:t.phase||null,session_label:t.em&&t.em.session||null,events:t.events||[],target_comps:t.targets||[],notes:t.note||'',source:t.em||null,active:!t.deleted};},
    from:function(x){return {id:x.id,name:x.name,fleet:x.fleet||'',module:x.module||'',phase:x.phase||'',events:x.events||[],targets:x.target_comps||[],note:x.notes||'',em:x.source||null,deleted:x.active===false,updatedAt:ts(x.updated_at)};}},
  sessions:{table:'ei_sessions',
    to:function(s){var d=JSON.parse(JSON.stringify(s));['id','status','date','fleet','module','phase','templateId','mode','pilots','hash','signedAt','updatedAt','by','deleted','iid'].forEach(function(k){delete d[k];});
      var st=s.status==='signed'?(s.deleted?'void':'signed'):'draft';
      return {id:s.id,status:st,session_date:s.date||today(),fleet:s.fleet||null,module:s.module||null,phase:s.phase||null,format_id:isUuid(s.templateId)?s.templateId:null,mode:s.mode==='crew'?'crew':'single',
        cm1:isUuid(s.pilots&&s.pilots.cm1)?s.pilots.cm1:null,cm2:s.mode==='crew'&&isUuid(s.pilots&&s.pilots.cm2)?s.pilots.cm2:null,instructor_id:s.iid||myId(),data:d,hash:s.hash||null,signed_at:iso(s.signedAt)};},
    from:function(x){var s=Object.assign({},x.data||{});s.id=x.id;s.status=x.status==='draft'?'draft':'signed';s.deleted=x.status==='void';s.date=x.session_date;s.fleet=x.fleet||'';s.module=x.module||'';s.phase=x.phase||'';s.templateId=x.format_id||'';s.mode=x.mode;s.pilots={cm1:x.cm1||'',cm2:x.cm2||''};
      s.hash=x.hash||'';s.signedAt=ts(x.signed_at);s.iid=x.instructor_id;s.updatedAt=ts(x.updated_at);s.grades=s.grades||{cm1:{},cm2:{}};s.result=s.result||{};s.sig=s.sig||{};s.events=s.events||[];s.focus=s.focus||{};if(!s.instructor)s.instructor=memberName(x.instructor_id);return s;}},
  schedule:{table:'ei_schedule',
    to:function(a){var iid=a.iid||(memberByName(a.instructor)||{}).user_id||null;return {id:a.id,slot_date:a.date,start_time:a.time||null,end_time:a.end||null,fleet:a.fleet||null,module:a.module||null,phase:a.phase||null,sim:a.sim||null,cm1:isUuid(a.cm1)?a.cm1:null,cm2:isUuid(a.cm2)?a.cm2:null,instructor_id:iid,status:a.status||'scheduled',note:a.note||'',session_id:isUuid(a.sessionId)?a.sessionId:null};},
    from:function(x){return {id:x.id,date:x.slot_date,time:x.start_time||'',end:x.end_time||'',fleet:x.fleet||'',module:x.module||'',phase:x.phase||'',sim:x.sim||'',cm1:x.cm1||'',cm2:x.cm2||'',iid:x.instructor_id||'',instructor:memberName(x.instructor_id),status:x.status,note:x.note||'',sessionId:x.session_id||'',updatedAt:ts(x.updated_at)};}},
  notices:{table:'ei_notices',
    to:function(n){return {id:n.id,kind:n.kind||'general',title:(n.title||'').trim()||'Aviso',body:n.body||'',schedule_id:isUuid(n.scheduleId)?n.scheduleId:null};},
    from:function(x){return {id:x.id,kind:x.kind,title:x.title,body:x.body||'',scheduleId:x.schedule_id||'',ts:ts(x.created_at),by:memberName(x.created_by),authorId:x.created_by||'',updatedAt:ts(x.updated_at)};}}
};
var PUSH_ORDER=['trainees','evals','sessions','schedule','notices'];

/* ============ Sincronización: primero el dispositivo, luego la nube ============ */
var dbState='connecting',flushing=false,flushT=null,pullT=null,lastErr='';
function online(){return navigator.onLine!==false;}
function pending(){return Object.keys(S.outbox||{}).length+(S.orgDirty?1:0)+(S.profileDirty?1:0);}
function scheduleFlush(){clearTimeout(flushT);flushT=setTimeout(function(){flush();},800);}
var _persist0=persist;
persist=function(){_persist0();if(SB.session&&!LOCKED){var o=JSON.stringify(orgFromSettings()),p=JSON.stringify(profileFromSettings());if(isCoord()&&S.orgSnap&&o!==JSON.stringify(S.orgSnap)){S.orgDirty=true;scheduleFlush();}if(S.me&&p!==S.profileSnap){S.profileDirty=true;scheduleFlush();}}};
async function flush(){
  if(!SB.session||!online()||flushing||LOCKED)return;
  if(!pending())return;
  flushing=true;renderSync();
  try{
    var keys=Object.keys(S.outbox).sort(function(a,b){return PUSH_ORDER.indexOf(a.split('/')[0])-PUSH_ORDER.indexOf(b.split('/')[0]);});
    for(var i=0;i<keys.length;i++){
      var key=keys[i],p=key.split('/'),coll=p[0],id=p[1],rec=S[coll]&&S[coll][id],C=CODEC[coll];
      if(!C){delete S.outbox[key];continue;}
      try{
        if(!rec){delete S.outbox[key];continue;}
        if(coll==='sessions'&&rec.deleted&&rec.status!=='signed'){await sbDelete(C.table,'id=eq.'+id);delete S.sessions[id];}
        else if((coll==='schedule'||coll==='notices')&&rec.deleted){await sbDelete(C.table,'id=eq.'+id);delete S[coll][id];}
        else await sbUpsert(C.table,[C.to(rec)]);
        delete S.outbox[key];
      }catch(e){
        if(e.offline)throw e;
        if(isPermErr(e)){delete S.outbox[key];lastErr=permMsg(coll,e);toast(lastErr);S.needPull=true;}
        else{lastErr=e.message;throw e;}
      }
    }
    if(S.orgDirty&&isCoord()){var cfg=orgFromSettings();await sbPatch('ei_settings','id=eq.main',{config:cfg,updated_by:myId()});S.org=cfg;S.orgSnap=cfg;S.orgDirty=false;}
    else S.orgDirty=false;
    if(S.profileDirty&&S.me){var pr=profileFromSettings();await sbPatch('ei_members','user_id=eq.'+myId(),pr);Object.assign(S.me,pr);S.profileSnap=JSON.stringify(pr);S.profileDirty=false;}
    dbState='on';lastErr='';S.lastSync=Date.now();
  }catch(e){dbState=e.offline?'offline':'error';}
  finally{flushing=false;persist0();renderSync();if(S.needPull){S.needPull=false;pull();}else if(pending()&&dbState==='on')scheduleFlush();}
}
function persist0(){_persist0();}
function permMsg(coll,e){
  if(coll==='sessions')return e.code==='42501'?'La evaluación ya estaba firmada en el servidor; se mostró la versión guardada.':'No se pudo guardar la evaluación: '+e.message;
  if(coll==='notices')return 'Tu cuenta no puede publicar ese aviso.';
  if(coll==='schedule')return 'Solo el Manager modifica esa sesión de la agenda.';
  if(coll==='evals')return 'Solo el Manager modifica las plantillas.';
  if(coll==='trainees'&&e.code==='23505')return 'Ya existe un trainee con ese número de empleado.';
  return 'Cambio rechazado por el servidor: '+e.message;
}
async function pull(){
  if(!SB.session||!online())return;
  try{
    var res=await Promise.all([
      sbSelect('ei_members','select=*'),sbSelect('ei_settings','select=*&id=eq.main'),
      sbSelect('ei_trainees','select=*'),sbSelect('ei_formats','select=*'),sbSelect('ei_sessions','select=*&order=session_date.asc'),
      sbSelect('ei_schedule','select=*'),sbSelect('ei_notices','select=*&order=created_at.desc&limit=300'),
      isCoordReal()?sbSelect('ei_invites','select=*&accepted_at=is.null&order=created_at.desc'):Promise.resolve([])
    ]);
    var mem={};res[0].forEach(function(m){mem[m.user_id]=m;});S.members=mem;
    var me=mem[myId()];
    if(!me){dbState='nomember';LOCKED=true;AUTH.mode='noaccess';render();return;}
    if(me.status!=='active'){dbState='nomember';LOCKED=true;AUTH.mode='inactive';render();return;}
    var wasLocked=LOCKED;applyMember(me);
    if(res[1][0])applyOrg(res[1][0].config);
    S.invites=res[7]||[];
    var tables={trainees:res[2],evals:res[3],sessions:res[4],schedule:res[5],notices:res[6]};
    Object.keys(tables).forEach(function(coll){
      var C=CODEC[coll],next={};tables[coll].forEach(function(row){var r=C.from(row);next[r.id]=r;});
      Object.keys(S[coll]||{}).forEach(function(id){if(S.outbox[coll+'/'+id])next[id]=S[coll][id];});
      S[coll]=next;
    });
    dbState='on';S.lastSync=Date.now();lastErr='';
    if(wasLocked&&AUTH.mode!=='setpw'){LOCKED=false;}
    persist0();
    var a=document.activeElement;if(a&&(a.tagName==='TEXTAREA'||a.tagName==='INPUT')&&!LOCKED)renderSync();else render();
    if(pending())flush();
  }catch(e){
    if(e.offline){dbState='offline';}else if(e.status===401){sbExpired();}else{dbState='error';lastErr=e.message;}
    renderSync();
  }
}
function isCoordReal(){var m=S.members&&S.members[myId()];return m?m.role==='manager':ROLE==='coord';}
function realCoord(){return ROLE==='coord';}
async function connect(){
  if(!SB.session){dbState='off';return;}
  dbState=online()?'connecting':'offline';renderSync();
  await pull();
  clearInterval(pullT);pullT=setInterval(function(){if(!document.hidden)pull();},90000);
}
function sbExpired(){if(LOCKED)return;LOCKED=true;AUTH.mode='login';AUTH.err='Tu sesión expiró. Vuelve a ingresar.';AUTH.email=myEmail()||AUTH.email;render();}
document.addEventListener('visibilitychange',function(){if(!document.hidden&&SB.session&&!LOCKED){pull();}});
window.addEventListener('online',function(){if(SB.session)pull();});
function syncInfo(){
  var n=pending();
  if(!online()||dbState==='offline')return {c:'warn',t:'Sin conexión',d:n?n+' cambio'+(n>1?'s':'')+' por subir':'Trabajando en este dispositivo'};
  if(dbState==='connecting')return {c:'',t:'Conectando…',d:'Base de datos EBT'};
  if(dbState==='off')return {c:'',t:'Sin sesión',d:'Inicia sesión para sincronizar'};
  if(dbState==='error')return {c:'bad',t:'Error de sincronización',d:lastErr||(n+' pendiente'+(n===1?'':'s'))};
  if(flushing)return {c:'acc',t:'Sincronizando…',d:n+' en cola'};
  if(n)return {c:'warn',t:n+' cambio'+(n>1?'s':'')+' pendiente'+(n>1?'s':''),d:'Se suben automáticamente'};
  return {c:'ok',t:'Sincronizado',d:S.lastSync?'Última: '+ftime(S.lastSync):'Base de datos al día'};
}
