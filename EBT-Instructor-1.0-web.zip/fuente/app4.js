/* ============ Asistente IA ============ */
var SAMPLE=null,sampleReady=false,aiBusy=false,aiCtl=null;
var PRE='Eres el asistente de un instructor de EBT (Evidence-Based Training) de pilotos de línea aérea. Marco: 9 competencias OACI Doc 9995 / EASA AMC1 ORO.FC.231 con numeración de OB 0–8 (KNO 0, APK 1, COM 2, FPA 3, FPM 4, LTW 5, PSD 6, SAW 7, WLM 8). Escala de calificación 1–5 (1 No satisfactorio, 2 Mínimo aceptable, 3 Adecuado, 4 Bueno, 5 Ejemplar). Fases: EVAL, MT, SBT, LOFT, LOE, Line check.\nReglas: responde en español claro y conciso; conserva la terminología técnica en inglés (EBT, OB, EVAL, MT, SBT, TEM, debriefing); usa solo los datos del contexto y no inventes calificaciones, eventos ni personas; cita los OB por código (p. ej. OB 7.2); si falta información, dilo. Sin markdown pesado: usa párrafos cortos y viñetas simples con "•".';
function ctxText(ctx){
  if(ctx&&ctx.indexOf('p:')===0){var p=pilot(ctx.slice(2));if(!p)return '';
    var ss=pilotSessions(p.id).filter(function(s){return s.status==='signed';});
    var w=weaknesses(p.id);
    var fal=(w.comp.length?'Competencias con grado 1–2: '+w.comp.map(function(c){return c.k+' ('+c.n+' vez/veces, última '+c.phase+' '+c.last+' grado '+c.lastG+')';}).join('; ')+'. ':'Sin competencias en grado 1–2. ')+
      (w.obs.length?'OB deficientes recurrentes: '+w.obs.map(function(o){return 'OB '+o.o+' ×'+o.n;}).join(', ')+'. ':'')+
      (w.events.length?'Maniobras/procedimientos asociados a bajo desempeño: '+w.events.map(function(e){return e.t+' ['+Object.keys(e.ks).join(' ')+'] ×'+e.n;}).join('; ')+'.':'');
    return 'TRAINEE: '+p.name+' · '+(p.rank==='CPT'?'Capitán':'Primer oficial')+' · flota '+p.fleet+'\nFALENCIAS DETECTADAS: '+fal+'\nHISTORIAL ('+ss.length+' sesiones firmadas):\n'+ss.map(function(s){return sessText(s,seatOf(s,p.id));}).join('\n');}
  if(ctx&&ctx.indexOf('s:')===0){var s=S.sessions[ctx.slice(2)];if(!s)return '';return 'SESIÓN:\n'+seats(s).map(function(x){return sessText(s,x);}).join('\n')+debTargets(s).filter(function(t){return t.val;}).map(function(t){return '\nDebriefing registrado'+(t.label?' ('+t.label+')':'')+': '+t.val;}).join('');}
  if(!isCoord())return 'Sin contexto seleccionado. Pide al instructor que elija un trainee o una sesión.';
  var ss2=live('sessions').filter(function(s){return s.status==='signed'&&s.module===S.settings.module;});
  var av=compAverages(ss2);
  return 'RESUMEN DEL MÓDULO '+S.settings.module+': '+ss2.length+' sesiones firmadas. Promedios por competencia: '+CK.map(function(k){return k+' '+(av[k]?av[k].toFixed(2):'s/d');}).join(', ')+'.\nTrainees registrados: '+live('trainees').length+'.';
}
function sessText(s,x){
  var g=s.grades[x]||{};
  return '- '+s.date+' '+s.module+' '+s.phase+' ('+s.fleet+') '+x.toUpperCase()+' '+pname(s.pilots[x])+': '+CK.map(function(k){var e=g[k]||{};var ob=e.ob||{};var o=Object.keys(ob).filter(function(q){return ob[q];}).map(function(q){return (ob[q]<0?'−':'+')+q;});return k+'='+(e.no?'N/O':(e.g||'s/d'))+(o.length?' ['+o.join(' ')+']':'')+(e.note?' «'+e.note+'»':'');}).join('; ')+'. Resultado: '+(RES[s.result[x]||''][0])+(s.events&&s.events.length?'. Eventos: '+s.events.map(function(e){return e.t+(e.done?'':' (no completado)')+(e.g&&e.g[x]?' grado '+e.g[x]:'')+(e.at?' ['+hhmm(e.at)+']':'')+(e.note?' «'+e.note+'»':'');}).join(' | '):'');
}
function vAsistente(){
  var ctx=S.ui.aiCtx||'',chat=S.ui.chat||(S.ui.chat=[]);
  var ps=live('trainees').sort(function(a,b){return a.name.localeCompare(b.name);});
  var ss=live('sessions').sort(sortByDate).reverse().slice(0,15);
  var html=head('Asistente IA','Analiza historiales, redacta debriefings y prepara el training focus del próximo módulo.');
  html+='<div class="row" style="margin-bottom:14px"><div class="field" style="flex:1;min-width:240px"><label for="ai-ctx">Contexto</label><select class="input" id="ai-ctx" data-bind="ui.aiCtx" data-rerender="1" data-resetchat="1">'+(isCoord()?'<option value="">Módulo en curso ('+esc(S.settings.module)+')</option>':'<option value="">Elige un trainee o una sesión</option>')+'<optgroup label="Trainees">'+ps.map(function(p){return '<option value="p:'+p.id+'"'+(ctx==='p:'+p.id?' selected':'')+'>'+esc(p.name)+'</option>';}).join('')+'</optgroup><optgroup label="Sesiones">'+ss.map(function(s){return '<option value="s:'+s.id+'"'+(ctx==='s:'+s.id?' selected':'')+'>'+esc(s.phase+' '+fdate(s.date)+' · '+seats(s).map(function(x){return pname(s.pilots[x]).split(' ')[0];}).join('/'))+'</option>';}).join('')+'</optgroup></select></div>'+(chat.length?'<button class="btn" data-act="aiClear" style="align-self:flex-end">Nueva conversación</button>':'')+'</div>';
  if(sampleReady&&!SAMPLE)html+='<div class="note" style="margin-bottom:14px">El asistente funciona cuando la app se abre en Claude con conexión. Sin conexión, el resto de la app sigue disponible.</div>';
  var quick=ctx.indexOf('p:')===0?['Resume la evolución de este trainee','¿Qué training focus recomiendas para el próximo módulo?','Identifica patrones en los OB deficientes']:ctx.indexOf('s:')===0?['Redacta un debriefing facilitado para esta sesión','¿Las calificaciones son coherentes con los OB y notas?','Sugiere preguntas de facilitación para el debriefing']:['¿Qué competencias están más débiles en el módulo?','Propón prioridades para el próximo módulo','Explica la diferencia entre EVAL, MT y SBT'];
  html+='<div class="chat" id="chat">'+(chat.length?chat.map(function(m,i){return '<div class="msg '+(m.role==='user'?'u':'a')+'" id="m'+i+'">'+esc(m.content)+'</div>';}).join(''):'<div class="card" style="text-align:center;padding:28px"><div style="color:var(--accent);display:inline-block">'+I.spark.replace('<svg','<svg width="34" height="34"')+'</div><h3 style="margin:8px 0 4px">¿En qué te ayudo?</h3><p class="small muted" style="margin-bottom:16px">El asistente lee solo el contexto que elijas arriba.</p><div class="chips" style="justify-content:center">'+quick.map(function(q){return '<button class="chip" data-act="aiQuick" data-q="'+esc(q)+'">'+esc(q)+'</button>';}).join('')+'</div></div>')+'</div>';
  html+='<div class="composer"><textarea class="input" id="ai-in" rows="1" placeholder="Pregunta al asistente…"></textarea><button class="btn primary" data-act="aiSend" id="ai-send" style="height:44px;width:44px;padding:0" aria-label="Enviar"'+(aiBusy?' disabled':'')+'>'+I.send+'</button></div>';
  return html;
}
async function getSample(){if(!sampleReady){try{SAMPLE=window.claude&&window.claude.use?await window.claude.use('sample'):null;}catch(e){SAMPLE=null;}sampleReady=true;}return SAMPLE;}
function aiErr(e){var c=e&&e.code;return c==='not_granted'?'El asistente no tiene permiso en esta vista.':c==='rate_limited'?'Demasiadas consultas seguidas. Intenta en un minuto.':c==='cancelled'?'Consulta cancelada.':'No se pudo consultar al asistente'+(online()?'.':': no hay conexión.');}
async function aiAsk(q){
  q=(q||'').trim();if(!q||aiBusy)return;
  var sm=await getSample();var chat=S.ui.chat||(S.ui.chat=[]);
  chat.push({role:'user',content:q});
  if(!sm){chat.push({role:'assistant',content:'El asistente se activa cuando abres la app en Claude con conexión a internet.'});render();return;}
  chat.push({role:'assistant',content:'Pensando…'});aiBusy=true;render();scrollChat();
  var idx=chat.length-1;
  var turns=chat.slice(0,-1).map(function(m,i){return {role:m.role,content:i===0?PRE+'\n\nCONTEXTO:\n'+ctxText(S.ui.aiCtx)+'\n\nSOLICITUD DEL INSTRUCTOR: '+m.content:m.content};});
  try{aiCtl=new AbortController();
    var r=await sm(turns,{cache:false,signal:aiCtl.signal,onText:function(u){chat[idx].content=u.text;var el=document.getElementById('m'+idx);if(el)el.textContent=u.text;scrollChat();}});
    chat[idx].content=r.text;
  }catch(e){chat[idx].content=(e&&e.text?e.text+'\n\n':'')+aiErr(e);}
  aiBusy=false;if(chat.length>40)chat.splice(0,chat.length-40);persist();render();scrollChat();
}
function scrollChat(){var m=document.getElementById('main');var c=document.getElementById('chat');if(c&&c.lastElementChild)c.lastElementChild.scrollIntoView({block:'end',behavior:'smooth'});}
async function aiDebrief(key,btn){
  var s=cur();if(!s)return;var sm=await getSample();
  if(!sm){toast('El asistente requiere abrir la app en Claude con conexión');return;}
  var t=debTargets(s).filter(function(x){return x.key===key;})[0]||debTargets(s)[0];
  var ta=document.getElementById('deb-'+t.key);if(btn){btn.disabled=true;btn.lastChild.textContent='Redactando…';}
  var scope=t.key==='joint'?seats(s):[t.key];
  var prompt=PRE+'\n\nCONTEXTO:\n'+scope.map(function(x){return sessText(s,x);}).join('\n')+(t.val?'\nNotas actuales del instructor: '+t.val:'')+'\n\nSOLICITUD: Redacta el texto de debriefing y recomendaciones '+(t.key==='joint'?'para la tripulación completa':'individual para '+t.key.toUpperCase()+' ('+pname(s.pilots[t.key])+')')+' (máx. 220 palabras). Estructura: 1) Fortalezas observadas con OB, 2) Áreas de mejora con OB y evidencia, 3) Training focus para el próximo módulo. Integra las notas actuales del instructor si las hay. Solo el texto, sin títulos de markdown.';
  try{var r=await sm(prompt,{cache:false,onText:function(u){if(ta)ta.value=u.text;}});setPath(s,t.path,r.text);(s.aiDraft=s.aiDraft||{})[t.key]=Date.now();put('sessions',s,true);toast('Borrador de IA listo. Revísalo: tú eres el autor del registro');}
  catch(e){toast(aiErr(e));}
  if(btn){btn.disabled=false;btn.lastChild.textContent='Redactar con IA';}
}

/* ============ Exportación ============ */
async function saveFile(name,data){
  try{
    var dl=window.claude&&window.claude.use?await window.claude.use('downloads'):null;
    if(dl){await dl.save({filename:name,data:data});toast('Archivo listo: '+name);return;}
    var type=/\.pdf$/i.test(name)?'application/pdf':/\.csv$/i.test(name)?'text/csv':'application/json';
    var blob=data instanceof Blob?data:new Blob([data],{type:type});
    var file=null;try{file=new File([blob],name,{type:type});}catch(e){}
    if(file&&navigator.canShare&&navigator.canShare({files:[file]})&&/iPad|iPhone|iPod|Macintosh/.test(navigator.userAgent)&&'ontouchend' in document){try{await navigator.share({files:[file],title:name});return;}catch(e){if(e&&e.name==='AbortError')return;}}
    var url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(url);a.remove();},4000);toast('Descargado: '+name);
  }catch(e){if(e&&e.code==='declined')return;toast('No se pudo guardar el archivo');}
}
function slug(s){return String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^\w]+/g,'-').replace(/^-|-$/g,'');}
function hasPDF(){return !!(window.jspdf&&window.jspdf.jsPDF&&window.jspdf.jsPDF.API&&window.jspdf.jsPDF.API.autoTable);}
function loadLibs(){if(hasPDF())return;function add(src,cb){var sc=document.createElement('script');sc.src=src;sc.onload=cb||null;document.head.appendChild(sc);}
  if(!(window.jspdf&&window.jspdf.jsPDF))add('https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js',function(){add('https://cdn.jsdelivr.net/npm/jspdf-autotable@3.8.2/dist/jspdf.plugin.autotable.min.js');});
  else add('https://cdn.jsdelivr.net/npm/jspdf-autotable@3.8.2/dist/jspdf.plugin.autotable.min.js');}
var RGB={1:[210,59,50],2:[229,138,31],3:[124,198,142],4:[61,166,97],5:[22,121,74]};
function pdfBase(title,sub){
  var doc=new window.jspdf.jsPDF({unit:'mm',format:'a4'});
  doc.setFillColor(215,38,61);doc.rect(0,0,210,3,'F');
  doc.setFont('helvetica','bold');doc.setFontSize(17);doc.setTextColor(28,28,31);doc.text(title,16,18);
  doc.setFont('helvetica','normal');doc.setFontSize(9.5);doc.setTextColor(108,108,115);doc.text(sub,16,24);
  doc.text((S.settings.operator||ORG('orgName',''))?(S.settings.operator||ORG('orgName',''))+' · EBT Instructor':'EBT Instructor',194,18,{align:'right'});
  return doc;
}
function pdfFoot(doc,id){
  var n=doc.getNumberOfPages();for(var i=1;i<=n;i++){doc.setPage(i);doc.setFontSize(8);doc.setTextColor(150,150,155);doc.text('Generado '+new Date().toLocaleString('es-CO')+(id?' · ID '+id:''),16,289);doc.text('Página '+i+' de '+n,194,289,{align:'right'});}
}
function gradeCell(data,idx){if(data.section==='body'&&idx.indexOf(data.column.index)>=0){var v=parseInt(data.cell.raw,10);if(v>=1&&v<=5){data.cell.styles.fillColor=RGB[v];data.cell.styles.textColor=[255,255,255];data.cell.styles.fontStyle='bold';data.cell.styles.halign='center';}}}
var TBL={theme:'plain',styles:{fontSize:8.6,cellPadding:2.2,lineColor:[228,228,232],lineWidth:.2,textColor:[40,40,45]},headStyles:{fillColor:[245,245,247],textColor:[90,90,96],fontStyle:'bold',fontSize:7.8},margin:{left:16,right:16}};
function T(doc,o){doc.autoTable(Object.assign({},TBL,o));return doc.lastAutoTable.finalY;}
/* --- dibujo de gráficas en PDF --- */
var PDFC={fg:[28,28,31],mu:[108,108,115],ln:[225,225,230],acc:[215,38,61],g3:[158,163,173]};
function pdfBars(doc,x,y,w,vals,prev){
  var rowH=6.2,lw=12,vw=10,bw=w-lw-vw-4;
  CK.forEach(function(k,i){var yy=y+i*rowH,v=vals[k]||0;
    doc.setFont('helvetica','bold');doc.setFontSize(7.5);doc.setTextColor.apply(doc,PDFC.fg);doc.text(k,x,yy+3.4);
    doc.setFillColor(238,238,242);doc.roundedRect(x+lw,yy+0.6,bw,3.6,1.8,1.8,'F');
    if(v){var c=RGB[Math.max(1,Math.min(5,Math.round(v)))];doc.setFillColor(c[0],c[1],c[2]);doc.roundedRect(x+lw,yy+0.6,bw*v/5,3.6,1.8,1.8,'F');}
    if(prev&&prev[k]){doc.setDrawColor(70,70,75);doc.setLineWidth(.5);var px=x+lw+bw*prev[k]/5;doc.line(px,yy-0.2,px,yy+5);}
    doc.setFont('helvetica','normal');doc.setFontSize(7.5);doc.setTextColor.apply(doc,PDFC.mu);doc.text(v?f1(v):'–',x+w,yy+3.4,{align:'right'});});
  return y+CK.length*rowH;
}
function pdfRadar(doc,cx,cy,R,series){
  var n=CK.length;function pt(i,v){var a=-Math.PI/2+i*2*Math.PI/n,r=R*v/5;return [cx+r*Math.cos(a),cy+r*Math.sin(a)];}
  doc.setLineWidth(.2);doc.setDrawColor.apply(doc,PDFC.ln);
  for(var g=1;g<=5;g++){for(var i=0;i<n;i++){var p1=pt(i,g),p2=pt((i+1)%n,g);doc.line(p1[0],p1[1],p2[0],p2[1]);}}
  for(var i=0;i<n;i++){var e=pt(i,5);doc.line(cx,cy,e[0],e[1]);var l=pt(i,6);doc.setFont('helvetica','bold');doc.setFontSize(6.5);doc.setTextColor.apply(doc,PDFC.fg);doc.text(CK[i],l[0],l[1]+1,{align:'center'});}
  series.forEach(function(sr){var pts=CK.map(function(k,i){return pt(i,sr.vals[k]||0);});var c=sr.color;
    var segs=[];for(var i=1;i<pts.length;i++)segs.push([pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]]);
    doc.setDrawColor(c[0],c[1],c[2]);doc.setFillColor(c[0],c[1],c[2]);doc.setLineWidth(.6);
    try{doc.setGState(new doc.GState({opacity:.18}));doc.lines(segs,pts[0][0],pts[0][1],[1,1],'F',true);doc.setGState(new doc.GState({opacity:1}));}catch(e){}
    doc.lines(segs,pts[0][0],pts[0][1],[1,1],'S',true);
    pts.forEach(function(p,i){if(sr.vals[CK[i]])doc.circle(p[0],p[1],.8,'F');});});
}
function pdfTrend(doc,x,y,w,h,points,color){
  var L=7,B=7,iw=w-L-2,ih=h-B-3;function Y(v){return y+3+ih-(v-1)/4*ih;}function X(i){return points.length===1?x+L+iw/2:x+L+i*iw/(points.length-1);}
  doc.setLineWidth(.2);for(var g=1;g<=5;g++){doc.setDrawColor.apply(doc,PDFC.ln);doc.line(x+L,Y(g),x+w,Y(g));doc.setFontSize(6.5);doc.setTextColor.apply(doc,PDFC.mu);doc.text(String(g),x+L-2,Y(g)+1,{align:'right'});}
  var c=color;doc.setDrawColor(c[0],c[1],c[2]);doc.setFillColor(c[0],c[1],c[2]);doc.setLineWidth(.7);
  for(var i=1;i<points.length;i++)doc.line(X(i-1),Y(points[i-1].v),X(i),Y(points[i].v));
  var step=Math.ceil(points.length/8);
  points.forEach(function(p,i){doc.circle(X(i),Y(p.v),.9,'F');if(i%step===0||i===points.length-1){doc.setFontSize(6);doc.setTextColor.apply(doc,PDFC.mu);doc.text(p.label,X(i),y+h,{align:'center'});}
    if(i===points.length-1){doc.setFont('helvetica','bold');doc.setFontSize(7);doc.setTextColor.apply(doc,PDFC.fg);doc.text(f1(p.v),X(i),Y(p.v)-2.2,{align:'center'});doc.setFont('helvetica','normal');}});
}
function pdfH(doc,txt,y){doc.setFont('helvetica','bold');doc.setFontSize(11);doc.setTextColor.apply(doc,PDFC.fg);doc.text(txt,16,y);doc.setFont('helvetica','normal');}
function pdfPara(doc,txt,y,w){doc.setFontSize(9);doc.setTextColor(50,50,55);var lines=doc.splitTextToSize(txt,w||178);lines.forEach(function(l){if(y>282){doc.addPage();y=16;}doc.text(l,16,y);y+=4.3;});return y;}
function pdfLegend(doc,x,y,items){items.forEach(function(it){doc.setFillColor(it.c[0],it.c[1],it.c[2]);doc.roundedRect(x,y-2.2,3,3,.6,.6,'F');doc.setFontSize(7);doc.setTextColor.apply(doc,PDFC.mu);doc.text(it.t,x+4.5,y);x+=4.5+doc.getTextWidth(it.t)+5;});}

async function pdfSession(id){
  var s=S.sessions[id];if(!s)return;
  if(!hasPDF()){toast('El PDF necesita conexión la primera vez que se abre la app');return;}
  var doc=pdfBase('Informe de evaluación EBT',s.phase+' · '+phaseName(s.phase)+' · '+s.module+' · '+s.fleet);
  var y=T(doc,{startY:30,body:[['Fecha',fdate(s.date),'Instructor',(s.instructor||'')+(S.settings.instructorId?' ('+S.settings.instructorId+')':'')],['Modalidad',s.mode==='crew'?'Tripulación (CM1 + CM2)':'Un piloto','Estado',s.status==='signed'?'Firmada '+ftime(s.signedAt):'Borrador'],['Plantilla',(s.templateId&&S.evals[s.templateId]?S.evals[s.templateId].name:'—'),'Sello',s.hash||'—']],columnStyles:{0:{textColor:[108,108,115],cellWidth:24},2:{textColor:[108,108,115],cellWidth:22}}});
  seats(s).forEach(function(x,si){
    var p=pilot(s.pilots[x])||{},g=s.grades[x]||{};
    if(si>0||y>120){doc.addPage();y=12;}
    doc.setFont('helvetica','bold');doc.setFontSize(12.5);doc.setTextColor.apply(doc,PDFC.fg);doc.text(x.toUpperCase()+' · '+pname(s.pilots[x])+(p.emp?'  #'+p.emp:''),16,y+9);
    doc.setFont('helvetica','normal');doc.setFontSize(9);doc.setTextColor.apply(doc,PDFC.mu);
    doc.text('Resultado: '+RES[s.result[x]||''][0]+'   ·   Promedio: '+f1(sessAvg(s,x)),194,y+9,{align:'right'});
    // gráficas: radar (última vs anterior) + barras
    var hist=pilotSessions(s.pilots[x]).filter(function(q){return q.status==='signed'&&q.id!==s.id&&q.date<=s.date;});var prev=hist[hist.length-1];
    var vals=gradesOf(s,x),pv=prev?gradesOf(prev,seatOf(prev,s.pilots[x])):null;
    var series=[];if(pv)series.push({vals:pv,color:PDFC.g3});series.push({vals:vals,color:PDFC.acc});
    doc.setFontSize(8);doc.setTextColor.apply(doc,PDFC.mu);doc.text('Perfil de competencias'+(prev?' vs. '+prev.phase+' '+fdateShort(prev.date):''),16,y+17);doc.text('Grado por competencia'+(pv?' (línea: sesión anterior)':''),104,y+17);
    pdfRadar(doc,52,y+50,25,series);pdfBars(doc,104,y+21,90,vals,pv);
    var leg=[{c:PDFC.acc,t:'Esta sesión'}];if(pv)leg.unshift({c:PDFC.g3,t:'Anterior'});pdfLegend(doc,20,y+84,leg);
    y=T(doc,{startY:y+90,head:[['Comp.','Competencia','Grado','OB observados','Evidencia']],body:CK.map(function(k){var e=g[k]||{},ob=e.ob||{};return [k,CMAP[k].es,gtxt(e),Object.keys(ob).filter(function(o){return ob[o];}).map(function(o){return (ob[o]<0?'(-) ':'(+) ')+o;}).join('  '),e.note||''];}),
      columnStyles:{0:{cellWidth:13,fontStyle:'bold'},1:{cellWidth:52},2:{cellWidth:13},3:{cellWidth:30}},didParseCell:function(d){gradeCell(d,[2]);}});
  });
  if(s.events&&s.events.length){if(y>250){doc.addPage();y=16;}y=T(doc,{startY:y+6,head:[['Hora','Evento','Competencias','Grado','Nota']],body:s.events.map(function(e){return [e.at?hhmm(e.at):'',(e.phase?e.phase+' · ':'')+e.t,(e.c||[]).join(' '),seats(s).map(function(x){return e.g&&e.g[x]?x.toUpperCase()+' '+e.g[x]:'';}).filter(Boolean).join(' / ')||(e.done?'Hecho':'—'),e.note||''];}),columnStyles:{0:{cellWidth:14},2:{cellWidth:26},3:{cellWidth:22}}});}
  if(temList(s).length){if(y>230){doc.addPage();y=16;}y=T(doc,{startY:y+6,head:[['TEM','Categoría','Qué pasó','Quién','Competencias','Gestión']],body:temList(s).map(function(it){return [TEM_T[it.type].n,it.cat,it.txt||'',it.seat&&it.seat!=='crew'?it.seat.toUpperCase():'Tripulación',(it.c||[]).join(' '),TEM_MGMT[it.mgmt]?TEM_MGMT[it.mgmt][0]:''];}),columnStyles:{0:{cellWidth:22,fontStyle:'bold'},1:{cellWidth:32},3:{cellWidth:20},4:{cellWidth:26},5:{cellWidth:24}}});}
  debTargets(s).forEach(function(t){if(!t.val)return;if(y>240){doc.addPage();y=16;}pdfH(doc,'Debriefing y recomendaciones'+(t.label?' · '+t.label:''),y+10);y=pdfPara(doc,t.val,y+16);if(s.aiDraft&&s.aiDraft[t.key])y=pdfPara(doc,'Borrador propuesto por IA; revisado y firmado por el instructor, autor del registro.',y+2);});
  var who=[['inst','Instructor',s.instructor||'']].concat(seats(s).map(function(x){return [x,x.toUpperCase(),pname(s.pilots[x])];}));
  if(y>240){doc.addPage();y=16;}y+=8;var w=(178-(who.length-1)*6)/who.length;
  who.forEach(function(v,i){var x0=16+i*(w+6);if(s.sig[v[0]]){try{doc.addImage(s.sig[v[0]],'JPEG',x0,y,w,w*0.31);}catch(e){}}doc.setDrawColor(180,180,186);doc.setLineWidth(.3);doc.line(x0,y+w*0.31+2,x0+w,y+w*0.31+2);doc.setFontSize(8.4);doc.setTextColor(90,90,96);doc.text(v[1]+' · '+v[2],x0,y+w*0.31+6.5);});
  pdfFoot(doc,s.id);
  await saveFile('evaluacion-'+slug(s.phase+'-'+s.date+'-'+seats(s).map(function(x){return pname(s.pilots[x]).split(' ')[0];}).join('-'))+'.pdf',doc.output('blob'));
}
async function pdfPilot(pid){
  var p=pilot(pid);if(!p)return;var ss=pilotSessions(pid).filter(function(s){return s.status==='signed';});
  if(!hasPDF()){toast('El PDF necesita conexión la primera vez que se abre la app');return;}
  var doc=pdfBase('Historial de entrenamiento EBT',p.name+' · '+(p.rank==='CPT'?'Capitán':'Primer oficial')+' · '+p.fleet+(p.emp?' · #'+p.emp:''));
  if(!ss.length){pdfH(doc,'Sin sesiones firmadas',40);pdfFoot(doc,p.id);await saveFile('historial-'+slug(p.name)+'.pdf',doc.output('blob'));return;}
  var last=ss[ss.length-1],prev=ss[ss.length-2],lx=seatOf(last,pid);
  var lv=gradesOf(last,lx),pv=prev?gradesOf(prev,seatOf(prev,pid)):null;
  var all=compAverages(ss.map(function(s){var c=JSON.parse(JSON.stringify(s));c.mode='single';c.pilots={cm1:pid};c.grades={cm1:s.grades[seatOf(s,pid)]};return c;}));
  var rt=ss.filter(function(s){return s.result[seatOf(s,pid)]==='RT';}).length;
  // resumen
  var y=T(doc,{startY:30,body:[['Sesiones firmadas',String(ss.length),'Última sesión',last.phase+' · '+fdate(last.date)+' · promedio '+f1(sessAvg(last,lx))],['Promedio histórico',f1(avg(CK.map(function(k){return all[k];}))),'Entrenamiento adicional',rt+' de '+ss.length],['Módulos',Array.from(new Set(ss.map(function(s){return s.module;}))).join(', '),'Instructor del informe',S.settings.instructor]],columnStyles:{0:{textColor:[108,108,115],cellWidth:34},2:{textColor:[108,108,115],cellWidth:38}}});
  doc.setFontSize(8);doc.setTextColor.apply(doc,PDFC.mu);doc.text('Evolución del promedio por sesión',16,y+9);doc.text('Perfil: última sesión'+(prev?' vs. anterior':''),118,y+9);
  pdfTrend(doc,16,y+12,92,46,ss.map(function(s){return {label:s.phase+' '+fdateShort(s.date),v:sessAvg(s,seatOf(s,pid))};}),PDFC.acc);
  var series=[];if(pv)series.push({vals:pv,color:PDFC.g3});series.push({vals:lv,color:PDFC.acc});pdfRadar(doc,158,y+36,22,series);
  var leg=[{c:PDFC.acc,t:last.phase+' '+fdateShort(last.date)}];if(prev)leg.unshift({c:PDFC.g3,t:prev.phase+' '+fdateShort(prev.date)});pdfLegend(doc,122,y+64,leg);
  y+=70;doc.setFontSize(8);doc.setTextColor.apply(doc,PDFC.mu);doc.text('Promedio histórico por competencia (línea: última sesión)',16,y);
  y=pdfBars(doc,16,y+4,178,all,lv)+4;
  y=T(doc,{startY:y+4,head:[['Fecha','Fase','Módulo'].concat(CK).concat(['Prom.','Resultado'])],body:ss.map(function(s){var x=seatOf(s,pid),g=s.grades[x];return [fdateShort(s.date)+' '+String(s.date).slice(2,4),s.phase,s.module].concat(CK.map(function(k){return g[k]&&g[k].g||'';})).concat([f1(sessAvg(s,x)),RES[s.result[x]||''][0]]);}),
    styles:Object.assign({},TBL.styles,{fontSize:7.4,cellPadding:1.7}),didParseCell:function(d){gradeCell(d,[3,4,5,6,7,8,9,10,11]);}});
  // áreas de atención
  var w=weaknesses(pid);
  if(y>225){doc.addPage();y=10;}
  pdfH(doc,'Áreas de atención',y+10);y+=13;
  if(!w.comp.length&&!w.obs.length){y=pdfPara(doc,'Sin competencias en grado 1–2 ni OB deficientes en el historial firmado.',y+4);}
  else{
    if(w.comp.length)y=T(doc,{startY:y+2,head:[['Comp.','Competencia','Veces en 1–2','Última vez','Grado']],body:w.comp.map(function(c){return [c.k,CMAP[c.k].es,String(c.n),c.phase+' '+fdate(c.last),String(c.lastG)];}),columnStyles:{0:{cellWidth:14,fontStyle:'bold'},2:{cellWidth:24,halign:'center'},4:{cellWidth:14}},didParseCell:function(d){gradeCell(d,[4]);}});
    if(w.obs.length){y=T(doc,{startY:y+4,head:[['OB deficiente','Descripción','Veces']],body:w.obs.map(function(o){return [o.k+' · OB '+o.o,obText(o.k,o.o),String(o.n)];}),columnStyles:{0:{cellWidth:28,fontStyle:'bold'},2:{cellWidth:14,halign:'center'}}});}
    if(w.events.length){y=T(doc,{startY:y+4,head:[['Maniobra / procedimiento por reforzar','Competencias en 1–2','Veces','Última']],body:w.events.map(function(e){return [e.t,Object.keys(e.ks).join(' '),String(e.n),fdate(e.last)];}),columnStyles:{1:{cellWidth:34},2:{cellWidth:14,halign:'center'},3:{cellWidth:26}}});}
  }
  var g=last.grades[lx];var f=CK.filter(function(k){return g[k]&&g[k].g&&g[k].g<=2;});
  if(y>250){doc.addPage();y=10;}
  pdfH(doc,'Foco sugerido para el próximo módulo',y+10);
  y=pdfPara(doc,(f.length?f.map(function(k){return '• '+k+' · '+CMAP[k].es+' (grado '+g[k].g+' en '+last.phase+' '+fdate(last.date)+')';}).join('\n'):'• Sin competencias en grado 1–2 en la última sesión.')+(w.events.length?'\n• Repetir en simulador: '+w.events.slice(0,3).map(function(e){return e.t;}).join('; ')+'.':''),y+16);
  debTargets(last).forEach(function(t){if(!t.val)return;if(y>240){doc.addPage();y=10;}pdfH(doc,'Último debriefing registrado ('+last.phase+' '+fdate(last.date)+')',y+8);y=pdfPara(doc,t.val,y+14);});
  pdfFoot(doc,p.id);await saveFile('historial-'+slug(p.name)+'.pdf',doc.output('blob'));
}
async function pdfReport(){
  if(!hasPDF()){toast('El PDF necesita conexión la primera vez que se abre la app');return;}
  var f=S.ui.rf||{};var ss=live('sessions').filter(function(s){return s.status==='signed'&&(!f.module||s.module===f.module)&&(!f.fleet||s.fleet===f.fleet)&&(!f.phase||s.phase===f.phase);}).sort(sortByDate);
  if(!ss.length){toast('No hay sesiones con estos filtros');return;}
  var av=compAverages(ss);
  var doc=pdfBase('Informe consolidado EBT',[f.module||'Todos los módulos',f.fleet||'Todas las flotas',f.phase||'Todas las fases'].join(' · ')+' · '+ss.length+' sesiones');
  var y=T(doc,{startY:30,head:[['Código','Competencia','Promedio']],body:CK.map(function(k){return [k,CMAP[k].es,f1(av[k])];}),columnStyles:{0:{cellWidth:18,fontStyle:'bold'},2:{cellWidth:24,halign:'center'}},didParseCell:function(d){if(d.section==='body'&&d.column.index===2){var v=Math.round(av[CK[d.row.index]]);if(v){d.cell.styles.fillColor=RGB[v];d.cell.styles.textColor=[255,255,255];d.cell.styles.fontStyle='bold';}}}});
  var rows=[];ss.forEach(function(s){seats(s).forEach(function(x){rows.push([fdate(s.date),s.phase,s.fleet,pname(s.pilots[x]),x.toUpperCase(),f1(sessAvg(s,x)),RES[s.result[x]||''][0]]);});});
  T(doc,{startY:y+8,head:[['Fecha','Fase','Flota','Piloto','Asiento','Prom.','Resultado']],body:rows});
  pdfFoot(doc);await saveFile('informe-ebt-'+slug(f.module||'general')+'.pdf',doc.output('blob'));
}
function htmlExport(title,body){return '<!doctype html><html lang="es"><head><meta charset="utf-8"><title>'+esc(title)+'</title><style>body{font-family:-apple-system,Helvetica,Arial,sans-serif;max-width:820px;margin:32px auto;padding:0 16px;color:#1c1c1f}img{max-width:220px}button{display:none}.tag,.pill,.code{font-size:11px;margin-right:4px}.gchip{display:inline-block;min-width:22px;text-align:center;border-radius:5px;background:#eee;font-weight:700}table{border-collapse:collapse;width:100%}td{border-bottom:1px solid #eee;padding:6px}</style></head><body><h1>'+esc(title)+'</h1>'+body+'</body></html>';}
function csv(){
  var rows=[['fecha','modulo','flota','fase','asiento','piloto','codigo','cargo'].concat(CK).concat(['promedio','resultado','estado','instructor','id_sesion'])];
  live('sessions').sort(sortByDate).forEach(function(s){seats(s).forEach(function(x){var p=pilot(s.pilots[x])||{};var g=s.grades[x]||{};rows.push([s.date,s.module,s.fleet,s.phase,x.toUpperCase(),p.name||'',p.emp||'',p.rank||''].concat(CK.map(function(k){return g[k]?(g[k].no?'N/O':(g[k].g||'')):'';})).concat([sessAvg(s,x).toFixed(2),RES[s.result[x]||''][0],s.status,s.instructor||'',s.id]));});});
  var txt='\ufeff'+rows.map(function(r){return r.map(function(v){v=String(v);return /[",;\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;}).join(';');}).join('\n');
  saveFile('ebt-instructor-'+today()+'.csv',txt);
}
function backup(){var o={app:'ebt-instructor',version:1,exportedAt:new Date().toISOString(),trainees:S.trainees,sessions:S.sessions,instructors:S.instructors,evals:S.evals,schedule:S.schedule,notices:S.notices};saveFile('ebt-instructor-respaldo-'+today()+'.json',JSON.stringify(o,null,1));}
function pickFileText(cb){var i=document.createElement('input');i.type='file';i.accept='.csv,.json,text/csv,application/json';i.onchange=function(){var f=i.files[0];if(!f)return;var r=new FileReader();r.onload=function(){cb(r.result,f.name);};r.readAsText(f);};i.click();}
function pickFile(cb){var i=document.createElement('input');i.type='file';i.accept='application/json,.json';i.onchange=function(){var f=i.files[0];if(!f)return;var r=new FileReader();r.onload=function(){try{cb(JSON.parse(r.result));}catch(e){toast('El archivo no es un JSON válido');}};r.readAsText(f);};i.click();}
function mergeIn(o){var n=0;COLLS.forEach(function(c){var src=o[c]||{};(Array.isArray(src)?src:Object.keys(src).map(function(k){return src[k];})).forEach(function(r){if(!r||!r.id)return;var l=S[c][r.id];if(!l||(r.updatedAt||0)>(l.updatedAt||0)){S[c][r.id]=r;S.outbox[c+'/'+r.id]=1;n++;}});});persist();scheduleFlush();render();toast(n+' registros importados');}
function importTpl(o){var arr=Array.isArray(o)?o:o.evals?(Array.isArray(o.evals)?o.evals:Object.keys(o.evals).map(function(k){return o.evals[k];})):[o];var n=0;
  arr.forEach(function(t){if(!t||!t.name)return;var rec={id:t.id||uid('t'),name:t.name,module:t.module||S.settings.module,fleet:t.fleet||'A320',phase:t.phase||'EVAL',note:t.note||'',events:(t.events||[]).map(function(e){return typeof e==='string'?{t:e,c:[]}:{t:e.t||e.name||'',c:(e.c||e.competencies||[]).filter(function(k){return CMAP[k];})};})};put('evals',rec,true);n++;});render();toast(n+' plantilla'+(n===1?'':'s')+' importada'+(n===1?'':'s'));}
function loadDemo(){var d=demoData();['trainees','sessions','evals','schedule','notices'].forEach(function(c){Object.keys(d[c]).forEach(function(k){if(!S[c][k]||S[c][k].deleted){S[c][k]=d[c][k];S[c][k].deleted=false;S[c][k].updatedAt=Date.now();S.outbox[c+'/'+k]=1;}});});persist();scheduleFlush();render();toast('Datos de ejemplo cargados');}
function clearDemo(){var n=0;['trainees','sessions','evals','schedule','notices'].forEach(function(c){live(c).forEach(function(r){if(r.example){r.deleted=true;r.updatedAt=Date.now();S.outbox[c+'/'+r.id]=1;n++;}});});persist();scheduleFlush();render();toast(n+' registros de ejemplo eliminados');}

async function sealHash(s){
  var o=JSON.parse(JSON.stringify(s));delete o.sig;delete o.hash;delete o.updatedAt;delete o.by;
  var txt=JSON.stringify(o)+Object.keys(s.sig).map(function(k){return (s.sig[k]||'').length;}).join(',');
  try{var b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(txt));return Array.from(new Uint8Array(b)).slice(0,10).map(function(x){return x.toString(16).padStart(2,'0');}).join('').toUpperCase().match(/.{4}/g).join('-');}
  catch(e){var h=0;for(var i=0;i<txt.length;i++){h=(h*31+txt.charCodeAt(i))|0;}return 'H'+(h>>>0).toString(16).toUpperCase();}
}

/* ============ Acciones ============ */
function toast(m){var t=document.createElement('div');t.className='toast';t.textContent=m;document.body.appendChild(t);setTimeout(function(){t.remove();},2600);}
function go(r){if(r==='trainees')r='pilotos';S.ui.route=r;S.ui.sheet=null;persist();render();window.scrollTo(0,0);}
function openSheet(o){S.ui.sheet=o;render();}
var ACT={
  go:function(el){go(el.dataset.r);},
  newEval:function(el){var u=S.ui.setup=null;vSetup();if(el.dataset.pid){var p=pilot(el.dataset.pid);if(p){S.ui.setup.fleet=p.fleet;S.ui.setup.cm1=p.id;}}S.ui.cur=null;go('evaluar');},
  resume:function(el){S.ui.cur=el.dataset.id;S.ui.step=2;S.ui.seat='cm1';go('evaluar');},
  setup:function(el){var u=S.ui.setup;u[el.dataset.k]=el.dataset.v;if(el.dataset.k==='fleet'){u.cm1='';u.cm2='';u.templateId='';}persist();render();},
  startEval:function(){var u=S.ui.setup;
    if(!u.cm1)return toast('Selecciona el trainee'+(u.mode==='crew'?' CM1':''));
    if(u.mode==='crew'&&!u.cm2)return toast('Selecciona el piloto CM2');
    if(u.mode==='crew'&&u.cm1===u.cm2)return toast('CM1 y CM2 deben ser trainees distintos');
    var t=u.templateId&&S.evals[u.templateId];
    var s={id:uid('s'),date:u.date||today(),module:u.module,fleet:u.fleet,phase:u.phase,mode:u.mode,templateId:u.templateId||'',events:t?(t.events||[]).map(function(e){return {t:e.t,c:(e.c||[]).slice(),phase:e.phase||'',done:false,g:{}};}):[],
      slotId:u.slotId||'',pilots:{cm1:u.cm1,cm2:u.mode==='crew'?u.cm2:''},grades:{cm1:{},cm2:{}},result:{cm1:'',cm2:''},debrief:'',focus:{cm1:[],cm2:[]},sig:{inst:'',cm1:'',cm2:''},status:'draft',instructor:S.settings.instructor,iid:myId(),targets:t&&t.targets?t.targets.slice():[]};
    S.ui.cur=s.id;S.ui.step=2;S.ui.seat='cm1';S.ui.setup=null;S.ui.open={};put('sessions',s,true);render();window.scrollTo(0,0);},
  step:function(el){var v=+el.dataset.v;if(v===1){return;}S.ui.step=v;persist();render();window.scrollTo(0,0);},
  seat:function(el){S.ui.seat=el.dataset.v;persist();render();},
  grade:function(el){var s=cur(),seat=el.dataset.seat||S.ui.seat,k=el.dataset.k,v=+el.dataset.v;var g=s.grades[seat][k]||(s.grades[seat][k]={g:0,ob:{},note:''});g.g=g.g===v?0:v;g.no=false;put('sessions',s);},
  gradeNO:function(el){var s=cur(),seat=el.dataset.seat||S.ui.seat,k=el.dataset.k;var g=s.grades[seat][k]||(s.grades[seat][k]={g:0,ob:{},note:''});g.no=!g.no;if(g.no)g.g=0;put('sessions',s);},
  evGrade:function(el){var s=cur();var e=s.events[+el.dataset.i];e.g=e.g||{};var x=el.dataset.seat,v=+el.dataset.v;e.g[x]=e.g[x]===v?0:v;if(e.g[x]&&!e.done)e.done=true;put('sessions',s);},
  ob:function(el){var s=cur(),seat=el.dataset.seat||S.ui.seat,k=el.dataset.k,o=el.dataset.o;var g=s.grades[seat][k]||(s.grades[seat][k]={g:0,ob:{},note:''});g.ob=g.ob||{};var v=g.ob[o]||0;g.ob[o]=v===0?-1:v<0?1:0;if(!g.ob[o])delete g.ob[o];(S.ui.open=S.ui.open||{})[seat+k]=true;put('sessions',s);},
  evDone:function(el){var s=cur();var e=s.events[+el.dataset.i];e.done=!e.done;put('sessions',s);},
  evDel:function(el){var s=cur();s.events.splice(+el.dataset.i,1);put('sessions',s);},
  newEvent:function(){S.ui.form={t:'',c:[],phase:''};openSheet({type:'event'});},
  evTag:function(el){var c=S.ui.form.c,k=el.dataset.k,i=c.indexOf(k);if(i>=0)c.splice(i,1);else c.push(k);render();},
  evAddSheet:function(){var s=cur(),f=S.ui.form;var t=(f.t||'').trim();if(!t)return toast('Escribe el nombre del evento');s.events.push({t:t,c:f.c.slice(),phase:f.phase||'',done:false,g:{}});S.ui.sheet=null;put('sessions',s);toast('Evento agregado');},
  nextSeat:function(el){S.ui.seat=el.dataset.v;persist();render();window.scrollTo(0,0);toast('Calificando '+el.dataset.v.toUpperCase()+' · '+pname(cur().pilots[el.dataset.v]));},
  phrase:function(el){var s=cur(),seat=el.dataset.seat||S.ui.seat,k=el.dataset.k;var g=s.grades[seat][k]||(s.grades[seat][k]={g:0,ob:{},note:''});g.note=(g.note?g.note.replace(/\s*$/,'')+' ':'')+el.dataset.t;put('sessions',s,true);var ta=document.getElementById('n-'+seat+'-'+k);if(ta){ta.value=g.note;ta.focus();}},
  debMode:function(el){var s=cur();s.debriefMode=el.dataset.v;put('sessions',s);},
  debPhrase:function(el){var s=cur();var t=debTargets(s).filter(function(x){return x.key===el.dataset.t;})[0];if(!t)return;var v=(t.val?t.val.replace(/\s*$/,'')+' ':'')+el.dataset.txt;setPath(s,t.path,v);put('sessions',s,true);var ta=document.getElementById('deb-'+t.key);if(ta){ta.value=v;ta.focus();}},
  result:function(el){var s=cur();s.result[el.dataset.seat]=el.dataset.v;put('sessions',s);},
  saveDraft:function(){var s=cur();if(s){put('sessions',s,true);toast('Borrador guardado'+(DB&&online()?'':' en este dispositivo'));}},
  discard:function(el){openSheet({type:'confirm',title:'Descartar evaluación',msg:'Se eliminará este borrador y sus calificaciones. Esta acción no se puede deshacer.',yes:'Descartar',act:'discardYes',id:el.dataset.id});},
  sigClear:function(el){var s=cur();if(!s)return;s.sig[el.dataset.k]='';put('sessions',s);},
  aiDebrief:function(el){aiDebrief(el.dataset.t,el);},
  finalize:async function(){var s=cur();if(!s)return;
    var miss=seats(s).filter(function(x){return graded(s,x)<9;});if(miss.length)return toast('Faltan competencias por calificar en '+miss.map(function(x){return x.toUpperCase();}).join(' y '));
    var nr=seats(s).filter(function(x){return !s.result[x];});if(nr.length)return toast('Elige el resultado de '+nr.map(function(x){return x.toUpperCase();}).join(' y '));
    var nm=ORG('requireNoteForNO',true)?noMissing(s):[];if(nm.length)return toast('Justifica el N/O (no observado) en: '+nm.join(', '));
    var lim=+ORG('requireNoteAtOrBelow',2)||0,nl=[];if(lim)seats(s).forEach(function(x){CK.forEach(function(k){var e=(s.grades[x]||{})[k];if(e&&e.g&&e.g<=lim&&!(e.note||'').trim())nl.push(x.toUpperCase()+' '+k);});});if(nl.length)return toast('Escribe la evidencia de los grados '+(lim===1?'1':'1–'+lim)+' en: '+nl.join(', '));
    if(ORG('requireTraineeSignature',false)){var ns=seats(s).filter(function(x){return !s.sig[x];});if(ns.length)return toast('Falta la firma de '+ns.map(function(x){return x.toUpperCase();}).join(' y '));}
    if(!s.sig.inst)return toast('Falta la firma del instructor');
    if(!s.iid)s.iid=myId();if(s.iid===myId()){s.instructor=S.settings.instructor;s.instructorId=S.settings.instructorId||'';}s.status='signed';s.signedAt=Date.now();s.hash=await sealHash(s);
    put('sessions',s,true);if(s.slotId&&S.schedule[s.slotId]){var sl=S.schedule[s.slotId];sl.sessionId=s.id;sl.status='done';put('schedule',sl,true);}S.ui.cur=null;S.ui.step=1;toast('Evaluación firmada y cerrada');
    S.ui.route='inicio';openSheet({type:'session',id:s.id});},
  openSession:function(el){openSheet({type:'session',id:el.dataset.id});},
  openPilot:function(el){S.ui.pid=el.dataset.id;go('piloto');},
  pf:function(el){S.ui.pf=el.dataset.v;render();},
  newPilot:function(){S.ui.form={name:'',emp:'',base:'BOG',rank:'FO',fleet:(S.ui.setup&&S.ui.setup.fleet)||S.settings.fleets[0]};openSheet({type:'pilot'});},
  editPilot:function(el){S.ui.form=JSON.parse(JSON.stringify(S.trainees[el.dataset.id]));openSheet({type:'pilot',id:el.dataset.id});},
  form:function(el){S.ui.form[el.dataset.k]=el.dataset.v;render();},
  savePilot:function(){var f=S.ui.form;if(!f.name||!f.name.trim())return toast('Escribe el nombre del trainee');var r=Object.assign({},f,{id:f.id||uid('p'),name:f.name.trim()});put('trainees',r,true);
    if(S.ui.setup&&!S.ui.setup.cm1&&r.fleet===S.ui.setup.fleet)S.ui.setup.cm1=r.id;S.ui.sheet=null;render();toast('Trainee guardado');},
  delPilot:function(el){openSheet({type:'confirm',title:'Eliminar trainee',msg:'El trainee dejará de aparecer en la lista. Sus sesiones firmadas se conservan.',act:'delPilotYes',id:el.dataset.id});},
  newTpl:function(){S.ui.form={name:'',module:S.settings.module,fleet:S.settings.fleets[0],phase:'EVAL',note:'',events:[{t:'',c:[]}]};openSheet({type:'tpl'});},
  editTpl:function(el){S.ui.form=JSON.parse(JSON.stringify(S.evals[el.dataset.id]));openSheet({type:'tpl',id:el.dataset.id});},
  useTpl:function(el){var t=S.evals[el.dataset.id];S.ui.cur=null;S.ui.setup=null;vSetup();Object.assign(S.ui.setup,{fleet:t.fleet,module:t.module,phase:t.phase,templateId:t.id});go('evaluar');},
  tplEvAdd:function(){S.ui.form.events.push({t:'',c:[],phase:''});render();},
  tplEvDel:function(el){S.ui.form.events.splice(+el.dataset.i,1);render();},
  tplEvC:function(el){var e=S.ui.form.events[+el.dataset.i];var k=el.dataset.k,i=e.c.indexOf(k);if(i>=0)e.c.splice(i,1);else e.c.push(k);render();},
  saveTpl:function(){var f=S.ui.form;if(!f.name||!f.name.trim())return toast('Escribe un nombre para la plantilla');f.events=(f.events||[]).filter(function(e){return e.t&&e.t.trim();});var r=Object.assign({},f,{id:f.id||uid('t')});delete r.example;r.example=!!f.example;put('evals',r,true);S.ui.sheet=null;render();toast('Plantilla guardada');},
  delTpl:function(el){openSheet({type:'confirm',title:'Eliminar plantilla',msg:'La plantilla se eliminará de la biblioteca para todos los instructores.',act:'delTplYes',id:el.dataset.id});},
  delSession:function(el){var ds=S.sessions[el.dataset.id];if(!isCoord()&&!(ds&&ds.status==='draft'&&isMine(ds)))return toast('Solo Coordinación EBT puede eliminar sesiones firmadas');openSheet({type:'confirm',title:'Eliminar sesión',msg:'La sesión y sus firmas se eliminarán del historial para todos los instructores.',act:'delSessionYes',id:el.dataset.id});},
  confirmYes:function(){var sh=S.ui.sheet;S.ui.sheet=null;
    if(sh.act==='discardYes'){remove('sessions',sh.id);S.ui.cur=null;toast('Borrador descartado');}
    else if(sh.act==='delPilotYes'){remove('trainees',sh.id);go('pilotos');toast('Trainee eliminado');}
    else if(sh.act==='delTplYes'){remove('evals',sh.id);toast('Plantilla eliminada');}
    else if(sh.act==='delSessionYes'){remove('sessions',sh.id);toast('Sesión eliminada');}
    else if(sh.act==='delSlotYes'){remove('schedule',sh.id);toast('Sesión quitada del cronograma');}
    render();},
  closeSheet:function(){S.ui.sheet=null;render();},
  scrim:function(el,e){if(e.target===el){S.ui.sheet=null;render();}},
  pdfSession:function(el){pdfSession(el.dataset.id);},
  pdfPilot:function(el){pdfPilot(el.dataset.id);},
  pdfReport:function(){if(!isCoord())return toast('Solo el Manager EBT genera informes');pdfReport();},
  csv:function(){if(!isCoord())return toast('Solo el Manager EBT exporta datos');csv();},backup:function(){if(!isCoord())return toast('Solo el Manager EBT exporta datos');backup();},
  restore:function(){pickFile(mergeIn);},
  importSched:function(){pickFileText(importSchedule);},
  importTpl:function(){pickFile(importTpl);},
  loadDemo:loadDemo,clearDemo:function(){openSheet({type:'confirm',title:'Borrar ejemplos',msg:'Se eliminarán los trainees, sesiones y plantillas marcados como Ejemplo.',yes:'Borrar',act:'clearDemoYes'});},
  syncNow:function(){if(!DB)return toast('La sincronización está disponible al abrir la app en Claude');if(!online())return toast('Sin conexión: los cambios se subirán al reconectar');flush().then(function(){toast('Sincronizado');});},
  askPilot:function(el){S.ui.aiCtx='p:'+el.dataset.id;S.ui.chat=[];go('asistente');},
  askSession:function(el){S.ui.aiCtx='s:'+el.dataset.id;S.ui.chat=[];go('asistente');},
  aiQuick:function(el){aiAsk(el.dataset.q);},
  aiSend:function(){var i=document.getElementById('ai-in');if(i){var v=i.value;i.value='';aiAsk(v);}},
  aiClear:function(){S.ui.chat=[];render();},
  photo:function(){var i=document.createElement('input');i.type='file';i.accept='image/*';i.onchange=function(){var f=i.files[0];if(!f)return;var r=new FileReader();r.onload=function(){var im=new Image();im.onload=function(){var c=document.createElement('canvas'),sz=160,m=Math.min(im.width,im.height);c.width=sz;c.height=sz;c.getContext('2d').drawImage(im,(im.width-m)/2,(im.height-m)/2,m,m,0,0,sz,sz);S.settings.photo=c.toDataURL('image/jpeg',.85);persist();render();};im.src=r.result;};r.readAsDataURL(f);};i.click();},
  photoClear:function(){S.settings.photo='';persist();render();},
  viewAs:function(el){S.ui.viewAs=el.dataset.v||'';S.ui.onlyMine=null;persist();render();toast(el.dataset.v?'Viendo la app como Instructor':'Vista de Manager');}
};
Object.assign(ACT,AGENDA_ACT,ROLE_ACT,IE_ACT);
var _cy=ACT.confirmYes;ACT.confirmYes=function(){var sh=S.ui.sheet;if(sh&&sh.act==='clearDemoYes'){S.ui.sheet=null;clearDemo();return;}_cy();};

function setPath(obj,path,val){var p=path.split('.');for(var i=0;i<p.length-1;i++){obj=obj[p[i]]=obj[p[i]]||{};}obj[p[p.length-1]]=val;}
document.addEventListener('click',function(e){var el=e.target.closest('[data-act]');if(!el)return;var f=ACT[el.dataset.act];if(!f)return;if(el.tagName==='BUTTON'||el.tagName==='TR')e.preventDefault();f(el,e);});
document.addEventListener('input',function(e){var t=e.target;
  if(t.dataset.bind){setPath(S,t.dataset.bind,t.value);if(t.dataset.resetchat)S.ui.chat=[];persist();if(t.dataset.bind==='ui.q'||t.dataset.rerender)render();else if(t.dataset.bind.indexOf('settings.')===0)renderSide();}
  else if(t.dataset.sb){var s=cur();if(!s)return;setPath(s,t.dataset.sb,t.value);clearTimeout(t._t);t._t=setTimeout(function(){put('sessions',s,true);},400);}
  else if(t.dataset.fb){S.ui.form[t.dataset.fb]=t.value;}
  else if(t.dataset.fe!=null){S.ui.form.events[+t.dataset.fe].t=t.value;}
  else if(t.dataset.fep!=null){S.ui.form.events[+t.dataset.fep].phase=t.value;}
});
document.addEventListener('change',function(e){var t=e.target;
  if(t.dataset.lines){var v=t.value.split('\n').map(function(x){return x.trim();}).filter(Boolean);S.settings[t.dataset.lines]=v;persist();}
  if(t.dataset.list){var v=t.value.split(',').map(function(x){return x.trim();}).filter(Boolean);if(v.length){S.settings[t.dataset.list]=v;if(t.dataset.list==='modules'&&v.indexOf(S.settings.module)<0)S.settings.module=v[0];persist();render();}}
  if(t.tagName==='SELECT'&&t.dataset.bind&&!t.dataset.rerender&&t.dataset.bind.indexOf('ui.setup')===0){render();}
  if(t.dataset.fb&&t.dataset.rerender){render();}
});
document.addEventListener('toggle',function(e){var d=e.target;if(d.classList&&d.classList.contains('disc')){(S.ui.open=S.ui.open||{})[d.dataset.k]=d.open;}},true);
document.addEventListener('keydown',function(e){if(e.target.id==='ai-in'&&e.key==='Enter'&&!e.shiftKey){e.preventDefault();ACT.aiSend();}if(e.target.id==='ev-t'&&e.key==='Enter'){e.preventDefault();ACT.evAddSheet();}if(e.key==='Escape'&&S.ui.sheet){S.ui.sheet=null;render();}});
function renderSide(){var b=document.querySelector('.brand span');if(b)b.textContent='Instructores · '+S.settings.module;}

/* ============ Render ============ */
var VIEWS={inicio:vInicio,evaluar:vEvaluar,pilotos:vPilotos,piloto:vPiloto,biblioteca:vBiblioteca,informes:vInformes,asistente:vAsistente,ajustes:vAjustes,mas:vMas,agenda:vAgenda,instructores:vInstructores,ebtm:vEBTM};
var root;
function render(){
  if(!root)return;
  var a=document.activeElement,aid=a&&a.id,ss=null,se=null;try{ss=a.selectionStart;se=a.selectionEnd;}catch(e){}
  var y=window.scrollY,sh=document.getElementById('sheet'),shy=sh?sh.scrollTop:0;
  var v=VIEWS[S.ui.route]||vInicio;
  var html;try{html=shell(v());}catch(err){console.error(err);html=shell('<div class="card">'+empty('alert','Algo salió mal en esta vista',esc(err.message),'<button class="btn" data-act="go" data-r="inicio">Ir al inicio</button>')+'</div>');}
  root.innerHTML=LOCKED?lockHTML():html+sheetHTML();
  if(!LOCKED)mountSigs();
  window.scrollTo(0,y);var sh2=document.getElementById('sheet');if(sh2)sh2.scrollTop=shy;
  if(aid){var el=document.getElementById(aid);if(el&&el.focus){el.focus({preventScroll:true});try{if(ss!=null)el.setSelectionRange(ss,se);}catch(e){}}}
}
function boot(){
  S=load();root=document.getElementById('root');
  
  if(S.ui.route==='evaluar'&&!cur()&&S.ui.step>1)S.ui.step=1;
  if(!aiOn()){var hs=document.createElement('style');hs.textContent='[data-act="aiDebrief"],[data-act="askSession"],[data-act="askPilot"],[data-r="asistente"]{display:none!important}';document.head.appendChild(hs);}
  sbBoot();if(aiOn())getSample();setTimeout(loadLibs,1500);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
