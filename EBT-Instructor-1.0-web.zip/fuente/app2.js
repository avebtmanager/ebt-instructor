/* ============ Gráficas ============ */
function radar(series){
  var W=340,H=300,cx=170,cy=152,R=108,n=CK.length,out='';
  function pt(i,v){var a=-Math.PI/2+i*2*Math.PI/n,r=R*v/5;return [cx+r*Math.cos(a),cy+r*Math.sin(a)];}
  for(var g=1;g<=5;g++){out+='<polygon points="'+CK.map(function(_,i){return pt(i,g).join(',');}).join(' ')+'" fill="none" stroke="var(--line2)" stroke-width="'+(g===5?1.2:.8)+'"/>';}
  CK.forEach(function(k,i){var e=pt(i,5),l=pt(i,5.9);out+='<line x1="'+cx+'" y1="'+cy+'" x2="'+e[0]+'" y2="'+e[1]+'" stroke="var(--line)"/>';
    out+='<text class="lbl" x="'+l[0]+'" y="'+(l[1]+4)+'" text-anchor="middle" style="font-family:var(--mono);font-size:11px">'+k+'</text>';});
  [2,4].forEach(function(g){var p=pt(0,g);out+='<text x="'+(p[0]+5)+'" y="'+(p[1]+3)+'" style="font-size:9.5px">'+g+'</text>';});
  series.forEach(function(s){
    var pts=CK.map(function(k,i){return pt(i,s.vals[k]||0);});
    out+='<polygon points="'+pts.map(function(p){return p.join(',');}).join(' ')+'" fill="'+s.color+'" fill-opacity=".14" stroke="'+s.color+'" stroke-width="2" stroke-linejoin="round"/>';
    pts.forEach(function(p,i){if(s.vals[CK[i]])out+='<circle cx="'+p[0]+'" cy="'+p[1]+'" r="3.2" fill="'+s.color+'"/>';});
  });
  return '<div class="chart"><svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Perfil de competencias">'+out+'</svg></div>';
}
function trend(points,color){
  if(!points.length)return '<p class="muted small">Sin sesiones firmadas todavía.</p>';
  var W=460,H=200,L=26,Rr=16,T=14,B=28,iw=W-L-Rr,ih=H-T-B,out='';
  function y(v){return T+ih-(v-1)/4*ih;}
  function x(i){return points.length===1?L+iw/2:L+i*iw/(points.length-1);}
  for(var g=1;g<=5;g++){out+='<line x1="'+L+'" x2="'+(W-Rr)+'" y1="'+y(g)+'" y2="'+y(g)+'" stroke="var(--line)" '+(g===2?'stroke-dasharray="4 4" stroke="var(--line2)"':'')+'/><text x="'+(L-10)+'" y="'+(y(g)+4)+'" text-anchor="end">'+g+'</text>';}
  var d=points.map(function(p,i){return (i?'L':'M')+x(i)+' '+y(p.v);}).join(' ');
  if(points.length>1)out+='<path d="'+d+' L'+x(points.length-1)+' '+(T+ih)+' L'+x(0)+' '+(T+ih)+' Z" fill="'+color+'" fill-opacity=".08"/>';
  out+='<path d="'+d+'" fill="none" stroke="'+color+'" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/>';
  var step=Math.ceil(points.length/7);
  points.forEach(function(p,i){var last=i===points.length-1;
    out+='<circle cx="'+x(i)+'" cy="'+y(p.v)+'" r="'+(last?5:3.5)+'" fill="'+(last?color:'var(--surface)')+'" stroke="'+color+'" stroke-width="2"><title>'+esc(p.label+': '+f1(p.v))+'</title></circle>';
    if(i%step===0||last)out+='<text x="'+x(i)+'" y="'+(H-10)+'" text-anchor="middle">'+esc(p.label)+'</text>';
    if(last)out+='<text class="lbl" x="'+x(i)+'" y="'+(y(p.v)-11)+'" text-anchor="middle">'+f1(p.v)+'</text>';});
  return '<div class="chart"><svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Tendencia">'+out+'</svg></div>';
}
function hbars(vals,counts,ref){
  return '<div style="display:flex;flex-direction:column;gap:9px">'+CK.map(function(k){var v=vals[k]||0;var rv=ref&&ref[k];
    return '<div style="display:grid;grid-template-columns:44px minmax(0,1fr) 38px;gap:10px;align-items:center" title="'+esc(CMAP[k].es)+'"><span class="code" style="text-align:center">'+k+'</span>'+
    '<div style="height:12px;border-radius:99px;background:var(--line);position:relative"><div style="height:100%;width:'+(v/5*100)+'%;background:'+gvar(v)+';border-radius:99px"></div>'+(rv?'<div title="Grupo '+f1(rv)+'" style="position:absolute;top:-3px;bottom:-3px;left:'+(rv/5*100)+'%;width:2px;background:var(--fg);border-radius:2px"></div>':'')+'</div>'+
    '<span class="num small" style="font-weight:650;text-align:right">'+f1(v)+'</span></div>';}).join('')+'</div>';
}
function dist(sessions){
  var rows=CK.map(function(k){var c=[0,0,0,0,0,0];sessions.forEach(function(s){seats(s).forEach(function(x){var g=s.grades[x]&&s.grades[x][k];if(g&&g.g)c[g.g]++;});});return {k:k,c:c,t:c.reduce(function(a,b){return a+b;},0)};});
  return '<div style="display:flex;flex-direction:column;gap:8px">'+rows.map(function(r){
    return '<div style="display:grid;grid-template-columns:44px minmax(0,1fr) 34px;gap:10px;align-items:center"><span class="code" style="text-align:center">'+r.k+'</span><div style="display:flex;height:14px;border-radius:5px;overflow:hidden;background:var(--line);gap:1px">'+
    [1,2,3,4,5].map(function(g){return r.c[g]?'<div title="Grado '+g+': '+r.c[g]+'" style="width:'+(r.c[g]/r.t*100)+'%;background:var(--g'+g+')"></div>':'';}).join('')+
    '</div><span class="num tiny muted" style="text-align:right">'+r.t+'</span></div>';}).join('')+'</div>'+
    '<div class="legend" style="margin-top:12px">'+[1,2,3,4,5].map(function(g){return '<span><i style="background:var(--g'+g+')"></i>'+g+' · '+GS[g]+'</span>';}).join('')+'</div>';
}
function compAverages(sessions){var v={};CK.forEach(function(k){var a=[];sessions.forEach(function(s){seats(s).forEach(function(x){var g=s.grades[x]&&s.grades[x][k];if(g&&g.g)a.push(g.g);});});v[k]=avg(a);});return v;}
function gradesOf(s,seat){var v={},g=(s.grades||{})[seat]||{};CK.forEach(function(k){v[k]=g[k]?g[k].g:0;});return v;}

/* ============ Vistas ============ */
var NAV=[['inicio','Inicio','home'],['agenda','Agenda','cal'],['evaluar','Evaluar','eval'],['pilotos','Trainees','people'],['biblioteca','Biblioteca EVAL','book'],['informes','Informes','chart'],['instructores','Instructores','people'],['ebtm','Diseño EBT Manager','cloud'],['asistente','Asistente IA','spark'],['ajustes','Ajustes','gear']];
var TABS=[['inicio','Inicio','home'],['agenda','Agenda','cal'],['evaluar','Evaluar','eval'],['pilotos','Trainees','people'],['mas','Más','more']];
function shell(content){
  var r=S.ui.route,act=r==='piloto'?'pilotos':r;
  var drafts=live('sessions').filter(function(s){return s.status==='draft';}).length;
  return '<div class="app"><aside class="side"><div class="brand"><img class="brand-mark" src="'+LOGO+'" alt="" style="object-fit:contain"><div><b>EBT Instructor</b><span><span class="pill '+(isCoord()?'acc':'')+'" style="height:18px;font-size:10.5px;padding:0 7px">'+roleLabel()+'</span> · '+esc(S.settings.module)+'</span></div></div>'+
   NAV.filter(function(n){return isCoord()||(n[0]!=='informes'&&n[0]!=='instructores'&&n[0]!=='ebtm');}).map(function(n){return '<button class="nav'+(act===n[0]?' on':'')+'" data-act="go" data-r="'+n[0]+'">'+I[n[2]]+n[1]+(n[0]==='evaluar'&&drafts?'<span class="badge">'+drafts+'</span>':'')+(n[0]==='agenda'&&unreadNotices()?'<span class="badge">'+unreadNotices()+'</span>':'')+'</button>';}).join('')+
   '<div class="side-foot" data-sync>'+syncHTML()+'</div></aside><main class="main" id="main">'+topbar()+content+'</main>'+
   '<nav class="tabbar">'+TABS.map(function(t){var on=act===t[0]||(t[0]==='mas'&&['biblioteca','informes','ajustes','mas','asistente','ebtm','instructores'].indexOf(act)>=0);var bd=t[0]==='agenda'?unreadNotices():t[0]==='evaluar'?drafts:0;return '<button class="tab'+(on?' on':'')+'" data-act="go" data-r="'+t[0]+'" style="position:relative">'+I[t[2]]+t[1]+(bd?'<span class="badge" style="position:absolute;top:0;right:calc(50% - 22px)">'+bd+'</span>':'')+'</button>';}).join('')+'</nav></div>';
}
function topbar(){
  var st=S.settings,i=syncInfo(),col={ok:'var(--ok)',warn:'var(--warn)',bad:'var(--bad)',acc:'var(--accent)'}[i.c]||'var(--faint)';var n=unreadNotices();
  return '<div class="topbar"><div class="who" style="flex:1">'+(st.photo?'<img src="'+st.photo+'" alt="">':'<span class="avatar">'+initials(st.instructor||'?')+'</span>')+'<span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(st.instructor||'Instructor')+'</span>'+(st.instructorId?'<span class="pill" style="height:20px">'+esc(st.instructorId)+'</span>':'')+(realCoord()?'<span class="seg" style="padding:2px;height:26px"><button class="'+(!S.ui.viewAs?'on':'')+'" data-act="viewAs" data-v="" style="padding:2px 9px;font-size:11.5px">Manager</button><button class="'+(S.ui.viewAs==='instructor'?'on':'')+'" data-act="viewAs" data-v="instructor" style="padding:2px 9px;font-size:11.5px">Instructor</button></span>':'<span class="pill" style="height:20px">'+roleLabel()+'</span>')+'</div>'+
   '<button class="syncpill" data-act="syncNow" data-sync-pill title="'+esc(i.d)+'"><span class="dot" style="background:'+col+'"></span>'+esc(i.t)+'</button>'+
   '<button class="iconbtn" data-act="go" data-r="agenda" aria-label="Avisos">'+I.bell+(n?'<span class="badge">'+n+'</span>':'')+'</button></div>'+
   (realCoord()&&S.ui.viewAs==='instructor'?'<div class="note" style="display:flex;align-items:center;gap:10px;margin:-6px 0 16px;background:var(--warn-soft);border-color:transparent;color:var(--warn)"><b style="flex:1">Estás viendo la app como Instructor.</b><button class="btn sm" data-act="viewAs" data-v="">Volver a Manager</button></div>':'');
}
function head(title,sub,actions){return '<div class="page-head"><div style="min-width:0"><h1>'+title+'</h1>'+(sub?'<p class="sub">'+sub+'</p>':'')+'</div><div class="row">'+(actions||'')+'</div></div>';}
function empty(icon,t,d,btn){return '<div class="empty">'+I[icon]+'<h3>'+t+'</h3><p class="small" style="max-width:420px">'+d+'</p>'+(btn||'')+'</div>';}
function sessRow(s,showCrew){
  var ss=seats(s),av=avg(ss.map(function(x){return sessAvg(s,x);}));
  var crew=ss.map(function(x){return esc(pname(s.pilots[x]));}).join(' · ');
  return '<button class="li" data-act="openSession" data-id="'+s.id+'"><span class="gchip '+gcls(av)+'" style="width:38px;height:38px;border-radius:10px;font-size:14px">'+(av?f1(av):'–')+'</span><div class="grow"><div class="t">'+esc(s.phase)+' · '+esc(s.module)+'</div><div class="small muted" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+fdate(s.date)+' · '+esc(s.fleet)+(showCrew!==false?' · '+crew:'')+'</div></div>'+
    (s.status==='draft'?'<span class="pill warn">Borrador</span>':'<span class="pill ok">'+I.check.replace('<svg','<svg width="11" height="11"')+'Firmada</span>')+(s.example?'<span class="pill">Ejemplo</span>':'')+I.chev+'</button>';
}
function hasData(){return live('trainees').length||live('sessions').length;}

function vInicio(){
  var st=S.settings,all=live('sessions'),signed=all.filter(function(s){return s.status==='signed';});
  var mod=signed.filter(function(s){return s.module===st.module;});
  var drafts=all.filter(function(s){return s.status==='draft';});
  var evaluated={};mod.forEach(function(s){seats(s).forEach(function(x){evaluated[s.pilots[x]]=1;});});
  var alerts=[];var lastBy={};
  signed.slice().sort(sortByDate).forEach(function(s){seats(s).forEach(function(x){lastBy[s.pilots[x]]={s:s,seat:x};});});
  Object.keys(lastBy).forEach(function(pid){var o=lastBy[pid];if(!pilot(pid))return;CK.forEach(function(k){var g=o.s.grades[o.seat][k];if(g&&g.g&&g.g<=2)alerts.push({pid:pid,k:k,g:g.g,s:o.s});});});
  alerts.sort(function(a,b){return a.g-b.g;});
  var h=new Date().getHours(),greet=h<12?'Buenos días':h<19?'Buenas tardes':'Buenas noches';
  var html=head(greet+(st.instructor?', '+esc(st.instructor.split(' ').slice(0,3).join(' ')):''),'<b>'+roleLabel()+'</b> · Módulo en curso: '+esc(st.module)+' · '+fdate(today()),'<button class="btn primary" data-act="newEval">'+I.plus+'Nueva evaluación</button>');
  if(ieBlocked())return html+blockedHTML();
  if(!hasData()){
    return html+'<div class="card">'+empty('eval','Empieza tu bitácora','Registra a tus trainees y crea tu primera evaluación. Todo se guarda en este dispositivo y se sincroniza con la base de datos cuando hay conexión.','<div class="row" style="justify-content:center"><button class="btn primary" data-act="newPilot">'+I.plus+'Agregar trainee</button></div>')+'</div>';
  }
  html+=profileCard();
  html+=backupCard();
  var me=myStats(signed);
  if(isCoord()){html+='<div class="grid g4" style="margin-bottom:16px">'+
   kpi('Sesiones del módulo',mod.length,'firmadas en '+st.module,'','informes')+kpi('Trainees evaluados',Object.keys(evaluated).length,'de '+live('trainees').length+' registrados','','trainees')+
   kpi('Alertas de grado ≤ 2',alerts.length,'en la última sesión de cada trainee',alerts.length?'var(--bad)':'','alerts')+kpi('Borradores abiertos',drafts.length,'de todos los instructores',drafts.length?'var(--warn)':'','evaluar')+'</div>';}
  else{html+='';}
  html+='<div class="eyebrow" style="margin-bottom:8px">Acceso rápido</div><div class="quick" style="margin-bottom:16px">'+[['newEval','','eval','Nueva evaluación','Un trainee o tripulación'],['go','agenda','cal','Agenda','Cronograma y avisos'],['go','pilotos','people','Trainees','Historial y falencias'],['go','biblioteca','book','Biblioteca EVAL','Plantillas por módulo'],['go','informes','chart','Informes','Calibración y exportación'],['go','asistente','spark','Asistente IA','Debriefings y análisis']].filter(function(q){return isCoord()||q[1]!=='informes';}).map(function(q){return '<button data-act="'+q[0]+'"'+(q[1]?' data-r="'+q[1]+'"':'')+'>'+I[q[2]]+'<b>'+q[3]+'</b><span>'+q[4]+'</span></button>';}).join('')+
   '<button class="'+(pending()?'warnq':'')+'" data-act="syncNow">'+I.cloud+'<b>'+(pending()?pending()+' por sincronizar':'Sincronizado')+'</b><span>'+esc(syncInfo().d)+'</span></button></div>';
  html+=inicioAgenda();
  if(drafts.length){html+='<div class="card" style="margin-bottom:16px;display:flex;align-items:center;gap:14px;flex-wrap:wrap"><span class="gchip gc2" style="width:40px;height:40px;border-radius:12px">'+I.pen.replace('<svg','<svg width="20" height="20"')+'</span><div style="flex:1;min-width:200px"><h3>Tienes '+drafts.length+' evaluación'+(drafts.length>1?'es':'')+' sin cerrar</h3><p class="small muted">'+drafts.slice(0,2).map(function(s){return esc(s.phase)+' · '+seats(s).map(function(x){return esc(pname(s.pilots[x]));}).join(' / ');}).join(' — ')+'</p></div><button class="btn" data-act="resume" data-id="'+drafts[0].id+'">Continuar</button></div>';}
  var avgs=compAverages(mod.length?mod:signed);
  html+='<div class="grid '+(isCoord()?'g2':'')+'">'+(isCoord()?'<div class="card"><div class="card-head"><div><h3>Promedio por competencia</h3><p class="small muted">'+(mod.length?esc(st.module):'Todas las sesiones')+' · escala 1–5</p></div></div>'+hbars(avgs)+'</div>':'')+
   '<div class="card" id="alertas"><div class="card-head"><div><h3>Alertas para el próximo módulo</h3><p class="small muted">Competencias con grado 1–2 en la última sesión</p></div></div>'+
   (alerts.length?alerts.slice(0,7).map(function(a){return '<div class="flag"><span class="gchip '+gcls(a.g)+'">'+a.g+'</span><div style="flex:1;min-width:0"><div style="font-weight:600">'+esc(pname(a.pid))+'</div><div class="small muted">'+a.k+' · '+esc(CMAP[a.k].es)+' · '+esc(a.s.phase)+' '+fdateShort(a.s.date)+'</div></div><button class="btn sm" data-act="openPilot" data-id="'+a.pid+'">Ver</button></div>';}).join(''):'<p class="muted small">Sin alertas. Ningún trainee tiene competencias en 1 o 2 en su última sesión.</p>')+'</div></div>';
  var recent=all.filter(function(s){return isCoord()||isMine(s);}).sort(sortByDate).reverse().slice(0,6);
  html+='<div style="margin-top:22px" class="card-head"><h2>'+(isCoord()?'Sesiones recientes':'Mis sesiones recientes')+'</h2>'+(isCoord()?'<button class="btn ghost" data-act="go" data-r="informes">Ver todas</button>':'')+'</div><div class="list">'+recent.map(function(s){return sessRow(s);}).join('')+'</div>';
  return html;
}
function profileCard(){
  var st=S.settings;if(!st.instructor&&!st.photo)return '';
  var quals=(st.quals||'').split(/[,;·]/).map(function(q){return q.trim();}).filter(Boolean);
  return '<div class="card" style="margin-bottom:16px"><div class="profile">'+(st.photo?'<img class="ph" src="'+st.photo+'" alt="Foto">':'<span class="avatar ph">'+initials(st.instructor)+'</span>')+'<div style="flex:1;min-width:200px"><div class="eyebrow">'+esc([st.rank==='CPT'?'Capitán':st.rank==='FO'?'Primer oficial':'',st.fleet?'Flota '+st.fleet:'',roleLabel()].filter(Boolean).join(' · '))+'</div><h2>'+esc(st.instructor)+(st.instructorId?' <span class="pill" style="vertical-align:middle">'+esc(st.instructorId)+'</span>':'')+'</h2>'+(quals.length?'<div class="quals" style="margin-top:6px">'+quals.map(function(q){return '<span class="pill acc">'+esc(q)+'</span>';}).join('')+'</div>':'<p class="small muted">Agrega tus habilitaciones (TRI, SFI, SFE, LTC…) en Ajustes.</p>')+'</div><div style="text-align:right"><div class="eyebrow">Licencia</div><div style="font-weight:600;font-variant-numeric:tabular-nums">'+esc(st.license||'—')+'</div><div class="eyebrow" style="margin-top:8px">Hoy</div><div style="font-weight:600">'+fdate(today())+'</div></div></div></div>';
}
function myWeek(){var t=today(),d=new Date();d.setDate(d.getDate()+7);var lim=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');var me=S.settings.instructor;
  return {next7:live('schedule').filter(function(s){return isMine(s)&&s.date>=t&&s.date<=lim&&s.status!=='cancelled';}).length,drafts:live('sessions').filter(function(s){return s.status==='draft'&&s.instructor===me;}).length};}
function myStats(signed){
  var me=S.settings.instructor,cut=Date.now()-30*864e5,mine=[],all=[],n30=0,s30=0;
  signed.forEach(function(s){var isMe=isMine(s);var recent=(s.signedAt||0)>=cut;seats(s).forEach(function(x){var g=s.grades[x]||{};CK.forEach(function(k){if(g[k]&&g[k].g){all.push(g[k].g);if(isMe){mine.push(g[k].g);if(recent)n30++;}}});if(isMe&&recent)s30++;});});
  return {n:mine.length,n30:n30,s30:s30,mean:avg(mine),group:avg(all)};
}
function cycleProgress(pid){
  var mods=S.settings.modules||[],ss=pilotSessions(pid).filter(function(s){return s.status==='signed';});
  var done={};ss.forEach(function(s){done[s.module]=1;});var nm=mods.filter(function(m){return done[m];}).length;
  var te={};ss.forEach(function(s){(s.events||[]).forEach(function(e){if(e.done)te[String(e.t).trim().toLowerCase()]=1;});});
  var lib={};live('evals').forEach(function(t){(t.events||[]).forEach(function(e){lib[String(e.t).trim().toLowerCase()]=1;});});Object.keys(te).forEach(function(k){lib[k]=1;});
  var last=ss[ss.length-1],ok=0;if(last){var g=last.grades[seatOf(last,pid)];ok=CK.filter(function(k){return g[k]&&g[k].g>=3;}).length;}
  function bar(l,v,t,d){var p=t?Math.round(v/t*100):0;return '<div style="margin-bottom:10px"><div class="row" style="gap:8px;margin-bottom:4px"><span class="small" style="flex:1;font-weight:600">'+l+'</span><span class="small num"><b>'+v+'</b> de '+t+' · '+p+'%</span></div><div class="progress"><div style="width:'+p+'%;background:'+(p>=100?'var(--ok)':p>=50?'var(--accent)':'var(--warn)')+'"></div></div><div class="tiny muted" style="margin-top:3px">'+d+'</div></div>';}
  return '<div class="card"><div class="card-head"><div><h3>Progreso del ciclo EBT</h3><p class="small muted">Ciclo de '+mods.length+' módulos</p></div></div>'+bar('Módulos con sesión firmada',nm,mods.length,mods.filter(function(m){return done[m];}).join(', ')||'Ninguno todavía')+bar('Training elements cubiertos',Object.keys(te).length,Object.keys(lib).length||1,'Eventos completados frente a los de la biblioteca EVAL')+bar('Competencias ≥ 3 en el último módulo',ok,9,last?last.phase+' '+fdate(last.date):'Sin sesiones')+'</div>';
}
function kpi(l,v,d,col,go){return '<div class="card kpi"'+(go?' data-act="kpiGo" data-t="'+go+'" style="cursor:pointer"':'')+'><div class="eyebrow">'+l+'</div><div class="v"'+(col?' style="color:'+col+'"':'')+'>'+v+'</div><div class="d">'+esc(d)+'</div></div>';}

function vPilotos(){
  var q=(S.ui.q||'').toLowerCase(),fl=S.ui.pf||'';
  var ps=live('trainees').filter(function(p){return (!fl||p.fleet===fl)&&(!q||(p.name+' '+p.emp+' '+p.base).toLowerCase().indexOf(q)>=0);}).sort(function(a,b){return a.name.localeCompare(b.name);});
  var html=head('Trainees',live('trainees').length+' registrados','<button class="btn primary" data-act="newPilot">'+I.plus+'Agregar trainee</button>');
  html+='<div class="row" style="margin-bottom:14px"><div class="search" style="flex:1;min-width:220px">'+I.search+'<input class="input" id="q" data-bind="ui.q" placeholder="Buscar por nombre, código o base" value="'+esc(S.ui.q||'')+'"></div><div class="seg">'+['','A320','B787'].map(function(f){return '<button class="'+(fl===f?'on':'')+'" data-act="pf" data-v="'+f+'">'+(f||'Todas')+'</button>';}).join('')+'</div></div>';
  if(!ps.length)return html+'<div class="card">'+empty('people','Sin trainees','Agrega trainees para evaluarlos y llevar su historial.','<button class="btn primary" data-act="newPilot">'+I.plus+'Agregar trainee</button>')+'</div>';
  html+='<div class="list">'+ps.map(function(p){var ss=pilotSessions(p.id).filter(function(s){return s.status==='signed';});var last=ss[ss.length-1];var la=last?sessAvg(last,seatOf(last,p.id)):0;
    var low=last?CK.filter(function(k){var g=last.grades[seatOf(last,p.id)][k];return g&&g.g&&g.g<=2;}):[];
    return '<button class="li" data-act="openPilot" data-id="'+p.id+'"><span class="avatar">'+initials(p.name)+'</span><div class="grow"><div class="t">'+esc(p.name)+'</div><div class="small muted">'+esc(p.rank==='CPT'?'Capitán':'Primer oficial')+' · '+esc(p.fleet)+' · '+esc(p.base||'')+(p.emp?' · #'+esc(p.emp):'')+'</div></div>'+
    (low.length?'<span class="pill bad">'+low.join(' ')+'</span>':'')+(p.example?'<span class="pill">Ejemplo</span>':'')+'<span class="small muted num" style="min-width:64px;text-align:right">'+ss.length+' sesión'+(ss.length===1?'':'es')+'</span><span class="gchip '+gcls(la)+'" style="width:34px">'+(la?f1(la):'–')+'</span>'+I.chev+'</button>';}).join('')+'</div>';
  return html;
}

function vPiloto(){
  var p=pilot(S.ui.pid);if(!p){S.ui.route='pilotos';return vPilotos();}
  var ss=pilotSessions(p.id),signed=ss.filter(function(s){return s.status==='signed';});
  var last=signed[signed.length-1],prev=signed[signed.length-2];
  var html='<button class="btn ghost" data-act="go" data-r="pilotos" style="margin:-6px 0 8px -8px">'+I.back+'Trainees</button>';
  html+=head(esc(p.name),esc(p.rank==='CPT'?'Capitán':'Primer oficial')+' · '+esc(p.fleet)+' · '+esc(p.base||'—')+(p.emp?' · #'+esc(p.emp):'')+(p.example?' · <span class="pill">Ejemplo</span>':''),
   '<button class="btn" data-act="editPilot" data-id="'+p.id+'">'+I.pen+'Editar</button><button class="btn" data-act="pdfPilot" data-id="'+p.id+'">'+I.down+'Historial PDF</button><button class="btn" data-act="askPilot" data-id="'+p.id+'">'+I.spark+'Analizar con IA</button><button class="btn primary" data-act="newEval" data-pid="'+p.id+'">'+I.plus+'Evaluar</button>');
  if(!signed.length){return html+'<div class="card">'+empty('chart','Sin sesiones firmadas','Cuando cierres y firmes una evaluación de este trainee verás aquí su perfil de competencias y su evolución.','<button class="btn primary" data-act="newEval" data-pid="'+p.id+'">'+I.plus+'Evaluar ahora</button>')+'</div>'+(ss.length?'<div class="list" style="margin-top:16px">'+ss.map(function(s){return sessRow(s);}).join('')+'</div>':'');}
  var lv=gradesOf(last,seatOf(last,p.id)),pv=prev?gradesOf(prev,seatOf(prev,p.id)):null;
  var series=[{name:'Última',color:'var(--accent)',vals:lv}];if(pv)series.unshift({name:'Anterior',color:'var(--g3)',vals:pv});
  var pts=signed.map(function(s){return {label:s.phase+' '+fdateShort(s.date),v:sessAvg(s,seatOf(s,p.id))};});
  html+='<div class="grid g2"><div class="card"><div class="card-head"><div><h3>Perfil de competencias</h3><p class="small muted">'+esc(last.phase)+' '+fdate(last.date)+(prev?' comparado con '+esc(prev.phase)+' '+fdate(prev.date):'')+'</p></div></div>'+radar(series)+
   '<div class="legend" style="justify-content:center">'+(pv?'<span><i style="background:var(--g3)"></i>Anterior</span>':'')+'<span><i style="background:var(--accent)"></i>Última sesión</span></div></div>'+
   '<div class="stack"><div class="card"><div class="card-head"><div><h3>Evolución del promedio</h3><p class="small muted">Promedio de las 9 competencias por sesión</p></div></div>'+trend(pts,'var(--accent)')+'</div>'+
   '<div class="card"><h3 style="margin-bottom:10px">Foco sugerido</h3>'+focusList(last,seatOf(last,p.id))+'</div></div></div>';
  html+='<div class="grid g2" style="margin-top:16px">'+attentionCard(p.id)+cycleProgress(p.id)+'</div>';
  var tst=temStats(pilotSessions(p.id).filter(function(s){return s.status==='signed';}),p.id);if(tst.n)html+='<div class="card" style="margin-top:16px"><div class="card-head"><div><h3>TEM · Nivel 3</h3><p class="small muted">Amenazas, errores y estados indeseados registrados en sus sesiones</p></div></div>'+temChart(tst)+'</div>';
  html+='<div class="card" style="margin-top:16px"><div class="card-head"><div><h3>Mapa de calor del historial</h3><p class="small muted">Grado por competencia en cada sesión firmada</p></div></div><div class="scroll-x"><table class="heat"><thead><tr><th></th>'+signed.map(function(s){return '<th>'+esc(s.phase)+'<br><span style="font-weight:500">'+fdateShort(s.date)+'</span></th>';}).join('')+'</tr></thead><tbody>'+
   CK.map(function(k){return '<tr><th class="r" title="'+esc(CMAP[k].es)+'">'+k+'</th>'+signed.map(function(s){var g=s.grades[seatOf(s,p.id)][k];var v=g&&g.g;return '<td style="background:'+gvar(v)+'">'+(v||'')+'</td>';}).join('')+'</tr>';}).join('')+'</tbody></table></div></div>';
  html+='<div style="margin-top:22px" class="card-head"><h2>Historial</h2></div><div class="list">'+ss.slice().reverse().map(function(s){return sessRow(s);}).join('')+'</div>';
  return html;
}
function weaknesses(pid){
  var ss=pilotSessions(pid).filter(function(s){return s.status==='signed';});
  var comp={},obs={},evs={};
  ss.forEach(function(s){var x=seatOf(s,pid),g=s.grades[x]||{};
    CK.forEach(function(k){var e=g[k]||{};
      if(e.g&&e.g<=2){var c=comp[k]||(comp[k]={k:k,n:0,last:'',lastG:0,phase:''});c.n++;if(s.date>=c.last){c.last=s.date;c.lastG=e.g;c.phase=s.phase;}
        (s.events||[]).forEach(function(ev){if((ev.c||[]).indexOf(k)>=0){var o=evs[ev.t]||(evs[ev.t]={t:ev.t,n:0,ks:{},last:''});o.n++;o.ks[k]=1;if(s.date>o.last)o.last=s.date;}});}
      var ob=e.ob||{};Object.keys(ob).forEach(function(q){if(ob[q]<0){var o=obs[k+' '+q]||(obs[k+' '+q]={k:k,o:q,n:0});o.n++;}});});});
  function arr(o){return Object.keys(o).map(function(k){return o[k];});}
  return {sessions:ss.length,comp:arr(comp).sort(function(a,b){return b.n-a.n||a.lastG-b.lastG;}),obs:arr(obs).sort(function(a,b){return b.n-a.n;}),events:arr(evs).sort(function(a,b){return b.n-a.n;})};
}
function attentionCard(pid){
  var w=weaknesses(pid);
  var html='<div class="card"><div class="card-head"><div><h3>Áreas de atención</h3><p class="small muted">Competencias, OB y maniobras con grado 1–2 en el historial firmado</p></div></div>';
  if(!w.comp.length&&!w.obs.length)return html+'<p class="small muted">Sin competencias en grado 1–2 ni OB deficientes en '+w.sessions+' sesión'+(w.sessions===1?'':'es')+' firmada'+(w.sessions===1?'':'s')+'.</p></div>';
  if(w.comp.length)html+='<div class="eyebrow" style="margin-bottom:4px">Competencias</div>'+w.comp.map(function(c){return '<div class="attn"><span class="gchip '+gcls(c.lastG)+'">'+c.lastG+'</span><div style="min-width:0"><b>'+c.k+'</b> <span class="small muted">'+esc(CMAP[c.k].es)+'</span></div><span class="small muted num" style="text-align:right">'+c.n+'× · última '+esc(c.phase)+' '+fdateShort(c.last)+'</span></div>';}).join('')+riskChips(w.comp.map(function(c){return {k:c.k,g:c.lastG};}),true);
  if(w.obs.length)html+='<div class="eyebrow" style="margin:12px 0 6px">OB deficientes recurrentes</div><div class="tags">'+w.obs.slice(0,10).map(function(o){return '<span class="tag" style="color:var(--bad)" title="'+esc(obText(o.k,o.o))+'">OB '+o.o+(o.n>1?' ×'+o.n:'')+'</span>';}).join('')+'</div>';
  if(w.events.length)html+='<div class="eyebrow" style="margin:12px 0 4px">Maniobras y procedimientos por reforzar</div>'+w.events.map(function(e){return '<div class="attn" style="grid-template-columns:minmax(0,1fr) auto"><div style="min-width:0"><div style="font-weight:550">'+esc(e.t)+'</div><div class="tags">'+Object.keys(e.ks).map(function(k){return '<span class="tag" style="color:var(--bad)">'+k+'</span>';}).join('')+'</div></div><span class="small muted num">'+e.n+'× · '+fdateShort(e.last)+'</span></div>';}).join('');
  return html+'</div>';
}
function focusList(s,seat){
  var g=s.grades[seat]||{};
  var f=CK.filter(function(k){return g[k]&&g[k].g&&g[k].g<=2;});
  var negs=[];CK.forEach(function(k){var ob=(g[k]&&g[k].ob)||{};Object.keys(ob).forEach(function(o){if(ob[o]<0)negs.push({k:k,o:o});});});
  if(!f.length&&!negs.length)return '<p class="small muted">Sin competencias en 1–2 ni OB marcados como deficientes en la última sesión.</p>';
  return '<div style="display:flex;flex-direction:column;gap:8px">'+f.map(function(k){return '<div class="row" style="gap:8px"><span class="gchip '+gcls(g[k].g)+'">'+g[k].g+'</span><b>'+k+'</b><span class="small muted">'+esc(CMAP[k].es)+'</span></div>';}).join('')+
   (negs.length?'<div class="small muted" style="margin-top:4px">OB deficientes: '+negs.map(function(n){return '<span class="tag" title="'+esc(obText(n.k,n.o))+'">OB '+n.o+'</span>';}).join(' ')+'</div>':'')+'</div>';
}
function obText(k,o){var r=CMAP[k].ob.filter(function(x){return x[0]===o;})[0];return r?r[1]:'';}

function vBiblioteca(){
  var ts=live('evals').sort(function(a,b){return (a.module+a.fleet+a.phase).localeCompare(b.module+b.fleet+b.phase);});
  var html=head('Biblioteca EVAL','Plantillas de evaluación por módulo, flota y fase. Al evaluar, la plantilla carga los eventos y las competencias asociadas.',isCoord()?'<button class="btn" data-act="importTpl">'+I.up+'Importar JSON</button><button class="btn primary" data-act="newTpl">'+I.plus+'Nueva plantilla</button>':'<span class="pill">Solo lectura · gestiona Coordinación</span>');
  if(!ts.length)return html+'<div class="card">'+empty('book','Sin plantillas','Crea plantillas con los eventos de cada módulo EBT (EVAL, MT, SBT) para reutilizarlas en cada sesión.','<button class="btn primary" data-act="newTpl">'+I.plus+'Nueva plantilla</button>')+'</div>';
  var groups={};ts.forEach(function(t){(groups[t.module]=groups[t.module]||[]).push(t);});
  Object.keys(groups).forEach(function(m){
    html+='<div class="eyebrow" style="margin:18px 0 8px">'+esc(m)+'</div><div class="grid g3">'+groups[m].map(function(t){
      var cs={};(t.events||[]).forEach(function(e){(e.c||[]).forEach(function(c){cs[c]=1;});});
      return '<div class="card" style="display:flex;flex-direction:column;gap:10px"><div class="row" style="gap:6px"><span class="pill acc">'+esc(t.phase)+'</span><span class="pill">'+esc(t.fleet)+'</span>'+(t.example?'<span class="pill">Ejemplo</span>':'')+(t.em?'<span class="pill ok">EBT Manager</span>':'')+'</div><h3>'+esc(t.name)+'</h3>'+
      '<ol class="small" style="margin:0;padding-left:18px;color:var(--muted);display:flex;flex-direction:column;gap:3px">'+(t.events||[]).map(function(e){return '<li>'+esc(e.t)+'</li>';}).join('')+'</ol>'+
      '<div class="tags">'+CK.filter(function(k){return cs[k];}).map(function(k){return '<span class="tag">'+k+'</span>';}).join('')+'</div>'+
      '<div class="row" style="margin-top:auto">'+(isCoord()?'<button class="btn sm" data-act="editTpl" data-id="'+t.id+'">'+I.pen+'Editar</button>':'')+'<button class="btn sm primary" data-act="useTpl" data-id="'+t.id+'">Usar</button></div></div>';}).join('')+'</div>';
  });
  return html;
}

function vInformes(){
  if(!isCoord()){S.ui.route='inicio';return vInicio();}
  var f=S.ui.rf||(S.ui.rf={module:'',fleet:'',phase:''});
  var ss=live('sessions').filter(function(s){return s.status==='signed'&&(!f.module||s.module===f.module)&&(!f.fleet||s.fleet===f.fleet)&&(!f.phase||s.phase===f.phase);}).sort(sortByDate).reverse();
  var mods={};live('sessions').forEach(function(s){mods[s.module]=1;});S.settings.modules.forEach(function(m){mods[m]=1;});
  function sel(id,key,opts,lbl){return '<div class="field" style="min-width:150px;flex:1"><label for="'+id+'">'+lbl+'</label><select class="input" id="'+id+'" data-bind="ui.rf.'+key+'" data-rerender="1"><option value="">Todos</option>'+opts.map(function(o){return '<option'+(f[key]===o?' selected':'')+'>'+esc(o)+'</option>';}).join('')+'</select></div>';}
  var html=head('Informes','Análisis de sesiones firmadas, calibración de instructores y exportación.','<button class="btn" data-act="csv">'+I.down+'CSV</button><button class="btn" data-act="pdfReport">'+I.down+'Informe PDF</button>'+(isCoord()?'<button class="btn" data-act="exportManager">'+I.up+'Para EBT Manager</button>':''));
  html+='<div class="seg" style="margin-bottom:14px"><button class="'+(S.ui.rtab!=='cal'?'on':'')+'" data-act="rtab" data-v="">Resumen</button><button class="'+(S.ui.rtab==='cal'?'on':'')+'" data-act="rtab" data-v="cal">Calibración de instructores</button></div>';
  html+='<div class="card" style="margin-bottom:16px"><div class="row" style="align-items:flex-end">'+sel('rf-m','module',Object.keys(mods).sort(),'Módulo')+sel('rf-f','fleet',S.settings.fleets,'Flota')+sel('rf-p','phase',S.settings.phases,'Fase')+'</div></div>';
  if(!ss.length)return html+'<div class="card">'+empty('chart','Sin sesiones con estos filtros','Cambia los filtros o cierra y firma evaluaciones para ver su análisis.')+'</div>';
  if(S.ui.rtab==='cal')return html+vCalibracion(ss);
  var nP={},rt=0,tot=0;ss.forEach(function(s){seats(s).forEach(function(x){nP[s.pilots[x]]=1;tot++;if(s.result[x]==='RT')rt++;});});
  var av=compAverages(ss),overall=avg(CK.map(function(k){return av[k];}));
  var weakest=CK.slice().filter(function(k){return av[k];}).sort(function(a,b){return av[a]-av[b];})[0];
  html+='<div class="grid g4" style="margin-bottom:16px">'+kpi('Sesiones',ss.length,'firmadas')+kpi('Trainees',Object.keys(nP).length,tot+' evaluaciones individuales')+kpi('Promedio global',f1(overall),'escala 1–5')+kpi('Competencia más baja',weakest||'—',weakest?CMAP[weakest].es+' · '+f1(av[weakest]):'')+'</div>';
  html+='<div class="grid g2" style="margin-bottom:16px"><div class="card"><div class="card-head"><h3>Promedio por competencia</h3></div>'+hbars(av)+'</div><div class="card"><div class="card-head"><h3>Distribución de grados</h3></div>'+dist(ss)+'</div></div>';
  html+='<div class="grid g2" style="margin-bottom:16px">'+riskCard(ss)+'<div class="card"><div class="card-head"><div><h3>TEM · Nivel 3</h3><p class="small muted">Amenazas, errores y estados indeseados por categoría</p></div></div>'+temChart(temStats(ss))+'</div></div>';
  html+='<div class="card" style="margin-bottom:16px"><div class="card-head"><div><h3>Resultado por trainee</h3><p class="small muted">'+(tot-rt)+' competentes · '+rt+' requieren entrenamiento adicional</p></div></div><div class="scroll-x"><table class="tbl"><thead><tr><th>Fecha</th><th>Fase</th><th>Piloto</th><th>Asiento</th><th>Prom.</th><th>Resultado</th></tr></thead><tbody>'+
   ss.map(function(s){return seats(s).map(function(x){var r=RES[s.result[x]||''];return '<tr class="click" data-act="openSession" data-id="'+s.id+'"><td class="num">'+fdate(s.date)+'</td><td>'+esc(s.phase)+'</td><td>'+esc(pname(s.pilots[x]))+'</td><td>'+x.toUpperCase()+'</td><td><span class="gchip '+gcls(sessAvg(s,x))+'" style="width:34px">'+f1(sessAvg(s,x))+'</span></td><td><span class="pill '+r[1]+'">'+r[0]+'</span></td></tr>';}).join('');}).join('')+'</tbody></table></div></div>';
  return html;
}

function vMas(){
  var html=head('Más','');
  return html+'<div class="list">'+[['asistente','Asistente IA','spark','Analiza historiales y redacta debriefings'],['biblioteca','Biblioteca EVAL','book','Plantillas de evaluación por módulo'],['informes','Informes','chart','Análisis, CSV y PDF'],['instructores','Instructores','people','Equipo habilitado y patrón de calificación'],['ebtm','Diseño EBT Manager','cloud','Convierte el diseño de módulos en plantillas'],['ajustes','Ajustes','gear','Instructor, módulos, sincronización y respaldo']].filter(function(n){return isCoord()||(n[0]!=='informes'&&n[0]!=='instructores'&&n[0]!=='ebtm');}).map(function(n){return '<button class="li" data-act="go" data-r="'+n[0]+'"><span class="avatar" style="color:var(--accent)">'+I[n[2]].replace('<svg','<svg width="20" height="20"')+'</span><div class="grow"><div class="t">'+n[1]+'</div><div class="small muted">'+n[3]+'</div></div>'+I.chev+'</button>';}).join('')+'</div><div style="margin-top:16px" data-sync>'+syncHTML()+'</div>';
}

function vAjustes(){
  var st=S.settings;
  function inp(id,key,lbl,ph){return '<div class="field"><label for="'+id+'">'+lbl+'</label><input class="input" id="'+id+'" data-bind="settings.'+key+'" value="'+esc(st[key]||'')+'" placeholder="'+esc(ph||'')+'"></div>';}
  var html=head('Ajustes','Preferencias de este dispositivo y gestión de datos.','<span class="pill '+(isCoord()?'acc':'')+'">'+roleLabel()+'</span>'+(realCoord()?'<div class="seg"><button class="'+(!S.ui.viewAs?'on':'')+'" data-act="viewAs" data-v="">Vista Manager</button><button class="'+(S.ui.viewAs==='instructor'?'on':'')+'" data-act="viewAs" data-v="instructor">Ver como Instructor</button></div>':''));
  html+='<div class="grid g2"><div class="card stack"><h3>Instructor</h3><div class="profile">'+(st.photo?'<img class="ph" src="'+st.photo+'" alt="Foto">':'<span class="avatar ph">'+initials(st.instructor||'?')+'</span>')+'<div class="row"><button class="btn sm" data-act="photo">'+I.cam+'Foto</button>'+(st.photo?'<button class="btn ghost sm" data-act="photoClear">Quitar</button>':'')+'</div></div>'+inp('s-in','instructor','Nombre que aparece en informes y firmas')+inp('s-id','instructorId','Código de instructor','Ej. IE-01')+'<div class="grid g2" style="gap:12px"><div class="field"><label for="s-rk">Cargo</label><select class="input" id="s-rk" data-bind="settings.rank"><option value="">—</option><option value="CPT"'+(st.rank==='CPT'?' selected':'')+'>Capitán</option><option value="FO"'+(st.rank==='FO'?' selected':'')+'>Primer oficial</option></select></div><div class="field"><label for="s-fle">Flota</label><select class="input" id="s-fle" data-bind="settings.fleet"><option value="">—</option>'+st.fleets.map(function(f){return '<option'+(st.fleet===f?' selected':'')+'>'+esc(f)+'</option>';}).join('')+'</select></div></div>'+inp('s-q','quals','Habilitaciones (separadas por coma)','TRI, SFI, SFE, LTC')+inp('s-lic','license','Licencia','Ej. ATPL COL-12345')+inp('s-op','operator','Operador / departamento','Ej. Entrenamiento de vuelo')+'</div>'+accountCard()+formatCard()+
   (isCoord()?'<div class="card stack"><h3>Ciclo EBT</h3><div class="field"><label for="s-mod">Módulo en curso</label><select class="input" id="s-mod" data-bind="settings.module" data-rerender="1">'+st.modules.map(function(m){return '<option'+(st.module===m?' selected':'')+'>'+esc(m)+'</option>';}).join('')+'</select></div>'+
   '<div class="field"><label for="s-mods">Módulos (separados por coma)</label><input class="input" id="s-mods" data-list="modules" value="'+esc(st.modules.join(', '))+'"></div>'+
   '<div class="field"><label for="s-ph">Fases de evaluación (separadas por coma)</label><input class="input" id="s-ph" data-list="phases" value="'+esc(st.phases.join(', '))+'"></div>'+
   '<div class="field"><label for="s-sims">Simuladores (separados por coma)</label><input class="input" id="s-sims" data-list="sims" value="'+esc((st.sims||[]).join(', '))+'"></div>'+
   '<div class="field"><label for="s-fph">Fases de vuelo para plantillas (separadas por coma)</label><input class="input" id="s-fph" data-list="flightPhases" value="'+esc((st.flightPhases||[]).join(', '))+'"></div>'+
   '<div class="field"><label for="s-fl">Flotas</label><input class="input" id="s-fl" data-list="fleets" value="'+esc(st.fleets.join(', '))+'"></div></div>':'')+
   '<div class="card stack"><h3>Frases predefinidas</h3><p class="small muted">Una por línea. Aparecen como botones al calificar y al redactar el debriefing.</p><div class="field"><label for="s-phr">Evidencia por competencia</label><textarea class="input" id="s-phr" data-lines="phrases" style="min-height:120px">'+esc((st.phrases||[]).join('\n'))+'</textarea></div><div class="field"><label for="s-dph">Debriefing</label><textarea class="input" id="s-dph" data-lines="debPhrases" style="min-height:120px">'+esc((st.debPhrases||[]).join('\n'))+'</textarea></div></div>'+
   '<div class="card stack"><h3>Sincronización</h3><div data-sync>'+syncHTML()+'</div><p class="small muted">Los datos se guardan primero en este dispositivo. Con conexión, se suben y descargan de la base de datos compartida de la app. Sin conexión puedes seguir evaluando; los cambios quedan en cola.</p><div class="row"><button class="btn" data-act="syncNow">'+I.cloud+'Sincronizar ahora</button></div></div>'+
   (isCoord()?'<div class="card stack"><h3>Respaldo e integración</h3><p class="small muted">Todo queda guardado en la base de datos. Descarga además una copia en JSON una vez al mes y guárdala fuera de la app.</p><div class="row"><button class="btn" data-act="backup">'+I.down+'Exportar respaldo</button></div><hr class="sep" style="margin:4px 0"><div class="row"><button class="btn" data-act="go" data-r="ebtm">'+I.cloud+'Diseño EBT Manager</button><button class="btn" data-act="go" data-r="instructores">'+I.people+'Equipo de instructores</button></div></div>':'')+'</div>';
  html+='<p class="small muted" style="margin-top:18px;max-width:720px">Rol: '+(isCoord()?'Manager EBT (acceso de edición sobre la app): ves todo, editas cronograma y plantillas, revisas informes y calibración, borras registros.':'Instructor: tu agenda, tus evaluaciones y el historial de los trainees. Informes, calibración, cronograma y plantillas los gestiona el Manager EBT.')+'</p>';
  html+='<p class="small muted" style="margin-top:10px;max-width:720px">Marco de competencias y textos de OB según EASA AMC1 ORO.FC.231 y OACI Doc 9995 (numeración 0–8). Verifica los textos y la escala de calificación contra el EBT Instructor Handbook vigente antes de usar la app en sesiones reales.</p>';
  return html;
}
