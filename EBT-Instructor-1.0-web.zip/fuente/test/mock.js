// Servidor Supabase simulado para pruebas (auth, PostgREST básico, RPC y función de invitaciones), con reglas de acceso equivalentes.
const BASE='https://xjrgbjshizimsfcfhoxp.supabase.co';
function nowIso(){return new Date().toISOString();}
function mkDB(){
  const users={
    'u-mgr':{id:'u-mgr',email:'manager@test.com',password:'Manager123',confirmed:true},
    'u-ext':{id:'u-ext',email:'otro@test.com',password:'Otro12345',confirmed:true},
  };
  const db={
    ei_members:[{user_id:'u-mgr',role:'manager',status:'active',full_name:'Cap. Oscar Prueba',email:'manager@test.com',ie_code:'MGR',rank:'CPT',fleet:'A320',created_at:nowIso(),updated_at:nowIso()}],
    ei_invites:[],ei_settings:[{id:'main',config:{scale:{1:{label:'Unsafe situation',short:'Unsafe',color:'#D23B32'},2:{label:'Not an unsafe situation',short:'Not unsafe',color:'#E5A11F'},3:{label:'Safe situation',short:'Safe',color:'#7CC68E'},4:{label:'Safe situation',short:'Safe',color:'#3DA661'},5:{label:'Enhanced safety, effectiveness and efficiency',short:'Enhanced',color:'#16794A'}},allowNO:true,requireNoteForNO:true,requireNoteAtOrBelow:2,temEnabled:true,phases:['EVAL','MT','SBT','LOFT','LOE','LINE'],fleets:['A320','B787'],modules:['M1 2S-2026','M2 1S-2027'],currentModule:'M1 2S-2026',phrases:['Adecuado manejo.'],debriefPhrases:['Resultado competente.']},updated_at:nowIso()}],
    ei_formats:[],ei_trainees:[],ei_sessions:[],ei_schedule:[],ei_notices:[],
  };
  const design={revision:61,updated_at:'2026-10-07T04:17:38Z',data:{A320:{'1':{crm:{map:[{c:['APK','PSD','COM'],s:'EVAL 1',t:'Ascenso con convectivo y TCAS TA durante la desviación.',ex:['J21'],fcts:[]},{c:['APK','WLM','LTW'],s:'TRANSIT',t:'Tránsito de 40 minutos en SKBO con MEL A/THR.',ex:['J131'],fcts:[]}]},compliance:{map:[{c:['APK','SAW'],s:'EVAL 1',t:'Ascenso con convectivo y TCAS TA durante la desviación.',ex:[],fcts:[]}]}},'2':{}},B787:{'1':{}},_sessionBoard:{}},target:{A320:{APK:[1],SAW:[1,2],FPM:[1,2],COM:[2]}},company:{},userEls:{}};
  return {users,db,design,tokens:{},log:[]};
}
function parseQ(url){const u=new URL(url);const q={};u.searchParams.forEach((v,k)=>{q[k]=v;});return {path:u.pathname,q};}
function filt(rows,q){return rows.filter(r=>Object.keys(q).every(k=>{if(['select','order','limit','on_conflict','grant_type','redirect_to'].includes(k))return true;const v=q[k];if(v.startsWith('eq.'))return String(r[k])===v.slice(3);if(v==='is.null')return r[k]==null;return true;}));}
async function install(page,M,opts){
  opts=opts||{};
  await page.route('https://cdnjs.cloudflare.com/**',r=>r.abort());
  await page.route(BASE+'/**',async route=>{
    const req=route.request();const {path,q}=parseQ(req.url());const method=req.method();
    if(M.offline)return route.abort('internetdisconnected');
    let body=null;try{body=req.postDataJSON();}catch(e){}
    const auth=(req.headers()['authorization']||'').replace(/^Bearer\s+/,'');
    const uid=M.tokens[auth]||null;
    const send=(status,obj)=>route.fulfill({status,contentType:'application/json',body:obj==null?'':JSON.stringify(obj)});
    M.log.push(method+' '+path+(Object.keys(q).length?'?'+new URL(req.url()).search.slice(1):''));
    if(path==='/auth/v1/token'){
      if(q.grant_type==='password'){const u=Object.values(M.users).find(x=>x.email===body.email&&x.password===body.password);if(!u)return send(400,{error_code:'invalid_credentials',msg:'Invalid login credentials'});const t='tok-'+u.id+'-'+Date.now();M.tokens[t]=u.id;return send(200,{access_token:t,refresh_token:'r-'+t,expires_in:3600,user:{id:u.id,email:u.email}});}
      if(q.grant_type==='refresh_token'){const t0=body.refresh_token.slice(2);const id=M.tokens[t0];if(!id)return send(400,{error_code:'refresh_token_not_found'});const t='tok-'+id+'-'+Date.now();M.tokens[t]=id;return send(200,{access_token:t,refresh_token:'r-'+t,expires_in:3600,user:{id,email:M.users[id].email}});}
    }
    if(path==='/auth/v1/user'){if(!uid)return send(401,{msg:'invalid JWT'});const u=M.users[uid];if(method==='PUT'){if((body.password||'').length<8)return send(422,{error_code:'weak_password',msg:'Password should be at least 8 characters'});u.password=body.password;}return send(200,{id:u.id,email:u.email});}
    if(path==='/auth/v1/recover'){M.recovered=body.email;M.recoverRedirect=q.redirect_to;return send(200,{});}
    if(path==='/auth/v1/logout'){return send(204,null);}
    const isMember=()=>M.db.ei_members.some(m=>m.user_id===uid&&m.status==='active');
    const isMgr=()=>M.db.ei_members.some(m=>m.user_id===uid&&m.status==='active'&&m.role==='manager');
    if(path==='/rest/v1/rpc/ei_manager_design'){if(!isMgr())return send(403,{code:'42501',message:'Solo el Manager'});return send(200,M.design);}
    if(path==='/functions/v1/ei-invite'){
      if(!uid)return send(401,{error:'not_authenticated'});if(!isMgr())return send(403,{error:'forbidden'});
      const email=String(body.email||'').toLowerCase();if(!/@/.test(email))return send(400,{error:'invalid_email'});
      if(body.action==='cancel'){M.db.ei_invites=M.db.ei_invites.filter(i=>!(i.email===email&&!i.accepted_at));return send(200,{status:'cancelled'});}
      M.db.ei_invites=M.db.ei_invites.filter(i=>!(i.email===email&&!i.accepted_at));
      M.db.ei_invites.push({id:'inv-'+Date.now(),email,full_name:body.full_name||'',role:body.role||'instructor',ie_code:body.ie_code||null,rank:body.rank||null,fleet:body.fleet||null,created_at:nowIso(),accepted_at:null});
      M.lastInvite=body;return send(200,{status:'invited'});
    }
    const m=path.match(/^\/rest\/v1\/(ei_\w+)$/);
    if(m){
      const t=m[1];if(!uid)return send(401,{message:'JWT required'});
      let rows=M.db[t];
      const canRead=t==='ei_members'?true:t==='ei_invites'?isMgr():isMember();
      if(method==='GET'){if(!canRead)return send(200,[]);let out=filt(rows,q);if(t==='ei_members'&&!isMember())out=out.filter(r=>r.user_id===uid);return send(200,out);}
      const key=t==='ei_members'?'user_id':'id';
      const writeOK=(row,old)=>{
        if(t==='ei_settings'||t==='ei_formats'||t==='ei_invites')return isMgr();
        if(t==='ei_trainees')return isMember();
        if(t==='ei_sessions'){if(!isMember())return false;if(isMgr())return true;if((old&&old.instructor_id!==uid)||(row.instructor_id&&row.instructor_id!==uid))return false;if(old&&old.status!=='draft')return 'signed';return true;}
        if(t==='ei_schedule')return isMgr()||(old&&old.instructor_id===uid);
        if(t==='ei_notices')return isMember()&&(isMgr()||!old||old.created_by===uid);
        if(t==='ei_members')return isMgr()||(row.user_id===uid&&(!old||(old.role===row.role||row.role==null)&&(old.status===row.status||row.status==null)));
        return false;};
      if(method==='POST'){
        for(const r of body){const old=rows.find(x=>x[key]===r[key]);const ok=writeOK(r,old);if(ok!==true)return send(403,{code:'42501',message:ok==='signed'?'La evaluación ya está firmada':'new row violates row-level security policy'});
          if(t==='ei_trainees'&&r.emp_no&&rows.some(x=>x.emp_no===r.emp_no&&x.id!==r.id))return send(409,{code:'23505',message:'duplicate key value violates unique constraint "ei_trainees_emp_no"'});
          const n=Object.assign({},old||{created_at:nowIso(),created_by:uid},r,{updated_at:nowIso()});if(old)Object.assign(old,n);else rows.push(n);}
        return send(201,null);
      }
      if(method==='PATCH'){const tgt=filt(rows,q);for(const old of tgt){const row=Object.assign({},old,body);const ok=writeOK(row,old);if(ok!==true)return send(403,{code:'42501',message:'denied'});Object.assign(old,body,{updated_at:nowIso()});}return send(204,null);}
      if(method==='DELETE'){const tgt=filt(rows,q);for(const old of tgt){const ok=t==='ei_sessions'?(isMgr()||(old.instructor_id===uid&&old.status==='draft')):writeOK(old,old);if(ok!==true)return send(403,{code:'42501',message:'denied'});}M.db[t]=rows.filter(r=>!tgt.includes(r));return send(204,null);}
    }
    return send(404,{message:'not mocked '+path});
  });
}
// Simula la aceptación de una invitación: crea el usuario y su membresía (lo que hace el disparador real al confirmar el correo).
function acceptInvite(M,email){const inv=M.db.ei_invites.find(i=>i.email===email&&!i.accepted_at);const id='u-'+email.split('@')[0];M.users[id]={id,email,password:'',confirmed:true};M.db.ei_members.push({user_id:id,role:inv.role,status:'active',full_name:inv.full_name,email,ie_code:inv.ie_code,rank:inv.rank,fleet:inv.fleet,created_at:nowIso(),updated_at:nowIso()});inv.accepted_at=nowIso();const t='tok-'+id+'-invite';M.tokens[t]=id;return t;}
module.exports={mkDB,install,acceptInvite,BASE};
