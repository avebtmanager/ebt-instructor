const {chromium}=require('playwright');const {mkDB,install,acceptInvite}=require('./mock.js');
const APP='http://localhost:8765/';
const results=[];function check(name,ok,info){results.push((ok?'PASS ':'FAIL ')+name+(info?' — '+info:''));}
async function newPage(b,M,vp){const ctx=await b.newContext({viewport:vp||{width:1180,height:860},serviceWorkers:'block'});const p=await ctx.newPage();p.on('pageerror',e=>results.push('PAGEERROR '+e.message));await install(p,M);return {ctx,p};}
const wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
  const b=await chromium.launch();const M=mkDB();
  try{
  // ---------- 1. Manager: inicio de sesión
  let {ctx,p}=await newPage(b,M);
  await p.goto(APP);await wait(500);
  check('pantalla de entrada visible',await p.locator('#lock [data-act="login"]').count()===1);
  await p.fill('#au-e','manager@test.com');await p.fill('#au-p','mala');await p.click('[data-act="login"]');await wait(400);
  check('contraseña incorrecta muestra error',/incorrectos/.test(await p.locator('#lock .note').innerText()));
  await p.fill('#au-p','Manager123');await p.click('[data-act="login"]');await wait(900);
  check('manager entra',await p.locator('#lock').count()===0);
  check('rol manager con menú Instructores',await p.locator('.nav[data-r="instructores"]').count()===1);
  check('asistente IA oculto fuera de Claude',!(await p.locator('.nav[data-r="asistente"]').isVisible()));
  await p.screenshot({path:'test/s1-inicio.png'});
  // ---------- 2. Formato de evaluación
  await p.click('.nav[data-r="ajustes"]');await wait(300);
  check('tarjeta Formato de evaluación',await p.locator('text=Formato de evaluación').count()>0);
  const lbl=p.locator('[data-org="scale.1.label"]');await lbl.fill('Inseguro');await lbl.dispatchEvent('change');await wait(1400);
  check('escala guardada en ei_settings',M.db.ei_settings[0].config.scale['1'].label==='Inseguro',JSON.stringify(M.db.ei_settings[0].config.scale['1']));
  await p.screenshot({path:'test/s2-ajustes.png',fullPage:true});
  // ---------- 3. Diseño EBT Manager → plantillas
  await p.click('.nav[data-r="ebtm"]');await wait(700);
  check('diseño leído (2 sesiones)',await p.locator('details.disc').count()===2);
  await p.click('[data-act="emTplAll"]');await wait(1400);
  check('plantillas creadas en ei_formats',M.db.ei_formats.length===2,String(M.db.ei_formats.length));
  check('plantilla con competencias objetivo',(M.db.ei_formats[0]||{}).target_comps&&M.db.ei_formats[0].target_comps.join(',')==='APK,SAW,FPM',JSON.stringify((M.db.ei_formats[0]||{}).target_comps));
  check('EVAL 1 unió escenarios repetidos',(M.db.ei_formats.find(f=>f.session_label==='EVAL 1')||{events:[]}).events.length===1);
  await p.screenshot({path:'test/s3-diseno.png',fullPage:true});
  // ---------- 4. Invitar instructor
  await p.click('.nav[data-r="instructores"]');await wait(300);
  await p.click('[data-act="newIE"]');await wait(200);
  await p.fill('#ie-n','Cap. Ana Instructora');await p.fill('#ie-em','ana@test.com');await p.fill('#ie-id','IE-07');
  await p.click('[data-act="saveIE"]');await wait(1200);
  check('invitación enviada a la función',M.lastInvite&&M.lastInvite.email==='ana@test.com'&&/localhost:8765/.test(M.lastInvite.redirectTo),JSON.stringify(M.lastInvite));
  check('invitación pendiente visible',await p.locator('text=Pendiente').count()>0);
  await p.screenshot({path:'test/s4-equipo.png',fullPage:true});
  await ctx.close();
  // ---------- 5. Instructor abre el enlace de invitación
  const tok=acceptInvite(M,'ana@test.com');
  ({ctx,p}=await newPage(b,M,{width:1024,height:768}));
  await p.goto(APP+'#access_token='+tok+'&refresh_token=r-'+tok+'&expires_in=3600&token_type=bearer&type=invite');await wait(700);
  check('pantalla crear contraseña',await p.locator('[data-act="setPw"]').count()===1);
  check('el enlace se borra de la barra',!(await p.evaluate(()=>location.hash)));
  await p.fill('#au-p','corta');await p.fill('#au-p2','corta');await p.click('[data-act="setPw"]');await wait(300);
  check('exige 8 caracteres',/8 caracteres/.test(await p.locator('#lock .note').innerText()));
  await p.fill('#au-p','Clave2026x');await p.fill('#au-p2','Clave2026x');await p.click('[data-act="setPw"]');await wait(1200);
  check('instructora entra',await p.locator('#lock').count()===0);
  check('contraseña guardada',M.users['u-ana'].password==='Clave2026x');
  check('instructor no ve Instructores ni Informes',await p.locator('.nav[data-r="instructores"]').count()===0&&await p.locator('.nav[data-r="informes"]').count()===0);
  check('nombre del perfil desde la invitación',/Ana/.test(await p.locator('.topbar .who').innerText()));
  // ---------- 6. Trainee + evaluación con plantilla
  await p.evaluate(()=>{ACT.newPilot();});await wait(200);
  await p.evaluate(()=>{S.ui.form.name='Laura Piloto';S.ui.form.emp='20871';S.ui.form.fleet='A320';S.ui.form.rank='FO';ACT.savePilot();});await wait(1300);
  check('trainee guardado en ei_trainees',M.db.ei_trainees.length===1&&M.db.ei_trainees[0].full_name==='Laura Piloto');
  const fmt=M.db.ei_formats.find(f=>f.session_label==='EVAL 1');
  await p.evaluate((fid)=>{ACT.newEval({dataset:{}});Object.assign(S.ui.setup,{mode:'single',cm1:Object.keys(S.trainees)[0],fleet:'A320',phase:'EVAL',templateId:fid});ACT.startEval();},fmt.id);await wait(500);
  check('competencias objetivo resaltadas',await p.locator('.pill:has-text("Objetivo")').count()===3);
  check('tarjeta TEM visible',await p.locator('text=TEM · Nivel 3').count()>0);
  await p.screenshot({path:'test/s6-calificar.png'});
  await p.evaluate(()=>{const s=cur();CK.forEach(k=>{s.grades.cm1[k]={g:k==='SAW'?2:4,no:false,ob:{},note:''};});s.result={cm1:'C'};s.sig={inst:'data:image/png;base64,AAAA',cm1:''};put('sessions',s,true);});await wait(300);
  await p.evaluate(()=>ACT.finalize());await wait(300);
  check('exige evidencia en grado 2',/evidencia/.test(await p.locator('.toast').last().innerText()));
  await p.evaluate(()=>{const s=cur();s.grades.cm1.SAW.note='Monitoreo tardío del FMA.';put('sessions',s,true);ACT.finalize();});await wait(1500);
  const srow=M.db.ei_sessions[0]||{};
  check('evaluación firmada en ei_sessions',srow.status==='signed'&&srow.instructor_id==='u-ana'&&srow.format_id===fmt.id,JSON.stringify({st:srow.status,iid:srow.instructor_id}));
  check('datos de calificación guardados',srow.data&&srow.data.grades&&srow.data.grades.cm1.SAW.g===2);
  // intento de modificar una evaluación firmada
  await p.evaluate((id)=>{const s=S.sessions[id];s.debrief='cambio';put('sessions',s,true);},srow.id);await wait(1600);
  check('firmada no se puede modificar',!(M.db.ei_sessions[0].data.debrief==='cambio'));
  // ---------- 7. Sin conexión
  M.offline=true;await p.context().setOffline(true);await wait(200);
  await p.evaluate(()=>{ACT.newPilot();S.ui.form.name='Pedro Offline';S.ui.form.fleet='A320';ACT.savePilot();});await wait(900);
  check('sin conexión queda pendiente',/Sin conexión|pendiente/.test(await p.locator('[data-sync-pill]').innerText()),await p.locator('[data-sync-pill]').innerText());
  await p.screenshot({path:'test/s7-offline.png'});
  M.offline=false;await p.context().setOffline(false);await p.evaluate(()=>window.dispatchEvent(new Event('online')));await wait(1800);
  check('al reconectar se sube',M.db.ei_trainees.some(t=>t.full_name==='Pedro Offline'));
  check('estado sincronizado',/Sincronizado/.test(await p.locator('[data-sync-pill]').innerText()),await p.locator('[data-sync-pill]').innerText());
  // recarga sin internet: abre con datos guardados
  M.offline=true;await p.reload().catch(()=>{});await wait(1200);
  const lockedOffline=await p.locator('#lock').count();
  check('abre sin internet con sesión guardada',lockedOffline===0);
  M.offline=false;
  // cerrar sesión
  await p.evaluate(()=>ACT.logout());await wait(500);
  check('cerrar sesión vuelve a la entrada',await p.locator('#lock [data-act="login"]').count()===1);
  // olvidé mi contraseña
  await p.click('[data-m="forgot"]');await p.fill('#au-e','ana@test.com');await p.click('[data-act="forgot"]');await wait(500);
  check('recuperación solicitada',M.recovered==='ana@test.com'&&/localhost:8765/.test(M.recoverRedirect||''));
  await ctx.close();
  // ---------- 8. Cuenta sin acceso
  ({ctx,p}=await newPage(b,M));await p.goto(APP);await wait(400);
  await p.fill('#au-e','otro@test.com');await p.fill('#au-p','Otro12345');await p.click('[data-act="login"]');await wait(900);
  check('cuenta sin invitación no entra',/no tiene acceso/.test(await p.locator('#lock').innerText()));
  await p.screenshot({path:'test/s8-noaccess.png'});
  await ctx.close();
  // ---------- 9. Manager desactiva instructora
  ({ctx,p}=await newPage(b,M));await p.goto(APP);await wait(300);await p.fill('#au-e','manager@test.com');await p.fill('#au-p','Manager123');await p.click('[data-act="login"]');await wait(900);
  await p.click('.nav[data-r="instructores"]');await wait(300);
  check('manager ve evaluación de la instructora (calibración)',await p.locator('text=Ana').count()>0);
  await p.evaluate(()=>ACT.editMember({dataset:{id:'u-ana'}}));await wait(200);await p.click('[data-act="memberStatus"]');await wait(900);
  check('instructora desactivada',M.db.ei_members.find(m=>m.user_id==='u-ana').status==='inactive');
  await ctx.close();
  }catch(e){results.push('ERROR '+e.message.split('\n')[0]);}
  await b.close();
  console.log(results.join('\n'));console.log('\nLLAMADAS:',M.log.length);
})();
