/* ============ Calibración de instructores ============ */
function hhmm(ms){var d=new Date(ms);return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');}
function simClock(s){if(!s.startedAt)return '';var m=Math.max(0,Math.round((Date.now()-s.startedAt)/60000));return hhmm(s.startedAt)+' · '+Math.floor(m/60)+'h '+String(m%60).padStart(2,'0')+'m';}
setInterval(function(){var el=document.getElementById('simclock'),s=typeof cur==='function'&&cur();if(el&&s&&s.startedAt){el.lastChild.nodeValue=simClock(s);}},30000);
function stats(arr){var n=arr.length;if(!n)return {n:0,mean:0,sd:0,p45:0,p12:0};var m=arr.reduce(function(a,b){return a+b;},0)/n;var v=arr.reduce(function(a,b){return a+(b-m)*(b-m);},0)/n;return {n:n,mean:m,sd:Math.sqrt(v),p45:arr.filter(function(x){return x>=4;}).length/n,p12:arr.filter(function(x){return x<=2;}).length/n};}
function calib(ss){
  var by={},all=[];
  ss.forEach(function(s){var ie=s.instructor||'Sin instructor';var o=by[ie]||(by[ie]={ie:ie,g:[],sessions:0,comp:{}});o.sessions++;
    seats(s).forEach(function(x){var g=s.grades[x]||{};CK.forEach(function(k){if(g[k]&&g[k].g){o.g.push(g[k].g);all.push(g[k].g);(o.comp[k]=o.comp[k]||[]).push(g[k].g);}});});});
  var G=stats(all);
  var rows=Object.keys(by).map(function(ie){var o=by[ie],st=stats(o.g);var d=st.mean-G.mean;var flags=[];
    if(st.n<18)flags.push(['Pocas sesiones','']);
    if(d>0.5)flags.push(['Tendencia leniente','warn']);if(d<-0.5)flags.push(['Tendencia severa','warn']);
    if(st.n>=18&&st.sd<0.45)flags.push(['Poca dispersión','warn']);
    if(st.n>=18&&st.p12===0&&G.p12>0.08)flags.push(['Nunca califica 1–2','']);
    var dist=[0,0,0,0,0,0];o.g.forEach(function(v){dist[v]++;});
    return {ie:ie,sessions:o.sessions,st:st,d:d,flags:flags,dist:dist,comp:o.comp};}).sort(function(a,b){return b.st.n-a.st.n;});
  return {G:G,rows:rows,groupComp:compAverages(ss)};
}
function vCalibracion(ss){
  var c=calib(ss),G=c.G;
  var html='<div class="grid g4" style="margin-bottom:16px">'+kpi('Instructores',c.rows.length,'con sesiones firmadas en el filtro')+kpi('Promedio del grupo',f1(G.mean),'desv. '+f1(G.sd))+kpi('% grados 4–5',Math.round(G.p45*100)+'%','del total de calificaciones')+kpi('% grados 1–2',Math.round(G.p12*100)+'%',G.n+' calificaciones',G.p12>0.2?'var(--warn)':'')+'</div>';
  html+='<div class="card" style="margin-bottom:16px"><div class="card-head"><div><h3>Concordancia entre instructores</h3><p class="small muted">Desviación del promedio de cada instructor frente al grupo. Se marcan tendencias leniente o severa (±0,5) y poca dispersión (todos los grados iguales).</p></div></div><div class="scroll-x"><table class="tbl"><thead><tr><th>Instructor</th><th>Sesiones</th><th>Calif.</th><th>Promedio</th><th>vs. grupo</th><th>Distribución</th><th>% 4–5</th><th>% 1–2</th><th>Señales</th></tr></thead><tbody>'+
   c.rows.map(function(r){var dc=Math.abs(r.d)>0.5?'var(--warn)':'var(--muted)';var tot=r.st.n||1;
     return '<tr><td style="font-weight:600;white-space:nowrap">'+esc(r.ie)+'</td><td class="num">'+r.sessions+'</td><td class="num">'+r.st.n+'</td><td><span class="gchip '+gcls(r.st.mean)+'" style="width:36px">'+f1(r.st.mean)+'</span></td><td class="num" style="color:'+dc+';font-weight:600">'+(r.d>=0?'+':'')+f1(Math.abs(r.d)<0.05?0:r.d).replace('—','0,0')+'</td>'+
     '<td style="min-width:140px"><div style="display:flex;height:12px;border-radius:4px;overflow:hidden;gap:1px;background:var(--line)">'+[1,2,3,4,5].map(function(g){return r.dist[g]?'<div title="'+g+': '+r.dist[g]+'" style="width:'+(r.dist[g]/tot*100)+'%;background:var(--g'+g+')"></div>':'';}).join('')+'</div></td>'+
     '<td class="num">'+Math.round(r.st.p45*100)+'%</td><td class="num">'+Math.round(r.st.p12*100)+'%</td><td>'+(r.flags.length?r.flags.map(function(f){return '<span class="pill '+f[1]+'" style="margin:1px 2px 1px 0">'+f[0]+'</span>';}).join(''):'<span class="pill ok">En rango</span>')+'</td></tr>';}).join('')+'</tbody></table></div>'+
   '<div class="legend" style="margin-top:12px">'+[1,2,3,4,5].map(function(g){return '<span><i style="background:var(--g'+g+')"></i>'+g+'</span>';}).join('')+'</div></div>';
  html+='<div class="card"><div class="card-head"><div><h3>Promedio por competencia e instructor</h3><p class="small muted">Celdas con color según el grado; resalta dónde un instructor se separa del grupo en una competencia</p></div></div><div class="scroll-x"><table class="heat"><thead><tr><th class="r">Instructor</th>'+CK.map(function(k){return '<th>'+k+'</th>';}).join('')+'</tr></thead><tbody><tr><th class="r" style="font-family:var(--font)">Grupo</th>'+CK.map(function(k){var v=c.groupComp[k];return '<td style="background:'+gvar(v)+'">'+f1(v)+'</td>';}).join('')+'</tr>'+
   c.rows.map(function(r){return '<tr><th class="r" style="font-family:var(--font);white-space:nowrap">'+esc(r.ie.split(' · ')[0])+'</th>'+CK.map(function(k){var v=r.comp[k]?avg(r.comp[k]):0;var off=v&&Math.abs(v-c.groupComp[k])>0.6;return '<td style="background:'+gvar(v)+';'+(off?'outline:2px solid var(--fg);outline-offset:-2px':'')+'" title="'+(off?'Se separa del grupo':'')+'">'+(v?f1(v):'')+'</td>';}).join('')+'</tr>';}).join('')+'</tbody></table></div><p class="tiny muted" style="margin-top:8px">Recuadro: diferencia mayor a 0,6 frente al promedio del grupo en esa competencia. Útil para la reunión de estandarización de IE.</p></div>';
  return html;
}
/* ============ Exportación para EBT Manager ============ */
function exportManager(){
  var f=S.ui.rf||{};var ss=live('sessions').filter(function(s){return s.status==='signed'&&(!f.module||s.module===f.module)&&(!f.fleet||s.fleet===f.fleet)&&(!f.phase||s.phase===f.phase);});
  if(!ss.length)return toast('No hay sesiones firmadas con estos filtros');
  var comp={},te={},rt=[];
  CK.forEach(function(k){comp[k]={competency:k,name:CMAP[k].en,grades:[],lowOB:{}};});
  ss.forEach(function(s){seats(s).forEach(function(x){var g=s.grades[x]||{};var lowK=[];
    CK.forEach(function(k){var e=g[k]||{};if(e.g){comp[k].grades.push(e.g);if(e.g<=2)lowK.push(k);}var ob=e.ob||{};Object.keys(ob).forEach(function(o){if(ob[o]<0)comp[k].lowOB[o]=(comp[k].lowOB[o]||0)+1;});});
    if(s.result[x]==='RT')rt.push({pilot:pname(s.pilots[x]),fleet:s.fleet,phase:s.phase,date:s.date,competencies:lowK});
    (s.events||[]).forEach(function(ev){var o=te[ev.t]||(te[ev.t]={trainingElement:ev.t,competencies:ev.c||[],exposures:0,lowPerformance:0,fleets:{}});o.exposures++;o.fleets[s.fleet]=1;if((ev.c||[]).some(function(k){return lowK.indexOf(k)>=0;}))o.lowPerformance++;});});});
  var out={source:'EBT Instructor',generatedAt:new Date().toISOString(),filter:{module:f.module||'all',fleet:f.fleet||'all',phase:f.phase||'all'},sessions:ss.length,evaluations:ss.reduce(function(a,s){return a+seats(s).length;},0),
    competencies:CK.map(function(k){var c=comp[k],st=stats(c.grades);return {competency:k,name:c.name,n:st.n,avg:+st.mean.toFixed(2),pctLow:+(st.p12*100).toFixed(1),pctHigh:+(st.p45*100).toFixed(1),deficientOB:Object.keys(c.lowOB).sort(function(a,b){return c.lowOB[b]-c.lowOB[a];}).map(function(o){return {ob:o,count:c.lowOB[o]};})};}).sort(function(a,b){return a.avg-b.avg;}),
    trainingElements:Object.keys(te).map(function(k){var o=te[k];return {trainingElement:o.trainingElement,competencies:o.competencies,fleets:Object.keys(o.fleets),exposures:o.exposures,lowPerformance:o.lowPerformance,lowRate:+(o.lowPerformance/o.exposures*100).toFixed(1)};}).sort(function(a,b){return b.lowRate-a.lowRate;}),
    additionalTraining:rt,
    recommendation:'Priorizar en el próximo módulo las competencias con mayor pctLow y los training elements con mayor lowRate; mantener los elementos obligatorios (Engine Failure, AUPRTA).'};
  saveFile('ebt-manager-'+slug(f.module||'todos')+'-'+slug(f.fleet||'todas')+'.json',JSON.stringify(out,null,1));
}
/* ============ Bloqueo con PIN ============ */
var LOCKED=false,pinBuf='';
function lockHTML(){
  return '<div class="scrim" style="background:var(--bg);z-index:200;align-items:center" id="lock"><div style="width:min(320px,100%);text-align:center"><img class="brand-mark" src="'+LOGO_BIG+'" alt="" style="margin:0 auto 14px;width:96px;height:96px;object-fit:contain"><h2>EBT Instructor</h2><p class="small muted" style="margin:6px 0 18px">Ingresa tu PIN</p><div class="row" style="justify-content:center;gap:10px;margin-bottom:18px">'+[0,1,2,3,4,5].slice(0,Math.max(4,(S.settings.pin||'').length)).map(function(i){return '<span style="width:14px;height:14px;border-radius:50%;border:1.5px solid var(--line2);background:'+(i<pinBuf.length?'var(--fg)':'transparent')+'"></span>';}).join('')+'</div>'+
   '<div style="display:grid;grid-template-columns:repeat(3,72px);gap:12px;justify-content:center">'+['1','2','3','4','5','6','7','8','9','','0','⌫'].map(function(k){return k===''?'<span></span>':'<button class="btn" data-act="pinKey" data-k="'+k+'" style="height:72px;border-radius:50%;font-size:22px;font-weight:600">'+k+'</button>';}).join('')+'</div><p class="tiny muted" style="margin-top:18px" id="pinmsg"></p></div></div>';
}
function lockIfNeeded(){if(S.settings.pin&&!LOCKED){LOCKED=true;pinBuf='';render();}}
document.addEventListener('visibilitychange',function(){if(document.hidden)lockIfNeeded();});
var ROLE_ACT={
  rtab:function(el){S.ui.rtab=el.dataset.v;render();},
  exportManager:exportManager,
  simMode:function(el){S.ui.sim=!!el.dataset.v;render();},
  simStart:function(){var s=cur();s.startedAt=Date.now();put('sessions',s);},
  evStamp:function(el){var s=cur();var e=s.events[+el.dataset.i];e.at=e.at?0:Date.now();if(!s.startedAt&&e.at)s.startedAt=e.at;put('sessions',s);},
  pinKey:function(el){var k=el.dataset.k;if(k==='⌫')pinBuf=pinBuf.slice(0,-1);else if(pinBuf.length<6)pinBuf+=k;
    if(pinBuf.length>=(S.settings.pin||'').length){if(pinBuf===S.settings.pin){LOCKED=false;pinBuf='';render();return;}pinBuf='';render();var m=document.getElementById('pinmsg');if(m)m.textContent='PIN incorrecto';return;}render();}
};
/* ============ Instructores (Manager) ============ */
function ieStats(ie,ss){
  var mine=ss.filter(function(s){return (s.instructor||'Sin instructor')===ie;}).sort(sortByDate);
  var g=[],comp={},dist=[0,0,0,0,0,0],flat=0,evals=0,obN=0,notes=0,byS=[];
  mine.forEach(function(s){seats(s).forEach(function(x){var gg=s.grades[x]||{};var vals=[];evals++;
    CK.forEach(function(k){var e=gg[k]||{};if(e.g){g.push(e.g);vals.push(e.g);dist[e.g]++;(comp[k]=comp[k]||[]).push(e.g);}if(e.ob)obN+=Object.keys(e.ob).filter(function(o){return e.ob[o];}).length;if(e.note)notes++;});
    if(vals.length>=9&&vals.every(function(v){return v===vals[0];}))flat++;});
    byS.push({label:s.phase+' '+fdateShort(s.date),v:avg(seats(s).map(function(x){return sessAvg(s,x);}))});});
  var st=stats(g);var mode=0,mc=0;for(var i=1;i<=5;i++)if(dist[i]>mc){mc=dist[i];mode=i;}
  return {ie:ie,sessions:mine.length,evals:evals,st:st,dist:dist,mode:mode,modeShare:st.n?mc/st.n:0,flat:flat,flatShare:evals?flat/evals:0,comp:comp,obPer:evals?obN/evals:0,notesPer:evals?notes/evals:0,trend:byS,last:mine[mine.length-1]};
}
function ieFlags(r,G){
  var f=[],d=r.st.mean-G.mean;
  if(r.st.n<18)f.push(['Pocas sesiones','','Menos de 2 sesiones completas; las señales aún no son concluyentes.']);
  if(r.st.n>=18&&(d>0.5||r.st.p45>=0.85))f.push(['Posible complacencia','warn','Promedio '+(d>0?'+':'')+f1(d)+' frente al grupo y '+Math.round(r.st.p45*100)+'% de grados 4–5.']);
  if(r.st.n>=18&&(d<-0.5||r.st.p12>=0.35))f.push(['Posible severidad','warn','Promedio '+f1(d)+' frente al grupo y '+Math.round(r.st.p12*100)+'% de grados 1–2.']);
  if(r.st.n>=18&&(r.modeShare>=0.7||r.st.sd<0.45))f.push(['Monotonía','bad','El grado '+r.mode+' representa el '+Math.round(r.modeShare*100)+'% de sus calificaciones (desv. '+f1(r.st.sd)+').']);
  if(r.flatShare>=0.5&&r.evals>=2)f.push(['Misma nota en las 9','bad','En el '+Math.round(r.flatShare*100)+'% de sus evaluaciones puso el mismo grado en todas las competencias.']);
  if(r.st.n>=18&&r.obPer<1)f.push(['Pocos OB marcados','','Marca menos de un OB por evaluación; la calificación queda sin evidencia.']);
  return f;
}
function histo(dist,mode){var tot=dist.reduce(function(a,b){return a+b;},0)||1,mx=Math.max.apply(null,dist)||1;
  return '<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:8px;align-items:end;height:120px">'+[1,2,3,4,5].map(function(g){var h=dist[g]/mx*100;return '<div style="display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;gap:4px"><span class="tiny num" style="font-weight:700;color:'+(g===mode?'var(--fg)':'var(--muted)')+'">'+Math.round(dist[g]/tot*100)+'%</span><div style="width:100%;height:'+Math.max(2,h)+'%;border-radius:6px 6px 2px 2px;background:var(--g'+g+');'+(g===mode?'outline:2px solid var(--fg);outline-offset:2px':'')+'"></div><span class="tiny muted num">'+g+'</span></div>';}).join('')+'</div>';}
function vInstructores(){
  if(!isCoord()){S.ui.route='inicio';return vInicio();}
  var ss=live('sessions').filter(function(s){return s.status==='signed';});
  var names={};ss.forEach(function(s){names[s.instructor||'Sin instructor']=1;});
  var all=[];ss.forEach(function(s){seats(s).forEach(function(x){CK.forEach(function(k){var e=s.grades[x][k];if(e&&e.g)all.push(e.g);});});});var G=stats(all);
  var rows=Object.keys(names).map(function(ie){return ieStats(ie,ss);}).sort(function(a,b){return b.st.n-a.st.n;});
  if(S.ui.ie&&names[S.ui.ie])return vInstructor(ieStats(S.ui.ie,ss),G,rows);
  var html=head('Instructores','Equipo habilitado y cómo califica cada instructor: promedio, nota más repetida y señales de complacencia, severidad o monotonía.');
  html+=teamCard();
  if(!rows.length)return html+'<div class="card">'+empty('people','Sin sesiones firmadas','Cuando los instructores firmen evaluaciones verás aquí su patrón de calificación.')+'</div>';
  html+='<div class="grid g4" style="margin-bottom:16px">'+kpi('Instructores',rows.length,'con sesiones firmadas')+kpi('Promedio del grupo',f1(G.mean),'desv. '+f1(G.sd)+' · '+G.n+' calificaciones')+kpi('Con señales',rows.filter(function(r){return ieFlags(r,G).some(function(f){return f[1];});}).length,'complacencia, severidad o monotonía',rows.some(function(r){return ieFlags(r,G).some(function(f){return f[1]==='bad';});})?'var(--bad)':'')+kpi('Nota más común',(function(){var d=[0,0,0,0,0,0];all.forEach(function(v){d[v]++;});var m=0,c=0;for(var i=1;i<=5;i++)if(d[i]>c){c=d[i];m=i;}return m||'—';})(),'en todo el grupo')+'</div>';
  html+='<div class="grid g3">'+rows.map(function(r){var fl=ieFlags(r,G),d=r.st.mean-G.mean;
    return '<button class="card" data-act="openIE" data-ie="'+esc(r.ie)+'" style="text-align:left;cursor:pointer;border:0;display:flex;flex-direction:column;gap:10px"><div class="row"><span class="avatar">'+initials(r.ie.split(' · ').pop())+'</span><div style="flex:1;min-width:0"><div style="font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(r.ie)+'</div><div class="small muted">'+r.sessions+' sesión'+(r.sessions===1?'':'es')+' · '+r.evals+' evaluaciones</div></div><span class="gchip '+gcls(r.st.mean)+'" style="width:42px;height:32px;font-size:14px">'+f1(r.st.mean)+'</span></div>'+
     '<div class="row" style="gap:14px"><div><div class="tiny muted">vs. grupo</div><div class="num" style="font-weight:700;color:'+(Math.abs(d)>0.5?'var(--warn)':'var(--fg)')+'">'+(d>=0?'+':'')+f1(Math.abs(d)<0.05?0:d).replace('—','0,0')+'</div></div><div><div class="tiny muted">Nota más repetida</div><div class="row" style="gap:6px"><span class="gchip '+gcls(r.mode)+'">'+(r.mode||'–')+'</span><span class="small num muted">'+Math.round(r.modeShare*100)+'%</span></div></div><div><div class="tiny muted">Desviación</div><div class="num" style="font-weight:700">'+f1(r.st.sd)+'</div></div></div>'+
     '<div style="display:flex;height:10px;border-radius:5px;overflow:hidden;gap:1px;background:var(--line)">'+[1,2,3,4,5].map(function(g){return r.dist[g]?'<div style="width:'+(r.dist[g]/(r.st.n||1)*100)+'%;background:var(--g'+g+')"></div>':'';}).join('')+'</div>'+
     '<div class="row" style="gap:4px">'+(fl.length?fl.map(function(f){return '<span class="pill '+f[1]+'">'+f[0]+'</span>';}).join(''):'<span class="pill ok">En rango</span>')+'</div></button>';}).join('')+'</div>';
  html+='<p class="small muted" style="margin-top:16px;max-width:760px">Complacencia: promedio 0,5 por encima del grupo o 85 % de grados 4–5. Severidad: promedio 0,5 por debajo o 35 % de grados 1–2. Monotonía: una misma nota en el 70 % de las calificaciones o desviación menor a 0,45. Las señales se calculan a partir de 18 calificaciones (dos evaluaciones completas).</p>';
  return html;
}
function vInstructor(r,G,rows){
  var fl=ieFlags(r,G),d=r.st.mean-G.mean;var gc=compAverages(live('sessions').filter(function(s){return s.status==='signed';}));
  var mine={};CK.forEach(function(k){mine[k]=r.comp[k]?avg(r.comp[k]):0;});
  var html='<button class="btn ghost" data-act="closeIE" style="margin:-6px 0 8px -8px">'+I.back+'Instructores</button>';
  html+=head(esc(r.ie),r.sessions+' sesiones firmadas · '+r.evals+' evaluaciones · '+r.st.n+' calificaciones','<button class="btn" data-act="pdfIE" data-ie="'+esc(r.ie)+'">'+I.down+'PDF</button>');
  html+='<div class="grid g4" style="margin-bottom:16px">'+kpi('Promedio',f1(r.st.mean),'grupo '+f1(G.mean)+' · '+(d>=0?'+':'')+f1(Math.abs(d)<0.05?0:d).replace('—','0,0'),Math.abs(d)>0.5?'var(--warn)':'')+kpi('Nota más repetida',r.mode||'—',Math.round(r.modeShare*100)+'% de sus calificaciones',r.modeShare>=0.7?'var(--bad)':'')+kpi('Desviación',f1(r.st.sd),r.st.sd<0.45?'poca variación entre notas':'variación normal',r.st.sd<0.45&&r.st.n>=18?'var(--bad)':'')+kpi('Misma nota en las 9',Math.round(r.flatShare*100)+'%','de sus evaluaciones',r.flatShare>=0.5?'var(--bad)':'')+'</div>';
  html+='<div class="card" style="margin-bottom:16px"><div class="card-head"><div><h3>Señales</h3><p class="small muted">Lectura automática del patrón de calificación</p></div></div>'+(fl.length?fl.map(function(f){return '<div class="flag"><span class="pill '+f[1]+'" style="flex:none">'+f[0]+'</span><span class="small">'+esc(f[2])+'</span></div>';}).join(''):'<p class="small muted">En rango: su promedio, dispersión y uso de la escala son coherentes con el grupo.</p>')+'</div>';
  html+='<div class="grid g2" style="margin-bottom:16px"><div class="card"><div class="card-head"><div><h3>Distribución de notas</h3><p class="small muted">Qué tanto usa cada grado de la escala · recuadro: la más repetida</p></div></div>'+histo(r.dist,r.mode)+'</div>'+
   '<div class="card"><div class="card-head"><div><h3>Evolución del promedio</h3><p class="small muted">Promedio otorgado en cada sesión firmada</p></div></div>'+trend(r.trend,'var(--accent)')+'</div></div>';
  html+='<div class="grid g2" style="margin-bottom:16px"><div class="card"><div class="card-head"><div><h3>Por competencia frente al grupo</h3><p class="small muted">Barra: este instructor · línea: promedio del grupo</p></div></div>'+hbars(mine,null,gc)+'</div>'+
   '<div class="card"><div class="card-head"><div><h3>Evidencia que deja</h3><p class="small muted">Por evaluación individual</p></div></div><dl class="kv"><dt>OB marcados</dt><dd>'+r.obPer.toFixed(1).replace('.',',')+' por evaluación</dd><dt>Competencias con nota escrita</dt><dd>'+r.notesPer.toFixed(1).replace('.',',')+' de 9</dd><dt>% grados 4–5</dt><dd>'+Math.round(r.st.p45*100)+'% <span class="muted small">(grupo '+Math.round(G.p45*100)+'%)</span></dd><dt>% grados 1–2</dt><dd>'+Math.round(r.st.p12*100)+'% <span class="muted small">(grupo '+Math.round(G.p12*100)+'%)</span></dd><dt>Última sesión</dt><dd>'+(r.last?esc(r.last.phase)+' · '+fdate(r.last.date):'—')+'</dd></dl></div></div>';
  html+='<div class="card"><div class="card-head"><div><h3>Comparación con los demás instructores</h3></div></div><div class="scroll-x"><table class="tbl"><thead><tr><th>Instructor</th><th>Calif.</th><th>Promedio</th><th>Más repetida</th><th>Desv.</th><th>% 4–5</th><th>% 1–2</th></tr></thead><tbody>'+rows.map(function(o){return '<tr class="click" data-act="openIE" data-ie="'+esc(o.ie)+'"'+(o.ie===r.ie?' style="font-weight:700"':'')+'><td>'+esc(o.ie)+'</td><td class="num">'+o.st.n+'</td><td><span class="gchip '+gcls(o.st.mean)+'" style="width:36px">'+f1(o.st.mean)+'</span></td><td><span class="gchip '+gcls(o.mode)+'">'+(o.mode||'–')+'</span> <span class="tiny muted num">'+Math.round(o.modeShare*100)+'%</span></td><td class="num">'+f1(o.st.sd)+'</td><td class="num">'+Math.round(o.st.p45*100)+'%</td><td class="num">'+Math.round(o.st.p12*100)+'%</td></tr>';}).join('')+'</tbody></table></div></div>';
  return html;
}
async function pdfIE(ie){
  if(!hasPDF()){toast('El PDF necesita conexión la primera vez que se abre la app');return;}
  var ss=live('sessions').filter(function(s){return s.status==='signed';});var all=[];ss.forEach(function(s){seats(s).forEach(function(x){CK.forEach(function(k){var e=s.grades[x][k];if(e&&e.g)all.push(e.g);});});});var G=stats(all);
  var r=ieStats(ie,ss),fl=ieFlags(r,G);
  var doc=pdfBase('Patrón de calificación del instructor',ie+' · '+r.sessions+' sesiones · '+r.st.n+' calificaciones');
  var y=T(doc,{startY:30,body:[['Promedio',f1(r.st.mean)+' (grupo '+f1(G.mean)+')','Nota más repetida',r.mode+' · '+Math.round(r.modeShare*100)+'%'],['Desviación',f1(r.st.sd),'Misma nota en las 9',Math.round(r.flatShare*100)+'% de evaluaciones'],['% grados 4–5',Math.round(r.st.p45*100)+'% (grupo '+Math.round(G.p45*100)+'%)','% grados 1–2',Math.round(r.st.p12*100)+'% (grupo '+Math.round(G.p12*100)+'%)']],columnStyles:{0:{textColor:[108,108,115],cellWidth:30},2:{textColor:[108,108,115],cellWidth:36}}});
  pdfH(doc,'Señales',y+10);y=pdfPara(doc,fl.length?fl.map(function(f){return '• '+f[0]+': '+f[2];}).join('\n'):'• En rango: promedio, dispersión y uso de la escala coherentes con el grupo.',y+16);
  doc.setFontSize(8);doc.setTextColor.apply(doc,PDFC.mu);doc.text('Distribución de notas (%)',16,y+8);
  var tot=r.st.n||1;[1,2,3,4,5].forEach(function(g,i){var x=16+i*36,h=r.dist[g]/tot*40;var c=RGB[g];doc.setFillColor(c[0],c[1],c[2]);doc.rect(x,y+54-h,28,h,'F');doc.setTextColor.apply(doc,PDFC.fg);doc.setFontSize(8);doc.text(String(g),x+14,y+60,{align:'center'});doc.text(Math.round(r.dist[g]/tot*100)+'%',x+14,y+52-h,{align:'center'});});
  y+=66;var mine={};CK.forEach(function(k){mine[k]=r.comp[k]?avg(r.comp[k]):0;});var gc=compAverages(ss);
  doc.setFontSize(8);doc.setTextColor.apply(doc,PDFC.mu);doc.text('Por competencia (barra: instructor · línea: grupo)',16,y);y=pdfBars(doc,16,y+4,178,mine,gc)+6;
  if(r.trend.length>1){doc.setFontSize(8);doc.setTextColor.apply(doc,PDFC.mu);doc.text('Evolución del promedio por sesión',16,y+4);pdfTrend(doc,16,y+8,178,44,r.trend,PDFC.acc);}
  pdfFoot(doc);await saveFile('instructor-'+slug(ie)+'.pdf',doc.output('blob'));
}
var IE_ACT={openIE:function(el){S.ui.ie=el.dataset.ie;go('instructores');},closeIE:function(){S.ui.ie='';go('instructores');},pdfIE:function(el){pdfIE(el.dataset.ie);},
  kpiGo:function(el){var t=el.dataset.t;if(t==='alerts'){var a=document.getElementById('alertas');if(a){a.scrollIntoView({behavior:'smooth',block:'start'});a.style.outline='2px solid var(--accent)';setTimeout(function(){a.style.outline='';},1600);}}else go(t);}};
