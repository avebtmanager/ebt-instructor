/* ============ Acceso: cuentas reales (Supabase Auth) ============ */
var AUTH={mode:'login',email:'',pw:'',pw2:'',err:'',info:'',busy:false,kind:''};
function firstName(n){var w=String(n||'').split(/\s+/).filter(function(x){return x&&!/^(cap|cmte|cpt|fo|ing|sr|sra|dr|lic)\.?$/i.test(x);});return w[0]||'';}
function ieBlocked(){return false;}
function blockedHTML(){return '';}
function lockIfNeeded(){}
function fld(id,key,lbl,type,ph,extra){return '<div class="field" style="text-align:left"><label for="'+id+'">'+lbl+'</label><input class="input" id="'+id+'" type="'+(type||'text')+'" data-auth="'+key+'" value="'+esc(AUTH[key]||'')+'" placeholder="'+esc(ph||'')+'" '+(extra||'')+'></div>';}
function lockHTML(){
  var m=AUTH.mode,body='',title='EBT Instructor',sub='Evaluación por competencias';
  if(m==='loading'){body='<p class="small muted">Cargando tu cuenta…</p>';}
  else if(m==='login'){body=fld('au-e','email','Correo','email','nombre@empresa.com','autocapitalize="none" autocomplete="username" autofocus')+fld('au-p','pw','Contraseña','password','','autocomplete="current-password"')+
    '<label class="row small" style="gap:8px;justify-content:flex-start;cursor:pointer"><input type="checkbox" data-auth="remember" '+(AUTH.remember!==false?'checked':'')+'> Mantener la sesión en este dispositivo</label>'+
    '<button class="btn primary" data-act="login" style="width:100%;height:44px"'+(AUTH.busy?' disabled':'')+'>'+(AUTH.busy?'Entrando…':'Entrar')+'</button>'+
    '<button class="btn ghost sm" data-act="authMode" data-m="forgot">¿Olvidaste tu contraseña?</button>'+
    '<p class="tiny muted" style="margin-top:4px">El acceso lo habilita el Manager EBT con una invitación a tu correo.</p>';}
  else if(m==='forgot'){body='<p class="small muted">Escribe tu correo y te enviaremos un enlace para crear una contraseña nueva.</p>'+fld('au-e','email','Correo','email','nombre@empresa.com','autocapitalize="none" autocomplete="username" autofocus')+
    '<button class="btn primary" data-act="forgot" style="width:100%;height:44px"'+(AUTH.busy?' disabled':'')+'>Enviar enlace</button><button class="btn ghost sm" data-act="authMode" data-m="login">Volver</button>';}
  else if(m==='sent'){body='<div class="note" style="text-align:left">Si '+esc(AUTH.email)+' tiene acceso, en unos minutos te llegará un correo con el enlace. Revisa también la carpeta de spam.</div><button class="btn ghost sm" data-act="authMode" data-m="login">Volver a ingresar</button>';}
  else if(m==='setpw'){title=AUTH.kind==='invite'?'Bienvenido':'Nueva contraseña';sub=AUTH.kind==='invite'?'Crea tu contraseña para entrar a EBT Instructor':'Crea una contraseña nueva para '+esc(myEmail());
    body=fld('au-p','pw','Contraseña (mínimo 8 caracteres)','password','','autocomplete="new-password" autofocus')+fld('au-p2','pw2','Repite la contraseña','password','','autocomplete="new-password"')+
    '<button class="btn primary" data-act="setPw" style="width:100%;height:44px"'+(AUTH.busy?' disabled':'')+'>Guardar y entrar</button>';}
  else if(m==='noaccess'){body='<div class="note" style="text-align:left">La cuenta <b>'+esc(myEmail())+'</b> no tiene acceso a EBT Instructor. Pide al Manager EBT que te envíe una invitación.</div><button class="btn" data-act="logout">Usar otra cuenta</button>';}
  else if(m==='inactive'){body='<div class="note" style="text-align:left">El Manager EBT desactivó el acceso de <b>'+esc(myEmail())+'</b>. Si crees que es un error, escríbele para reactivarlo.</div><button class="btn" data-act="logout">Usar otra cuenta</button>';}
  else if(m==='linkerr'){body='<div class="note" style="text-align:left">El enlace del correo venció o ya se usó. Pide al Manager que te reenvíe la invitación, o usa «¿Olvidaste tu contraseña?» si ya tenías cuenta.</div><button class="btn primary" data-act="authMode" data-m="login">Ir a ingresar</button><button class="btn ghost sm" data-act="authMode" data-m="forgot">¿Olvidaste tu contraseña?</button>';}
  var i=syncInfo();
  return '<div class="scrim" style="background:var(--bg);z-index:200;align-items:center;padding:24px" id="lock"><form onsubmit="return false" style="width:min(380px,100%);display:flex;flex-direction:column;gap:12px;text-align:center"><img src="'+LOGO_BIG+'" alt="" style="display:block;margin:0 auto 6px;width:92px;height:92px"><h2>'+title+'</h2><p class="small muted" style="margin:-4px 0 10px">'+sub+'</p>'+body+
   (AUTH.err?'<div class="note" style="color:var(--bad);text-align:left">'+esc(AUTH.err)+'</div>':'')+(AUTH.info?'<div class="note" style="text-align:left">'+esc(AUTH.info)+'</div>':'')+
   (online()?'':'<p class="tiny muted">Sin conexión. Si ya iniciaste sesión antes en este dispositivo con «Mantener la sesión», la app abre sin internet.</p>')+'</form></div>';
}
function authFail(msg){AUTH.err=msg;AUTH.busy=false;render();}
function authMsg(e){
  if(e&&e.offline)return 'Sin conexión. Conéctate a internet para iniciar sesión.';
  var c=(e&&(e.code||''))+' '+(e&&e.message||'');
  if(/invalid_credentials|Invalid login/i.test(c))return 'Correo o contraseña incorrectos.';
  if(/email_not_confirmed/i.test(c))return 'Tu correo aún no está confirmado. Abre el enlace de la invitación.';
  if(/weak_password|at least/i.test(c))return 'La contraseña es muy débil. Usa al menos 8 caracteres combinando letras y números.';
  if(/same_password|different from the old/i.test(c))return 'La contraseña nueva debe ser distinta de la anterior.';
  if(/over_email_send_rate|rate limit/i.test(c))return 'Se enviaron demasiados correos. Espera unos minutos e intenta de nuevo.';
  if(/reauthentication/i.test(c))return 'Por seguridad, cierra sesión y usa «¿Olvidaste tu contraseña?» para cambiarla.';
  return (e&&e.message)||'No se pudo completar. Intenta de nuevo.';
}
function resetLocalData(){var keep={photo:S.settings.photo,remember:S.settings.remember};S=blank();S.settings.photo=keep.photo||'';S.settings.remember=keep.remember;}
async function afterLogin(){
  var id=myId();if(S.owner&&S.owner!==id)resetLocalData();S.owner=id;
  try{sessionStorage.setItem('ei-active','1');}catch(e){}
  AUTH.pw='';AUTH.pw2='';AUTH.err='';AUTH.info='';AUTH.busy=false;AUTH.mode='loading';persist0();render();
  await connect();
  if(!LOCKED)toast('Bienvenido, '+(firstName(S.settings.instructor)||myEmail()));
}
var AUTH_ACT={
  authMode:function(el){AUTH.mode=el.dataset.m;AUTH.err='';AUTH.info='';render();},
  login:async function(){var e=String(AUTH.email||'').trim().toLowerCase(),p=AUTH.pw||'';if(!e||!p)return authFail('Escribe tu correo y tu contraseña.');
    AUTH.busy=true;AUTH.err='';render();
    try{await sbSignIn(e,p);S.settings.remember=AUTH.remember!==false;await afterLogin();}catch(err){authFail(authMsg(err));}},
  forgot:async function(){var e=String(AUTH.email||'').trim().toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e))return authFail('Escribe un correo válido.');
    AUTH.busy=true;render();try{await sbRecover(e);AUTH.busy=false;AUTH.err='';AUTH.mode='sent';render();}catch(err){authFail(authMsg(err));}},
  setPw:async function(){if((AUTH.pw||'').length<8)return authFail('La contraseña debe tener al menos 8 caracteres.');if(AUTH.pw!==AUTH.pw2)return authFail('Las contraseñas no coinciden.');
    AUTH.busy=true;render();try{await sbSetPassword(AUTH.pw);S.settings.remember=true;await afterLogin();}catch(err){authFail(authMsg(err));}},
  logout:function(){var n=Object.keys(S.outbox||{}).length;if(n&&SB.session&&!LOCKED){openSheet({type:'confirm',title:'Cerrar sesión',msg:'Hay '+n+' cambio'+(n>1?'s':'')+' sin subir. Si cierras sesión ahora se perderán. Conéctate a internet y espera a que diga «Sincronizado».',yes:'Cerrar sesión igual',act:'logoutYes'});return;}doLogout();},
  changePw:async function(){var n=document.getElementById('cp-new'),n2=document.getElementById('cp-new2');if(!n)return;
    if(n.value.length<8)return toast('La contraseña nueva debe tener al menos 8 caracteres');if(n.value!==n2.value)return toast('Las contraseñas no coinciden');
    try{await sbSetPassword(n.value);n.value=n2.value='';toast('Contraseña actualizada');}catch(e){toast(authMsg(e));}}
};
async function doLogout(){await sbSignOut();clearInterval(pullT);resetLocalData();S.owner='';try{sessionStorage.removeItem('ei-active');}catch(e){}persist0();LOCKED=true;AUTH.mode='login';AUTH.err='';AUTH.info='';dbState='off';render();}
document.addEventListener('input',function(e){var t=e.target;if(t.dataset&&t.dataset.auth){AUTH[t.dataset.auth]=t.type==='checkbox'?t.checked:t.value;}});
document.addEventListener('change',function(e){var t=e.target;if(t.dataset&&t.dataset.auth&&t.type==='checkbox'){AUTH[t.dataset.auth]=t.checked;}});
document.addEventListener('keydown',function(e){if(LOCKED&&e.key==='Enter'&&e.target.dataset&&e.target.dataset.auth){e.preventDefault();var f={login:'login',forgot:'forgot',setpw:'setPw'}[AUTH.mode];if(f&&ACT[f])ACT[f]();}});

async function sbBoot(){
  sbLoad();applyScale();
  var h=(location.hash||'').replace(/^#/,''),q=new URLSearchParams(h);
  if(q.get('error')||q.get('error_code')){history.replaceState(null,'',appUrl());LOCKED=true;AUTH.mode='linkerr';render();return;}
  if(q.get('access_token')){
    var type=q.get('type')||'';history.replaceState(null,'',appUrl());
    try{var u=await sbUser(q.get('access_token'));sbSetSession({access_token:q.get('access_token'),refresh_token:q.get('refresh_token'),expires_in:+q.get('expires_in')||3600,expires_at:+q.get('expires_at')||0,user:u});}
    catch(e){LOCKED=true;AUTH.mode=e.offline?'login':'linkerr';if(e.offline)AUTH.err='Sin conexión: abre el enlace cuando tengas internet.';render();return;}
    if(S.owner&&S.owner!==myId())resetLocalData();S.owner=myId();S.settings.remember=true;persist0();
    if(type==='invite'||type==='recovery'){LOCKED=true;AUTH.mode='setpw';AUTH.kind=type;render();return;}
  }
  var active=false;try{active=!!sessionStorage.getItem('ei-active');}catch(e){}
  if(SB.session&&!S.settings.remember&&!active){SB.session=null;sbStore();}
  if(!SB.session){LOCKED=true;AUTH.mode='login';render();return;}
  try{sessionStorage.setItem('ei-active','1');}catch(e){}
  if(S.me&&S.owner===myId()){applyMember(S.me);LOCKED=false;}else{LOCKED=true;AUTH.mode='loading';}
  render();connect();
}

/* ============ Cuenta, respaldo ============ */
function accountCard(){var st=S.settings;return '<div class="card stack"><h3>Cuenta y acceso</h3><div class="kv"><dt>Correo</dt><dd>'+esc(myEmail()||'—')+'</dd><dt>Rol</dt><dd>'+(isCoordReal()?'Manager EBT':'Instructor')+'</dd><dt>Sesión</dt><dd>'+(st.remember?'Se mantiene en este dispositivo':'Se pide al abrir la app')+'</dd></div><div class="field"><label for="cp-new">Cambiar contraseña</label><div class="grid g2" style="gap:8px"><input class="input" id="cp-new" type="password" placeholder="Nueva (mín. 8)" autocomplete="new-password"><input class="input" id="cp-new2" type="password" placeholder="Repetir" autocomplete="new-password"></div></div><div class="row"><button class="btn sm" data-act="changePw">Actualizar contraseña</button><button class="btn ghost sm" data-act="logout">Cerrar sesión</button></div><p class="tiny muted">Si olvidas la contraseña, usa «¿Olvidaste tu contraseña?» en la pantalla de entrada.</p></div>';}
function backupCard(){if(!isCoord())return '';var st=S.settings,n=live('sessions').filter(function(s){return s.status==='signed';}).length;if(!n)return '';var days=st.lastBackup?Math.floor((Date.now()-st.lastBackup)/86400000):null;if(days!==null&&days<30)return '';
  return '<div class="card" style="margin-bottom:16px;display:flex;align-items:center;gap:14px;flex-wrap:wrap"><span class="gchip gc0" style="width:40px;height:40px;border-radius:12px;color:var(--accent)">'+I.down.replace('<svg','<svg width="20" height="20"')+'</span><div style="flex:1;min-width:200px"><h3>'+(days===null?'Aún no has descargado un respaldo':'Último respaldo hace '+days+' días')+'</h3><p class="small muted">Las evaluaciones quedan guardadas en la base de datos. Además, descarga una copia mensual en JSON y guárdala fuera de la app.</p></div><button class="btn primary sm" data-act="backup">'+I.down+'Descargar respaldo</button></div>';}

/* ============ Formato de evaluación (solo Manager) ============ */
function formatCard(){
  if(!isCoord())return '';var sc=ORG('scale',{});
  function chk(k,lbl,d){return '<label class="row small" style="gap:8px;cursor:pointer"><input type="checkbox" data-org="'+k+'" '+(ORG(k,d)?'checked':'')+'> '+lbl+'</label>';}
  var below=ORG('requireNoteAtOrBelow',2);
  return '<div class="card stack" style="grid-column:1/-1"><div><h3>Formato de evaluación</h3><p class="small muted">Se aplica a todos los instructores. Los cambios se guardan y sincronizan solos.</p></div>'+
   '<div class="eyebrow">Escala de calificación</div><div class="stack" style="gap:8px">'+[1,2,3,4,5].map(function(g){var e=sc[g]||sc[String(g)]||{};return '<div class="row" style="gap:8px;flex-wrap:nowrap"><span class="gchip gc'+g+'" style="flex:none">'+g+'</span><input class="input" data-org="scale.'+g+'.label" value="'+esc(e.label||GL[g])+'" aria-label="Nombre del grado '+g+'" style="flex:2;min-width:0"><input class="input" data-org="scale.'+g+'.short" value="'+esc(e.short||GS[g])+'" aria-label="Abreviatura del grado '+g+'" style="flex:1;min-width:0;max-width:140px"><input type="color" data-org="scale.'+g+'.color" value="'+esc(e.color||'#888888')+'" aria-label="Color del grado '+g+'" style="width:44px;height:40px;border:0;background:none;flex:none"></div>';}).join('')+'</div>'+
   '<div class="eyebrow" style="margin-top:4px">Reglas al calificar y firmar</div><div class="stack" style="gap:8px">'+
   chk('allowNO','Permitir N/O (no observado)',true)+chk('requireNoteForNO','Exigir justificación cuando una competencia queda N/O',true)+
   '<label class="row small" style="gap:8px">Exigir evidencia escrita en grados <select class="input" data-org="requireNoteAtOrBelow" style="width:auto;height:34px">'+[[0,'ninguno'],[1,'1'],[2,'1 y 2'],[3,'1 a 3']].map(function(o){return '<option value="'+o[0]+'"'+(+below===o[0]?' selected':'')+'>'+o[1]+'</option>';}).join('')+'</select></label>'+
   chk('temEnabled','Mostrar registro TEM (amenazas, errores y estados indeseados)',true)+chk('requireTraineeSignature','Exigir firma del trainee para cerrar la evaluación',false)+'</div>'+
   '<p class="tiny muted">Frases, fases, flotas, módulos y simuladores se editan en «Ciclo EBT» y «Frases predefinidas». Las plantillas de cada sesión se gestionan en Biblioteca EVAL.</p></div>';
}
document.addEventListener('change',function(e){var t=e.target;if(!t.dataset||!t.dataset.org||!isCoord())return;
  var v=t.type==='checkbox'?t.checked:t.tagName==='SELECT'?+t.value:t.value;S.org=S.org||{};setPath(S.org,t.dataset.org,v);S.orgDirty=true;applyScale();persist0();scheduleFlush();if(t.type==='checkbox'||t.tagName==='SELECT'||t.type==='color')setTimeout(render,0);});

/* ============ Equipo (Manager) ============ */
var ROLE_LBL={manager:'Manager EBT',instructor:'Instructor'};
function teamCard(){
  if(!isCoord())return '';
  var ms=Object.keys(members()).map(function(k){return members()[k];}).sort(function(a,b){return (a.full_name||a.email||'').localeCompare(b.full_name||b.email||'');});
  var inv=S.invites||[];
  var act=ms.filter(function(m){return m.status==='active';}).length;
  var html='<div class="card" style="margin-bottom:16px"><div class="card-head"><div><h3>Equipo habilitado</h3><p class="small muted">'+act+' activo'+(act===1?'':'s')+(inv.length?' · '+inv.length+' invitación'+(inv.length===1?'':'es')+' pendiente'+(inv.length===1?'':'s'):'')+'</p></div><button class="btn primary sm" data-act="newIE">'+I.plus+'Habilitar instructor</button></div>';
  html+='<div class="list">'+ms.map(function(m){var me=m.user_id===myId();return '<div class="li" style="cursor:default"><span class="avatar">'+initials(m.full_name||m.email)+'</span><div class="grow" style="min-width:0"><div class="t">'+esc(m.full_name||m.email)+(m.ie_code?' <span class="pill" style="height:18px;font-size:10.5px">'+esc(m.ie_code)+'</span>':'')+(me?' <span class="tiny muted">(tú)</span>':'')+'</div><div class="small muted">'+[ROLE_LBL[m.role],m.fleet,m.email].filter(Boolean).map(esc).join(' · ')+'</div></div>'+(m.status==='active'?'<span class="pill ok">Activo</span>':'<span class="pill bad">Inactivo</span>')+(me?'':'<button class="btn ghost sm" data-act="editMember" data-id="'+m.user_id+'" aria-label="Editar">'+I.chev+'</button>')+'</div>';}).join('')+
   inv.map(function(v){return '<div class="li" style="cursor:default"><span class="avatar" style="opacity:.6">'+initials(v.full_name||v.email)+'</span><div class="grow" style="min-width:0"><div class="t">'+esc(v.full_name||v.email)+'</div><div class="small muted">'+esc(v.email)+' · invitado '+ftime(ts(v.created_at))+'</div></div><span class="pill warn">Pendiente</span><button class="btn ghost sm" data-act="resendInvite" data-email="'+esc(v.email)+'">Reenviar</button><button class="btn ghost sm" data-act="cancelInvite" data-email="'+esc(v.email)+'" aria-label="Cancelar invitación" style="color:var(--muted)">'+I.x+'</button></div>';}).join('')+'</div>';
  html+='<p class="tiny muted" style="margin-top:10px">El instructor recibe un correo con un enlace para crear su contraseña. Si el enlace vence, usa «Reenviar».</p>';
  return html+'</div>';
}
function ieForm(){
  var f=S.ui.form,st=S.settings,edit=!!f.user_id;
  return '<div class="stack"><div class="field"><label for="ie-n">Nombre completo</label><input class="input" id="ie-n" data-fb="full_name" value="'+esc(f.full_name||'')+'" placeholder="Cap. Nombre Apellido" autofocus></div>'+
   (edit?'<div class="field"><label>Correo</label><div class="small">'+esc(f.email||'')+'</div></div>':'<div class="field"><label for="ie-em">Correo</label><input class="input" id="ie-em" data-fb="email" type="email" value="'+esc(f.email||'')+'" placeholder="nombre@empresa.com" autocapitalize="none"></div>')+
   '<div class="grid g2" style="gap:12px"><div class="field"><label for="ie-id">Código de instructor</label><input class="input" id="ie-id" data-fb="ie_code" value="'+esc(f.ie_code||'')+'" placeholder="IE-05"></div><div class="field"><label for="ie-rk">Cargo</label><select class="input" id="ie-rk" data-fb="rank"><option value="">—</option><option value="CPT"'+(f.rank==='CPT'?' selected':'')+'>Capitán</option><option value="FO"'+(f.rank==='FO'?' selected':'')+'>Primer oficial</option></select></div></div>'+
   '<div class="grid g2" style="gap:12px"><div class="field"><label for="ie-fl">Flota</label><select class="input" id="ie-fl" data-fb="fleet"><option value="">—</option>'+st.fleets.map(function(x){return '<option'+(f.fleet===x?' selected':'')+'>'+esc(x)+'</option>';}).join('')+'</select></div><div class="field"><label for="ie-ro">Rol</label><select class="input" id="ie-ro" data-fb="role"><option value="instructor"'+(f.role!=='manager'?' selected':'')+'>Instructor</option><option value="manager"'+(f.role==='manager'?' selected':'')+'>Manager EBT</option></select></div></div>'+
   (edit?'<hr class="sep"><div class="row">'+(f.status==='inactive'?'<button class="btn sm" data-act="memberStatus" data-id="'+f.user_id+'" data-v="active">Reactivar acceso</button>':'<button class="btn danger sm" data-act="memberStatus" data-id="'+f.user_id+'" data-v="inactive">Desactivar acceso</button>')+'</div><p class="tiny muted">Al desactivarlo no puede entrar ni ver datos. Sus evaluaciones firmadas se conservan.</p>':'<p class="tiny muted">Se enviará una invitación a ese correo. Al abrirla, la persona crea su contraseña y entra directamente.</p>')+'</div>';
}
function needOnline(){if(!online()){toast('Necesitas conexión a internet para esto');return false;}return true;}
function fnMsg(e){var c=e&&(e.code||e.message)||'';return c==='invalid_email'?'El correo no es válido.':c==='forbidden'?'Solo el Manager puede invitar.':c==='self'?'Ese correo es tu propia cuenta.':c==='email_failed'?'No se pudo enviar el correo: '+((e.body&&e.body.detail)||''):(e&&e.message)||'No se pudo completar.';}
var TEAM_ACT={
  newIE:function(){S.ui.form={full_name:'',email:'',ie_code:'',rank:'CPT',fleet:S.settings.fleets[0]||'',role:'instructor'};openSheet({type:'ie'});},
  editMember:function(el){var m=members()[el.dataset.id];if(!m)return;S.ui.form=JSON.parse(JSON.stringify(m));openSheet({type:'ie',id:m.user_id});},
  saveIE:async function(){var f=S.ui.form;if(!needOnline())return;
    if(f.user_id){try{await sbPatch('ei_members','user_id=eq.'+f.user_id,{full_name:(f.full_name||'').trim(),ie_code:f.ie_code||null,rank:f.rank||null,fleet:f.fleet||null,role:f.role==='manager'?'manager':'instructor'});S.ui.sheet=null;toast('Datos actualizados');pull();}catch(e){toast(e.message);}return;}
    var email=String(f.email||'').trim().toLowerCase();if(!(f.full_name||'').trim())return toast('Escribe el nombre');if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return toast('Escribe un correo válido');
    var btn=document.querySelector('[data-act="saveIE"]');if(btn){btn.disabled=true;btn.textContent='Enviando…';}
    try{var r=await sbFn('ei-invite',{email:email,full_name:f.full_name.trim(),ie_code:f.ie_code,rank:f.rank,fleet:f.fleet,role:f.role,redirectTo:appUrl()});
      S.ui.sheet=null;toast(r&&r.status==='existing_user'?'Ya tenía cuenta: quedó habilitado y puede entrar con su contraseña':'Invitación enviada a '+email);pull();}
    catch(e){if(btn){btn.disabled=false;btn.textContent='Enviar invitación';}toast(fnMsg(e.body&&e.body.error?{code:e.body.error,body:e.body,message:e.message}:e));}},
  resendInvite:async function(el){if(!needOnline())return;var v=(S.invites||[]).filter(function(x){return x.email===el.dataset.email;})[0]||{email:el.dataset.email};
    try{await sbFn('ei-invite',{email:v.email,full_name:v.full_name,ie_code:v.ie_code,rank:v.rank,fleet:v.fleet,role:v.role,redirectTo:appUrl()});toast('Invitación reenviada');pull();}catch(e){toast(fnMsg(e.body&&e.body.error?{code:e.body.error,body:e.body,message:e.message}:e));}},
  cancelInvite:async function(el){if(!needOnline())return;try{await sbFn('ei-invite',{action:'cancel',email:el.dataset.email});toast('Invitación cancelada');pull();}catch(e){toast(e.message);}},
  memberStatus:async function(el){if(!needOnline())return;try{await sbPatch('ei_members','user_id=eq.'+el.dataset.id,{status:el.dataset.v});S.ui.sheet=null;toast(el.dataset.v==='active'?'Acceso reactivado':'Acceso desactivado');pull();}catch(e){toast(e.message);}}
};

/* ============ Diseño del EBT Manager → plantillas (solo lectura del EBT Manager) ============ */
var EM={state:'idle',msg:'',design:null,raw:null,sel:{fleet:'',module:'1'},busy:false};
function emPhaseOf(s){var u=s.toUpperCase();if(u.indexOf('EVAL')===0)return 'EVAL';if(u.indexOf('SBT')===0||u.indexOf('LOFT')>=0)return 'SBT';if(u.indexOf('LOE')===0||u.indexOf('LINE')>=0)return 'LOE';if(u.indexOf('MT')===0||u.indexOf('LPC')>=0||u.indexOf('MV')>=0||u.indexOf('UPRT')>=0)return 'MT';return 'SBT';}
function emModuleName(m){var hit=(S.settings.modules||[]).filter(function(x){return x.indexOf('M'+m)===0;})[0];return hit||('M'+m);}
function emFleets(){var d=EM.raw&&EM.raw.data||{};return Object.keys(d).filter(function(f){return f&&f[0]!=='_';}).sort();}
function emModules(f){var d=EM.raw&&EM.raw.data&&EM.raw.data[f]||{};return Object.keys(d).sort();}
async function emLoad(){
  if(!needOnline())return;EM.busy=true;EM.msg='';render();
  try{EM.raw=await sbRpc('ei_manager_design');EM.state='ready';var fs=emFleets();if(fs.indexOf(EM.sel.fleet)<0)EM.sel.fleet=fs[0]||'';emBuild();}
  catch(e){EM.state='error';EM.msg=e.offline?'Sin conexión.':e.message;}
  EM.busy=false;render();
}
function emBuild(){
  var f=EM.sel.fleet,m=EM.sel.module,mod=EM.raw&&EM.raw.data&&EM.raw.data[f]&&EM.raw.data[f][m]||{};
  var groups={},order=[];
  Object.keys(mod).forEach(function(topic){var map=mod[topic]&&mod[topic].map||[];map.forEach(function(r){var s=String(r.s||'Sin sesión').trim();var t=String(r.t||'').trim();var key=t.toLowerCase();
    if(!groups[s]){groups[s]={s:s,items:[],keys:{}};order.push(s);}var g=groups[s];
    if(g.keys[key]){var it=g.keys[key];(r.c||[]).forEach(function(c){if(it.c.indexOf(c)<0)it.c.push(c);});if(it.topics.indexOf(topic)<0)it.topics.push(topic);return;}
    var it2={t:t,c:(r.c||[]).slice(),ex:r.ex||[],fcts:r.fcts||[],topics:[topic]};g.keys[key]=it2;g.items.push(it2);});});
  var tg=EM.raw&&EM.raw.target&&EM.raw.target[f]||{},targets=[];Object.keys(tg).forEach(function(c){if((tg[c]||[]).map(String).indexOf(String(m))>=0)targets.push(c);});
  order.sort(function(a,b){return a.localeCompare(b,'es',{numeric:true});});
  EM.design={fleet:f,module:m,groups:order.map(function(s){return groups[s];}),targets:targets};
}
function emExisting(f,m,s){return live('evals').filter(function(t){return t.em&&t.em.fleet===f&&String(t.em.module)===String(m)&&t.em.session===s;})[0]||null;}
function emCreateTpl(g){
  var d=EM.design;var old=emExisting(d.fleet,d.module,g.s);
  var r={id:old?old.id:uuid(),name:g.s+' · '+d.fleet+' · Módulo '+d.module,module:emModuleName(d.module),fleet:d.fleet,phase:emPhaseOf(g.s),targets:d.targets.slice(),note:'Importado del diseño del EBT Manager · '+g.items.length+' escenarios',
    events:g.items.map(function(it){return {t:it.t,c:it.c.filter(function(k){return CK.indexOf(k)>=0;}),phase:'',ex:it.ex,fcts:it.fcts,topics:it.topics};}),
    em:{fleet:d.fleet,module:d.module,session:g.s,importedAt:Date.now(),rev:EM.raw&&EM.raw.revision}};
  if(old){r.name=old.name;r.phase=old.phase||r.phase;r.note=old.note||r.note;r.events.forEach(function(e){var o=(old.events||[]).filter(function(x){return x.t===e.t;})[0];if(o&&o.phase)e.phase=o.phase;});}
  put('evals',r,true);return !old;
}
function vEBTM(){
  if(!isCoord()){S.ui.route='inicio';return vInicio();}
  if(EM.state==='idle'&&!EM.busy)setTimeout(emLoad,0);
  var html=head('Diseño EBT Manager','Convierte las sesiones que diseñaste en el EBT Manager en plantillas de evaluación. EBT Instructor solo lee ese diseño: nunca lo modifica.','<button class="btn" data-act="emReload"'+(EM.busy?' disabled':'')+'>'+I.cloud+(EM.busy?'Leyendo…':'Leer de nuevo')+'</button>');
  if(EM.state==='error')html+='<div class="note" style="color:var(--bad);margin-bottom:16px">'+esc(EM.msg)+'</div>';
  if(!EM.raw)return html+'<div class="card">'+empty('cloud',EM.busy?'Leyendo el diseño…':'Sin datos','El diseño se lee desde la misma base de datos del EBT Manager.')+'</div>';
  var fs=emFleets(),ms=emModules(EM.sel.fleet);if(ms.indexOf(EM.sel.module)<0)EM.sel.module=ms[0]||'1';
  html+='<div class="card stack" style="margin-bottom:16px"><div class="row"><div class="seg">'+fs.map(function(f){return '<button class="'+(EM.sel.fleet===f?'on':'')+'" data-act="emSel" data-k="fleet" data-v="'+esc(f)+'">'+esc(f)+'</button>';}).join('')+'</div><div class="seg">'+ms.map(function(m){return '<button class="'+(EM.sel.module===m?'on':'')+'" data-act="emSel" data-k="module" data-v="'+esc(m)+'">Módulo '+esc(m)+'</button>';}).join('')+'</div><span class="spacer"></span><span class="tiny muted">EBT Manager v'+esc(EM.raw.revision)+' · '+ftime(ts(EM.raw.updated_at))+'</span></div>';
  var d=EM.design;
  if(!d||!d.groups.length)html+='<p class="small muted">Este módulo no tiene sesiones con escenarios asignados en el EBT Manager.</p>';
  else{
    html+='<div class="row" style="gap:6px;flex-wrap:wrap"><span class="small muted">Competencias objetivo del módulo:</span>'+(d.targets.length?d.targets.map(function(c){return '<span class="pill acc">'+esc(c)+'</span>';}).join(''):'<span class="small muted">sin definir</span>')+'<span style="flex:1"></span><button class="btn primary sm" data-act="emTplAll">Crear/actualizar las '+d.groups.length+' plantillas</button></div>';
    html+='<div class="list">'+d.groups.map(function(g,i){var ex=emExisting(d.fleet,d.module,g.s);var comps={};g.items.forEach(function(it){it.c.forEach(function(c){comps[c]=1;});});
      return '<details class="disc" data-k="em'+i+'"'+(S.ui.open&&S.ui.open['em'+i]?' open':'')+'><summary class="li" style="list-style:none"><span class="gchip gc0" style="width:auto;padding:0 8px;font-size:11px">'+esc(emPhaseOf(g.s))+'</span><div class="grow"><div class="t">'+esc(g.s)+'</div><div class="small muted">'+g.items.length+' escenario'+(g.items.length===1?'':'s')+' · '+Object.keys(comps).sort().join(', ')+(ex?' · <span style="color:var(--ok)">plantilla creada</span>':'')+'</div></div><button class="btn sm" data-act="emTpl" data-i="'+i+'">'+(ex?'Actualizar':'Crear plantilla')+'</button></summary><div style="padding:6px 14px 12px 50px">'+g.items.map(function(it){return '<div class="small" style="padding:6px 0;border-top:1px solid var(--line)"><div class="row" style="gap:4px;margin-bottom:3px">'+it.c.map(function(c){return '<span class="pill" style="height:18px;font-size:10.5px">'+esc(c)+'</span>';}).join('')+(it.ex.length?'<span class="tiny muted">'+esc(it.ex.join(' '))+'</span>':'')+'</div>'+esc(it.t)+'</div>';}).join('')+'</div></details>';}).join('')+'</div>';
  }
  html+='</div><p class="small muted" style="max-width:760px">Las plantillas quedan en Biblioteca EVAL. Ahí puedes ajustar nombres, fases de vuelo y competencias de cada evento; esos cambios no afectan el EBT Manager. Si vuelves a importar una sesión, se conservan tus nombres y fases de vuelo.</p>';
  return html;
}
var EM_ACT={
  emReload:function(){emLoad();},
  emSel:function(el){EM.sel[el.dataset.k]=el.dataset.v;emBuild();render();},
  emTpl:function(el){var g=EM.design&&EM.design.groups[+el.dataset.i];if(!g)return;var isNew=emCreateTpl(g);render();toast(isNew?'Plantilla creada en Biblioteca EVAL':'Plantilla actualizada');},
  emTplAll:function(){if(!EM.design)return;var n=0;EM.design.groups.forEach(function(g){if(emCreateTpl(g))n++;});render();toast(n+' plantillas nuevas · '+(EM.design.groups.length-n)+' actualizadas');}
};

var _cy2=ACT.confirmYes;ACT.confirmYes=function(){var sh=S.ui.sheet;if(sh&&sh.act==='logoutYes'){S.ui.sheet=null;doLogout();return;}return _cy2();};
Object.assign(ACT,AUTH_ACT,TEAM_ACT,EM_ACT);
var _bk=ACT.backup;ACT.backup=function(){_bk();if(isCoord()){S.settings.lastBackup=Date.now();persist0();}};
function sheetExtra(sh){
  if(sh.type==='ie')return {title:sh.id?'Editar instructor':'Habilitar instructor',narrow:true,body:ieForm(),actions:'<button class="btn sm primary" data-act="saveIE">'+(sh.id?'Guardar':'Enviar invitación')+'</button>'};
  return null;
}
function aiOn(){return !!(window.claude&&window.claude.use);}
