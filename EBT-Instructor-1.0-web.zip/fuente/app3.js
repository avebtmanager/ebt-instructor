/* ============ Evaluar ============ */
function cur(){var s=S.sessions[S.ui.cur];return s&&!s.deleted&&s.status==='draft'?s:null;}
function vEvaluar(){
  var s=cur();
  if(!s)return vSetup();
  return S.ui.step===3?vClose(s):vGrade(s);
}
function stepsBar(n,s){
  var lab=['Configuración','Calificación','Cierre y firmas'];
  return '<div class="steps">'+lab.map(function(l,i){var k=i+1;return '<button class="step'+(n===k?' on':'')+(k<n?' done':'')+'" '+(s&&k>1?'data-act="step" data-v="'+k+'"':'')+'><i>'+(k<n?I.check.replace('<svg','<svg width="12" height="12"'):k)+'</i>'+l+'</button>';}).join('')+'</div>';
}
function vSetup(){
  var st=S.settings,u=S.ui.setup||(S.ui.setup={date:today(),module:st.module,fleet:st.fleets[0]||'A320',phase:st.phases[0]||'EVAL',mode:'crew',cm1:'',cm2:'',templateId:''});
  var ps=live('trainees').filter(function(p){return p.fleet===u.fleet;}).sort(function(a,b){return a.name.localeCompare(b.name);});
  var tpls=live('evals').filter(function(t){return t.fleet===u.fleet;});
  function opts(sel,rankHint){return '<option value="">Seleccionar…</option>'+ps.map(function(p){return '<option value="'+p.id+'"'+(sel===p.id?' selected':'')+'>'+esc(p.name)+' · '+(p.rank==='CPT'?'CPT':'FO')+'</option>';}).join('');}
  var drafts=live('sessions').filter(function(x){return x.status==='draft';});
  var html=head('Nueva evaluación','Configura la sesión. Puedes evaluar a un trainee o a la tripulación completa (CM1 y CM2).');
  html+=stepsBar(1);
  if(drafts.length)html+='<div class="note" style="margin-bottom:16px;display:flex;gap:10px;align-items:center;flex-wrap:wrap"><span style="flex:1;min-width:200px">Tienes '+drafts.length+' borrador'+(drafts.length>1?'es':'')+' sin cerrar.</span>'+drafts.slice(0,3).map(function(d){return '<button class="btn sm" data-act="resume" data-id="'+d.id+'">'+esc(d.phase)+' · '+esc(seats(d).map(function(x){return pname(d.pilots[x]).split(' ')[0];}).join('/'))+'</button>';}).join('')+'</div>';
  html+='<div class="grid g2"><div class="card stack"><h3>Sesión</h3><div class="grid g2" style="gap:12px">'+
   '<div class="field"><label for="u-date">Fecha</label><input type="date" class="input" id="u-date" data-bind="ui.setup.date" value="'+esc(u.date)+'"></div>'+
   '<div class="field"><label for="u-mod">Módulo</label><select class="input" id="u-mod" data-bind="ui.setup.module">'+st.modules.map(function(m){return '<option'+(u.module===m?' selected':'')+'>'+esc(m)+'</option>';}).join('')+'</select></div></div>'+
   '<div class="field"><label>Flota</label><div class="seg">'+st.fleets.map(function(f){return '<button class="'+(u.fleet===f?'on':'')+'" data-act="setup" data-k="fleet" data-v="'+esc(f)+'">'+esc(f)+'</button>';}).join('')+'</div></div>'+
   '<div class="field"><label>Fase</label><div class="seg">'+st.phases.map(function(f){return '<button class="'+(u.phase===f?'on':'')+'" data-act="setup" data-k="phase" data-v="'+esc(f)+'" title="'+esc(phaseName(f))+'">'+esc(f==='LINE'?'Line check':f)+'</button>';}).join('')+'</div><span class="tiny muted">'+esc(phaseName(u.phase))+'</span></div>'+
   '<div class="field"><label for="u-tpl">Plantilla de la biblioteca EVAL</label><select class="input" id="u-tpl" data-bind="ui.setup.templateId"><option value="">Sin plantilla (eventos libres)</option>'+tpls.map(function(t){return '<option value="'+t.id+'"'+(u.templateId===t.id?' selected':'')+'>'+esc(t.name)+' · '+esc(t.phase)+'</option>';}).join('')+'</select></div></div>'+
   '<div class="card stack"><h3>Tripulación</h3><div class="field"><label>A quién evalúas</label><div class="seg"><button class="'+(u.mode==='crew'?'on':'')+'" data-act="setup" data-k="mode" data-v="crew">Tripulación · CM1 + CM2</button><button class="'+(u.mode==='single'?'on':'')+'" data-act="setup" data-k="mode" data-v="single">Un piloto</button></div></div>'+
   '<div class="field"><label for="u-cm1">'+(u.mode==='crew'?'CM1 · piloto en el asiento izquierdo':'Trainee evaluado')+'</label><select class="input" id="u-cm1" data-bind="ui.setup.cm1">'+opts(u.cm1)+'</select></div>'+
   (u.mode==='crew'?'<div class="field"><label for="u-cm2">CM2 · piloto en el asiento derecho</label><select class="input" id="u-cm2" data-bind="ui.setup.cm2">'+opts(u.cm2)+'</select></div>':'')+
   (ps.length?'':'<p class="small muted">No hay trainees de '+esc(u.fleet)+' registrados.</p>')+'<div><button class="btn sm" data-act="newPilot">'+I.plus+'Agregar trainee</button></div></div></div>';
  html+='<div class="sticky-bar"><button class="btn primary" data-act="startEval">Comenzar evaluación'+I.chev.replace('class="chev"','width="16" height="16"')+'</button></div>';
  return html;
}
function isWide(){return window.innerWidth>=900;}
function evHistory(pid,title){
  var t=String(title||'').trim().toLowerCase();if(!pid||!t)return null;
  var hits=[];pilotSessions(pid).filter(function(s){return s.status==='signed';}).forEach(function(s){var x=seatOf(s,pid);(s.events||[]).forEach(function(e){if(String(e.t||'').trim().toLowerCase()!==t)return;var g=e.g&&e.g[x];if(!g){var ks=(e.c||[]).map(function(k){var q=s.grades[x][k];return q&&q.g||0;}).filter(Boolean);g=ks.length?Math.min.apply(null,ks):0;}if(g)hits.push({g:g,date:s.date,ie:s.instructor||'',derived:!(e.g&&e.g[x])});});});
  if(!hits.length)return null;hits.sort(function(a,b){return a.date.localeCompare(b.date);});var last=hits[hits.length-1];
  return {last:last.g,avg:avg(hits.map(function(h){return h.g;})),n:hits.length,date:last.date,ie:last.ie,derived:last.derived};
}
function histHTML(h){if(!h)return '<span class="hist">Sin registro previo</span>';return '<span class="hist" title="'+esc((h.ie?h.ie+' · ':'')+fdate(h.date)+(h.derived?' · derivado de competencias':''))+'"><span>Última <b class="gchip '+gcls(h.last)+'" style="width:22px;height:22px;font-size:12px">'+h.last+'</b></span><span>Prom <b>'+f1(h.avg)+'</b></span><span class="num">'+h.n+'×</span></span>';}
function compBlock(s,seat,c){
  var g=s.grades[seat]||(s.grades[seat]={});var r=g[c.k]||{};var ob=r.ob||{};var nOb=Object.keys(ob).filter(function(k){return ob[k];}).length;
  return '<div class="grades6">'+[1,2,3,4,5].map(function(v){return '<button class="gbtn g'+v+(r.g===v?' on':'')+'" data-act="grade" data-seat="'+seat+'" data-k="'+c.k+'" data-v="'+v+'" title="'+GL[v]+'">'+v+'<small>'+GS[v]+'</small></button>';}).join('')+(ORG('allowNO',true)?'<button class="gbtn no'+(r.no?' on':'')+'" data-act="gradeNO" data-seat="'+seat+'" data-k="'+c.k+'" title="No observado en esta sesión">N/O<small>no obs.</small></button>':'')+'</div>'+
    '<details class="disc"'+(S.ui.open&&S.ui.open[seat+c.k]?' open':'')+' data-k="'+seat+c.k+'"><summary>'+I.chev.replace('class="chev"','')+'Observable behaviours'+(nOb?' · '+nOb+' marcado'+(nOb>1?'s':''):'')+'</summary><div class="obs" style="margin-top:10px">'+
    c.ob.map(function(o){var v=ob[o[0]]||0;return '<button class="ob'+(v<0?' neg':v>0?' pos':'')+'" data-act="ob" data-seat="'+seat+'" data-k="'+c.k+'" data-o="'+o[0]+'"><span class="s">'+(v<0?'−':v>0?'+':'')+'</span><span class="k">'+o[0]+'</span><span>'+esc(o[1])+'</span></button>';}).join('')+
    '<p class="tiny muted">Toca una vez para marcar como deficiente (−), dos veces como fortaleza (+), tres para limpiar.</p></div></details>'+
    '<div class="chips mini">'+(S.settings.phrases||[]).map(function(ph){return '<button class="chip" data-act="phrase" data-seat="'+seat+'" data-k="'+c.k+'" data-t="'+esc(ph)+'">'+esc(ph.replace(/\.$/,''))+'</button>';}).join('')+'</div>'+
    '<textarea class="input" id="n-'+seat+'-'+c.k+'" data-sb="grades.'+seat+'.'+c.k+'.note" placeholder="'+(r.no?'Justifica por qué no se observó'+(ORG('requireNoteForNO',true)?' (obligatorio)':''):(r.g&&r.g<=ORG('requireNoteAtOrBelow',2)?'Evidencia observada (obligatoria para este grado)':'Evidencia observada (qué, cuándo, impacto)'))+'" style="min-height:60px">'+esc(r.note||'')+'</textarea>';
}
function evRow(s,e,i,sim,cols){
  var hist=cols.map(function(x){return s.pilots[x]?'<div style="min-width:0"><span class="tiny muted">'+x.toUpperCase()+' · </span>'+histHTML(evHistory(s.pilots[x],e.t))+'</div>':'';}).join('');
  var grade=cols.map(function(x){var v=e.g&&e.g[x]||0;return '<div class="row" style="gap:6px"><span class="tiny muted" style="width:28px">'+x.toUpperCase()+'</span><span class="evgrade">'+[1,2,3,4,5].map(function(n){return '<button class="'+(v===n?'on g'+n:'')+'" style="'+(v===n?'background:var(--g'+n+')':'')+'" data-act="evGrade" data-i="'+i+'" data-seat="'+x+'" data-v="'+n+'">'+n+'</button>';}).join('')+'</span></div>';}).join('');
  return '<div class="ev"><button class="check'+(e.done?' on':'')+'" data-act="evDone" data-i="'+i+'" aria-label="Completado">'+(e.done?I.check:'')+'</button><div style="flex:1;min-width:0"><div class="row" style="gap:8px"><span style="font-weight:550;flex:1;min-width:0">'+esc(e.t)+'</span>'+(sim?'<button class="btn sm'+(e.at?'':' primary')+'" data-act="evStamp" data-i="'+i+'">'+I.clock+(e.at?hhmm(e.at):'Ahora')+'</button>':(e.at?'<span class="pill num">'+hhmm(e.at)+'</span>':''))+'</div><div class="tags">'+(e.c||[]).map(function(c){return '<span class="tag">'+c+'</span>';}).join('')+'</div>'+
    '<div class="row" style="gap:12px;margin-top:6px;align-items:flex-start;flex-wrap:wrap"><div class="stack" style="gap:4px;flex:1;min-width:200px">'+hist+'</div><div class="stack" style="gap:4px">'+grade+'</div></div>'+
    (sim||e.note?'<textarea class="input" id="evn-'+i+'" data-sb="events.'+i+'.note" placeholder="Nota rápida del evento (dicta con el micrófono)" style="min-height:44px;margin-top:6px">'+esc(e.note||'')+'</textarea>':'')+'</div><button class="btn ghost sm" data-act="evDel" data-i="'+i+'" aria-label="Quitar evento">'+I.x+'</button></div>';
}
function vGrade(s){
  var ss=seats(s),wide=s.mode==='crew'&&isWide();
  var seat=S.ui.seat&&ss.indexOf(S.ui.seat)>=0?S.ui.seat:'cm1';S.ui.seat=seat;
  var cols=wide?ss:[seat];
  var total=ss.reduce(function(a,x){return a+graded(s,x);},0),max=ss.length*9;
  var html='<div class="sess-head"><div class="row" style="gap:10px"><div style="flex:1;min-width:0"><div class="eyebrow">'+esc(s.fleet)+' · '+esc(s.phase)+' · '+esc(s.module)+' · '+fdate(s.date)+'</div><h2 style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+ss.map(function(x){return esc(pname(s.pilots[x]));}).join(' · ')+'</h2></div><span class="small muted num" style="white-space:nowrap">'+total+'/'+max+' · '+Math.round(total/max*100)+'%</span><button class="iconbtn hide-sm" data-act="discard" data-id="'+s.id+'" aria-label="Descartar" title="Descartar evaluación">'+I.trash+'</button><button class="btn sm hide-sm" data-act="step" data-v="3">'+I.doc+'Debriefing</button><button class="btn sm primary" data-act="step" data-v="3">Cierre'+I.chev.replace('class="chev"','width="14" height="14"')+'</button></div><div class="progress"><div style="width:'+(total/max*100)+'%"></div></div></div>';
  html+=stepsBar(2,s);
  if(s.mode==='crew'&&!wide){html+='<div class="seg" style="margin-bottom:16px">'+ss.map(function(x){return '<button class="'+(seat===x?'on':'')+'" data-act="seat" data-v="'+x+'">'+x.toUpperCase()+' · '+esc(pname(s.pilots[x]))+' <span class="muted num">'+graded(s,x)+'/9</span></button>';}).join('')+'</div>';}
  var sim=!!S.ui.sim;
  // eventos por fase
  var phases=S.settings.flightPhases||[];var groups={};s.events.forEach(function(e,i){var p=e.phase||'';(groups[p]=groups[p]||[]).push(i);});
  var order=phases.filter(function(p){return groups[p];}).concat(Object.keys(groups).filter(function(p){return phases.indexOf(p)<0;}));
  html+='<div class="card" style="margin-bottom:16px"><div class="card-head"><div><h3>Eventos de la sesión</h3><p class="small muted">'+(sim?'Modo simulador: marca la hora de cada evento y dicta la evidencia con el micrófono del teclado.':'Marca los eventos completados y, si aplica, califícalos. Debajo de cada uno ves el historial del trainee en esa maniobra.')+'</p></div><div class="row">'+(s.startedAt?'<span class="pill acc" id="simclock">'+I.clock.replace('<svg','<svg width="13" height="13"')+simClock(s)+'</span>':'')+'<div class="seg"><button class="'+(!sim?'on':'')+'" data-act="simMode" data-v="">Normal</button><button class="'+(sim?'on':'')+'" data-act="simMode" data-v="1">Simulador</button></div></div></div>'+
   (sim&&!s.startedAt?'<button class="btn primary sm" data-act="simStart" style="margin-bottom:10px">'+I.clock+'Iniciar cronómetro de sesión</button>':'')+
   (s.events.length?order.map(function(p){var idx=groups[p];var done=idx.filter(function(i){return s.events[i].done;}).length;return (p?'<div class="phase-h"><span class="eyebrow">'+esc(p)+'</span><span class="tiny muted num">'+done+'/'+idx.length+'</span><div class="progress"><div style="width:'+(done/idx.length*100)+'%;background:'+(done===idx.length?'var(--ok)':'var(--accent)')+'"></div></div></div>':'')+idx.map(function(i){return evRow(s,s.events[i],i,sim,cols);}).join('');}).join(''):'<p class="small muted" style="margin-bottom:8px">Sin eventos cargados.</p>')+
   '<div class="row" style="margin-top:10px"><button class="btn sm" data-act="newEvent">'+I.plus+'Agregar evento</button></div></div>';
  if(ORG('temEnabled',true))html+=temCard(s,true);
  // competencias
  if(wide)html+='<div class="seat-h">'+ss.map(function(x){return '<div><span class="avatar" style="width:28px;height:28px;font-size:11px">'+initials(pname(s.pilots[x]))+'</span><span class="eyebrow">'+x.toUpperCase()+'</span><span style="flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(pname(s.pilots[x]))+'</span><span class="muted num small">'+graded(s,x)+'/9</span></div>';}).join('')+'</div>';
  html+='<div class="'+(wide?'stack':'grid g2')+'">'+COMP.map(function(c){
    var chips=cols.map(function(x){var r=(s.grades[x]||{})[c.k]||{};return (r.g||r.no)?'<span class="gchip '+(r.no?'gc0':gcls(r.g))+'" '+(r.no?'style="font-size:10px"':'')+'>'+gtxt(r)+'</span>':'';}).join('');
    return '<div class="card comp" id="c-'+c.k+'"'+((s.targets||[]).indexOf(c.k)>=0?' style="box-shadow:inset 0 0 0 1.5px var(--accent)"':'')+'><div class="comp-h"><span class="code">'+c.k+'</span>'+((s.targets||[]).indexOf(c.k)>=0?'<span class="pill acc" style="height:20px;flex:none" title="Competencia objetivo del módulo">Objetivo</span>':'')+'<div style="flex:1;min-width:0"><h3>'+esc(c.es)+'</h3><div class="tiny muted">'+esc(c.en)+'</div></div><span class="row" style="gap:4px">'+chips+'</span></div>'+
      (wide?'<div class="grow-row">'+cols.map(function(x){return '<div class="comp" style="gap:10px">'+compBlock(s,x,c)+'</div>';}).join('')+'</div>':compBlock(s,seat,c))+'</div>';}).join('')+'</div>';
  var nextBtn=wide?'<button class="btn primary" data-act="step" data-v="3">Cierre y firmas'+I.chev.replace('class="chev"','width="16" height="16"')+'</button>':
    s.mode==='crew'&&seat==='cm1'?'<button class="btn primary" data-act="nextSeat" data-v="cm2">Siguiente: CM2 · '+esc(pname(s.pilots.cm2).split(' ')[0])+I.chev.replace('class="chev"','width="16" height="16"')+'</button><button class="btn" data-act="step" data-v="3">Cierre y firmas</button>':
    (s.mode==='crew'?'<button class="btn" data-act="nextSeat" data-v="cm1">'+I.back+'CM1</button>':'')+'<button class="btn primary" data-act="step" data-v="3">Cierre y firmas'+I.chev.replace('class="chev"','width="16" height="16"')+'</button>';
  html+='<div class="sticky-bar" style="align-items:center"><span class="spacer"></span>'+(wide?'':'<button class="btn ghost sm" data-act="discard" data-id="'+s.id+'">Descartar</button>')+'<button class="btn" data-act="saveDraft">Guardar</button>'+nextBtn+'</div>';
  return html;
}
function vClose(s){
  var html=head('Cierre · '+esc(s.phase),fdate(s.date)+' · '+esc(s.module)+' · '+esc(s.fleet));
  html+=stepsBar(3,s);
  html+='<div class="grid '+(s.mode==='crew'?'g2':'')+'" style="margin-bottom:16px">'+seats(s).map(function(x){var av=sessAvg(s,x),r=s.result[x]||'';
    var missing=CK.filter(function(k){var q=s.grades[x][k];return !(q&&(q.g||q.no));});
    return '<div class="card stack"><div class="row"><span class="avatar">'+initials(pname(s.pilots[x]))+'</span><div style="flex:1;min-width:0"><div class="eyebrow">'+x.toUpperCase()+'</div><h3>'+esc(pname(s.pilots[x]))+'</h3></div><span class="gchip '+gcls(av)+'" style="width:44px;height:34px;font-size:15px">'+f1(av)+'</span></div>'+
     (missing.length?'<div class="pill bad" style="align-self:flex-start">Faltan: '+missing.join(' ')+'</div>':'')+
     '<div style="display:grid;grid-template-columns:repeat(9,1fr);gap:4px">'+CK.map(function(k){var q=s.grades[x][k]||{};var v=q.g;return '<div style="text-align:center"><div class="tiny muted" style="font-family:var(--mono)">'+k+'</div><span class="gchip '+(q.no?'gc0':gcls(v))+'" style="width:100%;'+(q.no?'font-size:10px':'')+'">'+(q.no?'N/O':(v||'·'))+'</span></div>';}).join('')+'</div>'+
     '<div class="field"><label>Resultado</label><div class="seg full">'+['C','RT','INC'].map(function(k){return '<button class="'+(r===k?'on':'')+'" data-act="result" data-seat="'+x+'" data-v="'+k+'" title="'+RES[k][0]+'">'+({C:'Competente',RT:'Entrenamiento adicional',INC:'Incompleto'})[k]+'</button>';}).join('')+'</div></div>'+
     '<div><div class="eyebrow" style="margin-bottom:6px">Foco sugerido</div>'+focusList(s,x)+'</div></div>';}).join('')+'</div>';
  html+='<div class="card stack" style="margin-bottom:16px"><div class="row"><h3 style="flex:1">Debriefing y recomendaciones</h3>'+(s.mode==='crew'?'<div class="seg"><button class="'+(s.debriefMode!=='each'?'on':'')+'" data-act="debMode" data-v="joint">Uno conjunto</button><button class="'+(s.debriefMode==='each'?'on':'')+'" data-act="debMode" data-v="each">Uno por trainee</button></div>':'')+'</div>'+
    debTargets(s).map(function(t){return '<div class="stack" style="gap:8px"><div class="row">'+(t.label?'<div class="eyebrow" style="flex:1">'+esc(t.label)+'</div>':'<span class="spacer"></span>')+'<button class="btn sm" data-act="aiDebrief" data-t="'+t.key+'">'+I.spark+'Redactar con IA</button></div>'+
      '<div class="chips mini">'+(S.settings.debPhrases||[]).map(function(ph){return '<button class="chip" data-act="debPhrase" data-t="'+t.key+'" data-txt="'+esc(ph)+'">'+esc(ph.length>58?ph.slice(0,56)+'…':ph.replace(/[.:]\s*$/,''))+'</button>';}).join('')+'</div>'+
      '<textarea class="input" id="deb-'+t.key+'" data-sb="'+t.path+'" style="min-height:120px" placeholder="Hallazgos principales, OB observados, acuerdos y training focus para el próximo módulo.">'+esc(t.val)+'</textarea></div>';}).join('')+'</div>';
  html=html.slice(0,-'</div>'.length)+aiNote(s)+'</div>';
  var who=[['inst','Instructor · '+S.settings.instructor]].concat(seats(s).map(function(x){return [x,x.toUpperCase()+' · '+pname(s.pilots[x])];}));
  html+='<div class="card"><div class="card-head"><div><h3>Firmas</h3><p class="small muted">Firma con el dedo o el Apple Pencil. La firma del instructor es obligatoria.</p></div></div><div class="grid '+(who.length>1?'g'+Math.min(who.length,3):'')+'">'+who.map(function(w){return '<div class="field"><div class="row"><label style="flex:1">'+esc(w[1])+'</label><button class="btn ghost sm" data-act="sigClear" data-k="'+w[0]+'">Borrar</button></div><div class="sigbox"><span class="line"></span><canvas data-sig="'+w[0]+'" id="sig-'+w[0]+'"></canvas>'+(s.sig[w[0]]?'':'<span class="ph">Firma aquí</span>')+'</div></div>';}).join('')+'</div></div>';
  html+='<div class="sticky-bar"><button class="btn" data-act="step" data-v="2">Volver a calificar</button><button class="btn" data-act="saveDraft">Guardar borrador</button><button class="btn primary" data-act="finalize">'+I.sign+'Firmar y cerrar</button></div>';
  return html;
}

function debTargets(s){
  if(s.mode==='crew'&&s.debriefMode==='each'){s.debriefBy=s.debriefBy||{cm1:'',cm2:''};return seats(s).map(function(x){return {key:x,label:x.toUpperCase()+' · '+pname(s.pilots[x]),path:'debriefBy.'+x,val:s.debriefBy[x]||''};});}
  return [{key:'joint',label:'',path:'debrief',val:s.debrief||''}];
}
/* ============ Firma ============ */
function mountSigs(){
  document.querySelectorAll('canvas[data-sig]').forEach(function(cv){
    var s=cur();if(!s)return;var key=cv.dataset.sig,dpr=window.devicePixelRatio||1,w=cv.clientWidth,h=cv.clientHeight;
    cv.width=w*dpr;cv.height=h*dpr;var ctx=cv.getContext('2d');ctx.scale(dpr,dpr);ctx.lineCap='round';ctx.lineJoin='round';ctx.lineWidth=2.2;ctx.strokeStyle='#14141a';
    if(s.sig[key]){var im=new Image();im.onload=function(){var r=Math.min(w/im.width,h/im.height);ctx.drawImage(im,(w-im.width*r)/2,(h-im.height*r)/2,im.width*r,im.height*r);};im.src=s.sig[key];}
    var drawing=false,last=null,dirty=false;
    function pos(e){var b=cv.getBoundingClientRect();return [e.clientX-b.left,e.clientY-b.top];}
    cv.addEventListener('pointerdown',function(e){drawing=true;last=pos(e);cv.setPointerCapture(e.pointerId);var ph=cv.parentNode.querySelector('.ph');if(ph)ph.remove();e.preventDefault();});
    cv.addEventListener('pointermove',function(e){if(!drawing)return;var p=pos(e);ctx.lineWidth=e.pressure&&e.pointerType==='pen'?1.2+e.pressure*2.4:2.2;ctx.beginPath();ctx.moveTo(last[0],last[1]);ctx.lineTo(p[0],p[1]);ctx.stroke();last=p;dirty=true;e.preventDefault();});
    function end(){if(!drawing)return;drawing=false;if(!dirty)return;
      var out=document.createElement('canvas'),sc=Math.min(1,480/w);out.width=Math.round(w*sc);out.height=Math.round(h*sc);var o=out.getContext('2d');o.fillStyle='#fff';o.fillRect(0,0,out.width,out.height);o.drawImage(cv,0,0,out.width,out.height);
      var s2=cur();if(s2){s2.sig[key]=out.toDataURL('image/jpeg',.82);put('sessions',s2,true);}}
    cv.addEventListener('pointerup',end);cv.addEventListener('pointercancel',end);
  });
}

/* ============ Hojas (modales) ============ */
function sheetHTML(){
  var sh=S.ui.sheet;if(!sh)return '';
  var body='',title='',narrow=false,actions='';
  if(sh.type==='session'){var s=S.sessions[sh.id];if(!s){S.ui.sheet=null;return '';}title='Sesión '+esc(s.phase);body=sessionDetail(s);
    actions='<button class="btn sm" data-act="pdfSession" data-id="'+s.id+'">'+I.down+'PDF</button>';}
  else if(sh.type==='pilot'){title=sh.id?'Editar trainee':'Nuevo trainee';narrow=true;body=pilotForm();actions='<button class="btn sm primary" data-act="savePilot">Guardar</button>';}
  else if(sh.type==='tpl'){title=sh.id?'Editar plantilla':'Nueva plantilla';body=tplForm();actions='<button class="btn sm primary" data-act="saveTpl">Guardar</button>';}
  else if(sh.type==='event'){title='Nuevo evento';narrow=true;var f=S.ui.form;body='<div class="stack"><div class="field"><label for="ev-t">Maniobra, procedimiento o escenario</label><input class="input" id="ev-t" data-fb="t" value="'+esc(f.t||'')+'" placeholder="Ej. Rejected takeoff" autofocus></div><div class="field"><label for="ev-ph">Fase de vuelo</label><select class="input" id="ev-ph" data-fb="phase"><option value="">Sin fase</option>'+(S.settings.flightPhases||[]).map(function(p){return '<option'+(f.phase===p?' selected':'')+'>'+esc(p)+'</option>';}).join('')+'</select></div><div class="field"><label>Competencias que expone</label><div class="tags">'+CK.map(function(k){return '<button class="tag'+((f.c||[]).indexOf(k)>=0?' on':'')+'" data-act="evTag" data-k="'+k+'">'+k+'</button>';}).join('')+'</div></div><div class="row" style="justify-content:flex-end"><button class="btn" data-act="closeSheet">Cancelar</button><button class="btn primary" data-act="evAddSheet">'+I.plus+'Agregar</button></div></div>';}
  else if(sh.type==='slot'){var sl=S.schedule[sh.id];if(!sl){S.ui.sheet=null;return '';}title='Sesión programada';body=slotDetail(sl);actions=sl.status!=='cancelled'&&!sl.sessionId?'<button class="btn sm primary" data-act="startFromSlot" data-id="'+sl.id+'">Iniciar</button>':'';}
  else if(sh.type==='slotForm'){title=sh.id?'Editar sesión programada':'Programar sesión';body=slotForm();actions='<button class="btn sm primary" data-act="saveSlot">Guardar</button>';}
  else if(sh.type==='notice'){title='Nuevo aviso';narrow=true;body=noticeForm();actions='<button class="btn sm primary" data-act="saveNotice">Publicar</button>';}
  else if(sh.type==='confirm'){title=esc(sh.title||'Confirmar');narrow=true;body='<p style="margin-bottom:18px">'+esc(sh.msg)+'</p><div class="row" style="justify-content:flex-end"><button class="btn" data-act="closeSheet">Cancelar</button><button class="btn primary" data-act="confirmYes" style="background:var(--bad)">'+esc(sh.yes||'Eliminar')+'</button></div>';}
  if(!body&&typeof sheetExtra==='function'){var x=sheetExtra(sh);if(!x){S.ui.sheet=null;return '';}title=x.title;body=x.body;narrow=!!x.narrow;actions=x.actions||'';}
  return '<div class="scrim" data-act="scrim"><div class="sheet'+(narrow?' narrow':'')+'" role="dialog" aria-modal="true" id="sheet"><div class="sheet-h"><button class="btn ghost sm" data-act="closeSheet" aria-label="Cerrar">'+I.x+'</button><h2>'+title+'</h2><div style="min-width:36px;display:flex;justify-content:flex-end">'+actions+'</div></div><div class="sheet-b">'+body+'</div></div></div>';
}
function sessionDetail(s){
  var t=s.templateId&&S.evals[s.templateId];
  var html='<div class="row" style="margin-bottom:14px">'+(s.status==='signed'?'<span class="pill ok">Firmada '+ftime(s.signedAt)+'</span>':'<span class="pill warn">Borrador</span>')+(s.example?'<span class="pill">Ejemplo</span>':'')+'<span class="spacer"></span>'+
   (s.status==='draft'?'<button class="btn sm primary" data-act="resume" data-id="'+s.id+'">Continuar</button>':'')+'<button class="btn sm" data-act="askSession" data-id="'+s.id+'">'+I.spark+'Analizar con IA</button></div>';
  html+='<div class="card" style="margin-bottom:14px"><dl class="kv"><dt>Fecha</dt><dd>'+fdate(s.date)+'</dd><dt>Módulo</dt><dd>'+esc(s.module)+'</dd><dt>Flota · fase</dt><dd>'+esc(s.fleet)+' · '+esc(s.phase)+' <span class="muted small">('+esc(phaseName(s.phase))+')</span></dd>'+(t?'<dt>Plantilla</dt><dd>'+esc(t.name)+'</dd>':'')+'<dt>Instructor</dt><dd>'+esc(s.instructor||'')+'</dd>'+(s.slotId&&S.schedule[s.slotId]?'<dt>Agenda</dt><dd><button class="btn ghost sm" data-act="openSlot" data-id="'+s.slotId+'" style="height:auto">'+esc(S.schedule[s.slotId].sim||'Sesión programada')+' · '+esc(S.schedule[s.slotId].time||'')+'</button></dd>':'')+(s.hash?'<dt>Sello</dt><dd class="num" style="font-family:var(--mono);font-size:12px">'+esc(s.hash)+'</dd>':'')+'</dl></div>';
  seats(s).forEach(function(x){var r=RES[s.result[x]||''],g=s.grades[x]||{};
    html+='<div class="card" style="margin-bottom:14px"><div class="row" style="margin-bottom:10px"><span class="avatar">'+initials(pname(s.pilots[x]))+'</span><div style="flex:1;min-width:0"><div class="eyebrow">'+x.toUpperCase()+'</div><h3>'+esc(pname(s.pilots[x]))+'</h3></div><span class="pill '+r[1]+'">'+r[0]+'</span><span class="gchip '+gcls(sessAvg(s,x))+'" style="width:40px">'+f1(sessAvg(s,x))+'</span></div><div class="scroll-x"><table class="tbl"><tbody>'+
    CK.map(function(k){var e=g[k]||{},ob=e.ob||{};var obs=Object.keys(ob).filter(function(o){return ob[o];}).map(function(o){return '<span class="tag" style="'+(ob[o]<0?'color:var(--bad)':'color:var(--ok)')+'" title="'+esc(obText(k,o))+'">'+(ob[o]<0?'−':'+')+o+'</span>';}).join(' ');
      return '<tr><td style="width:50px"><span class="code">'+k+'</span></td><td style="width:40px"><span class="gchip '+(e.no?'gc0':gcls(e.g))+'" '+(e.no?'style="font-size:10px"':'')+'>'+gtxt(e)+'</span></td><td><div class="small">'+esc(CMAP[k].es)+'</div>'+(obs?'<div class="tags">'+obs+'</div>':'')+(e.note?'<div class="small muted" style="margin-top:4px">'+esc(e.note)+'</div>':'')+'</td></tr>';}).join('')+'</tbody></table></div></div>';});
  if(s.events&&s.events.length)html+='<div class="card" style="margin-bottom:14px"><h3 style="margin-bottom:6px">Eventos</h3>'+s.events.map(function(e){return '<div class="ev"><span class="check'+(e.done?' on':'')+'" style="cursor:default">'+(e.done?I.check:'')+'</span><div style="min-width:0"><div>'+(e.at?'<span class="pill num" style="margin-right:6px">'+hhmm(e.at)+'</span>':'')+esc(e.t)+'</div><div class="tags">'+(e.c||[]).map(function(c){return '<span class="tag">'+c+'</span>';}).join('')+'</div>'+(e.note?'<div class="small muted" style="margin-top:3px">'+esc(e.note)+'</div>':'')+(e.g&&(e.g.cm1||e.g.cm2)?'<div class="row" style="gap:6px;margin-top:4px">'+seats(s).map(function(x){return e.g[x]?'<span class="tiny muted">'+x.toUpperCase()+'</span><span class="gchip '+gcls(e.g[x])+'" style="width:22px;height:22px;font-size:12px">'+e.g[x]+'</span>':'';}).join('')+'</div>':'')+'</div></div>';}).join('')+'</div>';
  if(temList(s).length)html+=temCard(s,false).replace('margin-bottom:16px','margin-bottom:14px');
  debTargets(s).forEach(function(t){if(t.val)html+='<div class="card" style="margin-bottom:14px"><h3 style="margin-bottom:6px">Debriefing'+(t.label?' · '+esc(t.label):'')+'</h3><p style="white-space:pre-wrap">'+esc(t.val)+'</p></div>';});
  var who=[['inst','Instructor']].concat(seats(s).map(function(x){return [x,x.toUpperCase()];}));
  html+='<div class="card" style="margin-bottom:14px"><h3 style="margin-bottom:10px">Firmas</h3><div class="grid g3">'+who.map(function(w){return '<div><div class="tiny muted" style="margin-bottom:4px">'+w[1]+'</div>'+(s.sig[w[0]]?'<img class="sigimg" alt="Firma '+w[1]+'" src="'+s.sig[w[0]]+'">':'<div class="sigimg" style="display:grid;place-items:center;color:var(--faint);font-size:12px">'+(s.example?'Ejemplo sin firma':'Sin firma')+'</div>')+'</div>';}).join('')+'</div></div>';
  if(isCoord()||(s.status==='draft'&&isMine(s)))html+='<div class="row"><button class="btn danger sm" data-act="delSession" data-id="'+s.id+'">'+I.trash+'Eliminar sesión</button></div>';
  return html;
}
function pilotForm(){
  var f=S.ui.form;
  function inp(id,k,l,ph){return '<div class="field"><label for="'+id+'">'+l+'</label><input class="input" id="'+id+'" data-fb="'+k+'" value="'+esc(f[k]||'')+'" placeholder="'+esc(ph||'')+'"></div>';}
  return '<div class="stack">'+inp('pf-n','name','Nombre completo','Nombre y apellido')+'<div class="grid g2" style="gap:12px">'+inp('pf-e','emp','Código de empleado')+inp('pf-b','base','Base','BOG')+'</div>'+
   '<div class="field"><label>Cargo</label><div class="seg"><button class="'+(f.rank==='CPT'?'on':'')+'" data-act="form" data-k="rank" data-v="CPT">Capitán</button><button class="'+(f.rank==='FO'?'on':'')+'" data-act="form" data-k="rank" data-v="FO">Primer oficial</button></div></div>'+
   '<div class="field"><label>Flota</label><div class="seg">'+S.settings.fleets.map(function(x){return '<button class="'+(f.fleet===x?'on':'')+'" data-act="form" data-k="fleet" data-v="'+esc(x)+'">'+esc(x)+'</button>';}).join('')+'</div></div>'+
   (f.id&&isCoord()?'<hr class="sep"><button class="btn danger sm" data-act="delPilot" data-id="'+f.id+'" style="align-self:flex-start">'+I.trash+'Eliminar piloto</button>':'')+'</div>';
}
function tplForm(){
  var f=S.ui.form,st=S.settings;
  return '<div class="stack"><div class="field"><label for="tf-n">Nombre</label><input class="input" id="tf-n" data-fb="name" value="'+esc(f.name||'')+'" placeholder="EVAL A320 · Módulo 2"></div>'+
   '<div class="grid g3" style="gap:12px"><div class="field"><label for="tf-m">Módulo</label><select class="input" id="tf-m" data-fb="module">'+st.modules.map(function(m){return '<option'+(f.module===m?' selected':'')+'>'+esc(m)+'</option>';}).join('')+'</select></div>'+
   '<div class="field"><label for="tf-f">Flota</label><select class="input" id="tf-f" data-fb="fleet">'+st.fleets.map(function(m){return '<option'+(f.fleet===m?' selected':'')+'>'+esc(m)+'</option>';}).join('')+'</select></div>'+
   '<div class="field"><label for="tf-p">Fase</label><select class="input" id="tf-p" data-fb="phase">'+st.phases.map(function(m){return '<option'+(f.phase===m?' selected':'')+'>'+esc(m)+'</option>';}).join('')+'</select></div></div>'+
   '<div class="field"><label for="tf-note">Notas</label><input class="input" id="tf-note" data-fb="note" value="'+esc(f.note||'')+'" placeholder="Referencia: FCTS, Handbook, matriz del módulo"></div>'+
   '<div class="eyebrow" style="margin-top:6px">Eventos y competencias expuestas</div>'+
   (f.events||[]).map(function(e,i){return '<div class="card" style="padding:12px 14px;box-shadow:inset 0 0 0 1px var(--line)"><div class="row"><input class="input" id="tf-e'+i+'" data-fe="'+i+'" value="'+esc(e.t)+'" placeholder="Descripción del evento" style="flex:1;min-width:180px"><select class="input" id="tf-ph'+i+'" data-fep="'+i+'" style="width:auto;max-width:180px"><option value="">Sin fase</option>'+(S.settings.flightPhases||[]).map(function(p){return '<option'+(e.phase===p?' selected':'')+'>'+esc(p)+'</option>';}).join('')+'</select><button class="btn ghost sm" data-act="tplEvDel" data-i="'+i+'" aria-label="Quitar">'+I.x+'</button></div><div class="tags" style="margin-top:8px">'+CK.map(function(k){return '<button class="tag'+((e.c||[]).indexOf(k)>=0?' on':'')+'" data-act="tplEvC" data-i="'+i+'" data-k="'+k+'">'+k+'</button>';}).join('')+'</div></div>';}).join('')+
   '<button class="btn sm" data-act="tplEvAdd" style="align-self:flex-start">'+I.plus+'Agregar evento</button>'+
   (f.id?'<hr class="sep"><button class="btn danger sm" data-act="delTpl" data-id="'+f.id+'" style="align-self:flex-start">'+I.trash+'Eliminar plantilla</button>':'')+'</div>';
}
