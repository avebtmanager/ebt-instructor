// EBT Instructor · invitaciones del Manager (función Edge «ei-invite», ya desplegada; copia de referencia).
// Verifica el token del usuario dentro de la función (verify_jwt=false) y exige rol Manager activo en ei_members.
import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
const clean = (v: unknown, n = 120) => (v == null || v === "" ? null : String(v).trim().slice(0, n));

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const admin = createClient(url, service, { auth: { persistSession: false, autoRefreshToken: false } });

    const jwt = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
    if (!jwt) return json({ error: "not_authenticated" }, 401);
    const { data: who, error: whoErr } = await admin.auth.getUser(jwt);
    if (whoErr || !who?.user) return json({ error: "not_authenticated" }, 401);
    const caller = who.user;

    const { data: me } = await admin.from("ei_members").select("role,status").eq("user_id", caller.id).maybeSingle();
    if (!me || me.role !== "manager" || me.status !== "active") return json({ error: "forbidden" }, 403);

    const b = await req.json().catch(() => ({}));
    const action = b.action === "cancel" ? "cancel" : "invite";
    const email = String(b.email || "").trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 200) return json({ error: "invalid_email" }, 400);

    if (action === "cancel") {
      await admin.from("ei_invites").delete().eq("email", email).is("accepted_at", null);
      return json({ status: "cancelled" });
    }

    const role = b.role === "manager" ? "manager" : "instructor";
    const redirectTo = typeof b.redirectTo === "string" && /^https:\/\//.test(b.redirectTo) ? b.redirectTo : undefined;
    const inv = { email, full_name: clean(b.full_name) || "", role, ie_code: clean(b.ie_code, 20), rank: clean(b.rank, 10), fleet: clean(b.fleet, 20), invited_by: caller.id };

    let existing: any = null;
    for (let page = 1; page <= 20 && !existing; page++) {
      const { data: list, error } = await admin.auth.admin.listUsers({ page, perPage: 200 });
      if (error) break;
      existing = list.users.find((x: any) => (x.email || "").toLowerCase() === email) || null;
      if (list.users.length < 200) break;
    }

    await admin.from("ei_invites").delete().eq("email", email).is("accepted_at", null);

    if (existing && existing.email_confirmed_at) {
      if (existing.id === caller.id) return json({ error: "self" }, 400);
      const { error: me2 } = await admin.from("ei_members").upsert({ user_id: existing.id, role, status: "active", full_name: inv.full_name, email, ie_code: inv.ie_code, rank: inv.rank, fleet: inv.fleet }, { onConflict: "user_id" });
      if (me2) return json({ error: "member_failed", detail: me2.message }, 500);
      await admin.from("ei_invites").insert({ ...inv, user_id: existing.id, accepted_at: new Date().toISOString() });
      return json({ status: "existing_user" });
    }
    if (existing && !existing.email_confirmed_at) await admin.auth.admin.deleteUser(existing.id);

    const { error: insErr } = await admin.from("ei_invites").insert(inv);
    if (insErr) return json({ error: "invite_store_failed", detail: insErr.message }, 500);
    const { error: sendErr } = await admin.auth.admin.inviteUserByEmail(email, { redirectTo, data: { full_name: inv.full_name } });
    if (sendErr) return json({ error: "email_failed", detail: sendErr.message }, 502);
    return json({ status: "invited" });
  } catch (e) {
    return json({ error: "server_error", detail: String((e as Error)?.message || e) }, 500);
  }
});
